import type { AtlasLocation, ChronologicalEvent } from "@/lib/types";
import { LOCATIONS_PART_1 } from "./locations-part1";
import { LOCATIONS_PART_2 } from "./locations-part2";

export const ATLAS_LOCATIONS: AtlasLocation[] = [
  ...LOCATIONS_PART_1,
  ...LOCATIONS_PART_2,
];

/**
 * Haversine straight-line distance in km between two verified WGS84 points.
 * Used strictly as an editorial lower-bound estimate, never presented as exact footsteps.
 */
export function haversineKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function buildAtlasGeoJson(
  locations: AtlasLocation[],
  events: ChronologicalEvent[]
) {
  const locMap = new Map(locations.map((l) => [l.id, l]));

  const pointFeatures = locations
    .filter((l) => l.latitude !== null && l.longitude !== null)
    .map((l) => ({
      type: "Feature" as const,
      id: l.id,
      geometry: {
        type: "Point" as const,
        coordinates: [l.longitude as number, l.latitude as number],
      },
      properties: {
        id: l.id,
        nameKa: l.nameKa,
        nameEn: l.nameEn,
        novelNameEn: l.novelNameEn,
        category: l.category,
        literaryStatus: l.literaryStatus,
        historicalStatus: l.historicalStatus,
        confidence: l.confidence,
        coordinatePrecision: l.coordinatePrecision,
        historicalAddress: l.historicalAddress,
        modernAddress: l.modernAddress,
        neighborhoodKa: l.neighborhoodKa,
        stillExistsToday: l.stillExistsToday,
        chapters: l.chapters,
      },
    }));

  const routeFeatures: Array<{
    type: "Feature";
    id: string;
    geometry: { type: "LineString"; coordinates: number[][] };
    properties: Record<string, unknown>;
  }> = [];

  let lastMappedLoc: AtlasLocation | null = null;
  let skippedUnmapped = false;

  const sortedEvents = [...events].sort((a, b) => a.sequence - b.sequence);
  for (const ev of sortedEvents) {
    const curr = locMap.get(ev.locationId);
    if (!curr || curr.latitude === null || curr.longitude === null) {
      skippedUnmapped = true;
      continue;
    }
    if (lastMappedLoc && lastMappedLoc.id !== curr.id) {
      const certainty = skippedUnmapped ? "editorial" : ev.movementCertainty;
      routeFeatures.push({
        type: "Feature",
        id: `connector-${ev.id}`,
        geometry: {
          type: "LineString",
          coordinates: [
            [lastMappedLoc.longitude as number, lastMappedLoc.latitude as number],
            [curr.longitude, curr.latitude],
          ],
        },
        properties: {
          eventId: ev.id,
          sequence: ev.sequence,
          fromLocationId: lastMappedLoc.id,
          toLocationId: curr.id,
          movementCertainty: certainty,
          movementModeKa: ev.movementModeKa,
          note: "ქრონოლოგიური კავშირი — არ წარმოადგენს დადასტურებულ ქუჩა-ქუჩა მარშრუტს",
        },
      });
    }
    lastMappedLoc = curr;
    skippedUnmapped = false;
  }

  return {
    type: "FeatureCollection" as const,
    metadata: {
      project: "პროექტი ჰოლდენი — ლიტერატურული ატლასი",
      language: "ka",
      crs: "EPSG:4326 (WGS84)",
      unmappedFictionalLocations: locations
        .filter((l) => l.latitude === null || l.longitude === null)
        .map((l) => ({
          id: l.id,
          nameKa: l.nameKa,
          reason: l.uncertaintyNoteKa,
        })),
    },
    features: [...pointFeatures, ...routeFeatures],
  };
}
