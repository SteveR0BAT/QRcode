import type {
  ResearchSource,
  AuditItem,
  LiteraryTheme,
} from "@/lib/types";

export const RESEARCH_SOURCES: ResearchSource[] = [
  {
    id: "src-salinger-1951",
    titleKa: "ჯ. დ. სელინჯერი — „თამაში ჭვავის ყანაში“ (ორიგინალური გამოცემა, 26 თავი)",
    originalTitle: "J. D. Salinger, The Catcher in the Rye (Boston: Little, Brown and Company)",
    authorOrInstitution: "ჯ. დ. სელინჯერი / Little, Brown and Company",
    publicationDate: "1951-07-16",
    url: "https://openlibrary.org/works/OL3335295W/The_Catcher_in_the_Rye",
    category: "primary_literary",
    relevantClaimKa:
      "უმაღლესი პირველადი ლიტერატურული წყარო: ადგენს ჰოლდენ კოლფილდის ნიუ-იორკში ყოფნის ყველა სცენას (თავები 9–25), რეტროსპექტულ ჩარჩოს (თავები 1, 26), პერსონაჟებსა და მარშრუტის თანმიმდევრობას. ციტირება ხდება თავების მიხედვით.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (პირველადი ტექსტი)",
  },
  {
    id: "src-salinger-ka",
    titleKa: "ჯერომ სელინჯერი — „თამაში ჭვავის ყანაში“ (ქართული თარგმანი, მთარგმნ. ვახტანგ ჭელიძე)",
    originalTitle: "ჯ. დ. სელინჯერი, „თამაში ჭვავის ყანაში“, თბილისი (ვახტანგ ჭელიძის კლასიკური თარგმანი)",
    authorOrInstitution: "ვახტანგ ჭელიძე (მთარგმნელი)",
    publicationDate: "1963 / 2019",
    url: "https://nplg.gov.ge/",
    category: "primary_literary",
    relevantClaimKa:
      "საქართველოს პარლამენტის ეროვნულ ბიბლიოთეკაში დაცული კლასიკური ქართული თარგმანის ტრადიცია, რომლის მიხედვითაც რომანის ქართული სათაური და პერსონაჟთა ონომასტიკაა შეჯერებული.",
    accessedDate: "2026-04",
    reliabilityKa: "მაღალი (სტანდარტული ქართული გამოცემა)",
  },
  {
    id: "src-loc-penn-1942",
    titleKa: "აშშ-ის კონგრესის ბიბლიოთეკა — პენსილვანიის სადგურის მოსაცდელი დარბაზი (1942)",
    originalTitle: "Waiting for trains at the Pennsylvania railroad station, New York (Marjory Collins, FSA/OWI Collection)",
    authorOrInstitution: "United States Library of Congress — Prints & Photographs Division",
    publicationDate: "1942-08",
    url: "https://commons.wikimedia.org/wiki/File:Waiting_for_trains_at_the_Pennsylvania_railroad_station_8d21823v.jpg",
    category: "historical_primary",
    relevantClaimKa:
      "ასახავს McKim, Mead & White-ის მიერ 1910 წელს აგებული ძველი პენსილვანიის სადგურის 1940-იანი წლების ინტერიერსა და მინის ბლოკების იატაკს დანგრევამდე.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (საჯარო დომენის საარქივო ფოტო)",
  },
  {
    id: "src-nps-penn",
    titleKa: "აშშ-ის ეროვნული პარკების სამსახური — პენსილვანიის სადგურის დანგრევა (1963–1966) და ძეგლთა დაცვის კანონი",
    originalTitle: "Pennsylvania Station (1910–1963) and the Landmarks Preservation Movement",
    authorOrInstitution: "U.S. National Park Service / New-York Historical Society",
    publicationDate: "2023",
    url: "https://home.nps.gov/subjects/historicpreservation/national-historic-preservation-act.htm",
    category: "secondary_historical",
    relevantClaimKa:
      "ადასტურებს 1910 წლის Beaux-Arts-ის სტილის პენსილვანიის სადგურის მიწისზედა ნაგებობის დანგრევას 1963–1966 წლებში და მის გავლენას ნიუ-იორკის 1965 წლის ძეგლთა დაცვის კანონზე.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (ოფიციალური სახელმწიფო ინსტიტუცია)",
  },
  {
    id: "src-nytimes-biltmore-1981",
    titleKa: "The New York Times — სასტუმრო „ბილტმორის“ დემონტაჟი და მისი ბრინჯაოს საათის ბედი (1981)",
    originalTitle: "Biltmore Dismantling Stopped Again: For Hotel, Clock Runs Out / Biltmore Clock Gets Home",
    authorOrInstitution: "The New York Times Archive",
    publicationDate: "1981-08-17",
    url: "https://www.nytimes.com/1981/08/17/nyregion/biltmore-dismantling-stopped-again-for-hotel-clock-runs-out.html",
    category: "historical_primary",
    relevantClaimKa:
      "ადასტურებს სასტუმრო „ბილტმორის“ (1913–1981, მედისონ-ავენიუ 335, 43-ე–44-ე ქუჩები) ინტერიერის დანგრევას 1981 წლის აგვისტოში, შენობის გადაკეთებას საოფისე კოშკად და ცნობილი ბრინჯაოს საათის შემონახვას; უშუალოდ იმოწმებს სელინჯერის მე-17 თავს.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (დოკუმენტური საგაზეთო არქივი)",
  },
  {
    id: "src-loc-biltmore-1921",
    titleKa: "აშშ-ის კონგრესის ბიბლიოთეკა — სასტუმრო „ბილტმორი“ მედისონ-ავენიუზე (ირვინგ ანდერჰილი, 1921)",
    originalTitle: "Equitable Trust Building & Hotel Biltmore, New York City (Irving Underhill)",
    authorOrInstitution: "United States Library of Congress",
    publicationDate: "1921",
    url: "https://commons.wikimedia.org/wiki/File:EquitableTrustBuildingBiltmoreNYC1921.jpg",
    category: "historical_primary",
    relevantClaimKa:
      "ასახავს Warren & Wetmore-ის პროექტით 1913 წელს აგებული H-ის ფორმის სასტუმრო „ბილტმორის“ ისტორიულ არქიტექტურას Terminal City-ის კომპლექსში.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (საჯარო დომენის საარქივო ფოტო)",
  },
  {
    id: "src-shubert-play-1949",
    titleKa: "შუბერტის თეატრის ისტორია და სპექტაკლი „I Know My Love“ (2 ნოემბერი, 1949 – 3 ივნისი, 1950)",
    originalTitle: "Shubert Theatre (225 West 44th Street) — I Know My Love starring Alfred Lunt and Lynn Fontanne",
    authorOrInstitution: "Internet Broadway Database (IBDB) / Shubert Organization History",
    publicationDate: "1949-11-02",
    url: "https://en.wikipedia.org/wiki/Shubert_Theatre_(Broadway)",
    category: "secondary_historical",
    relevantClaimKa:
      "ადასტურებს, რომ ალფრედ ლანტისა და ლინ ფონტენის სპექტაკლი „I Know My Love“ (ს. ნ. ბერმანის პიესა) შუბერტის თეატრში (225 W 44th St) გაიხსნა 1949 წლის 2 ნოემბერს — რაც რომანის მოქმედებას 1949 წლის დეკემბრით ათარიღებს.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (თეატრალური საარქივო ქრონიკა)",
  },
  {
    id: "src-radio-city-loc",
    titleKa: "„რედიო-სითი მიუზიკ-ჰოლი“ და როკფელერ-ცენტრის ისტორია (კონგრესის ბიბლიოთეკა, ს. გოტშოს კოლექცია)",
    originalTitle: "Radio City Music Hall (1260 Sixth Avenue) & Rockefeller Center Skating Pond",
    authorOrInstitution: "Library of Congress (Gottscho-Schleisner Collection) / NYC LPC",
    publicationDate: "1932 / 1978",
    url: "https://commons.wikimedia.org/wiki/File:International_Music_Hall,_Radio_City,_New_York._LOC_gsc.5a02025.jpg",
    category: "historical_primary",
    relevantClaimKa:
      "ადასტურებს 1932 წელს გახსნილი Art Deco-ს დარბაზის არქიტექტურას, 1933 წლიდან მიმდინარე საშობაო სპექტაკლის (Rockettes და შობის სცენა) ტრადიციასა და 1936 წელს გახსნილ საციგურაო მოედანს.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (საარქივო კოლექცია)",
  },
  {
    id: "src-loc-pond-1956",
    titleKa: "აშშ-ის კონგრესის ბიბლიოთეკა — სენტრალ-პარკის სამხრეთის ტბორი და გეპსტოუს ხიდი (ანჯელო რიცუტო)",
    originalTitle: "[View of Central Park's Gapstow Bridge and The Pond], Anthony Angel Collection",
    authorOrInstitution: "United States Library of Congress (item 2020636208)",
    publicationDate: "1956",
    url: "https://www.loc.gov/item/2020636208/",
    category: "historical_primary",
    relevantClaimKa:
      "ასახავს სენტრალ-პარკის სამხრეთ-აღმოსავლეთ კუთხეში (59-ე ქუჩასთან) მდებარე ტბორს (The Pond) და 1896 წლის ქვის ხიდს ზამთარში, მე-20 საუკუნის შუა ხანების მანჰეტენის ფონზე.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (საჯარო დომენის საარქივო ფოტო)",
  },
  {
    id: "src-nyc-parks-carousel",
    titleKa: "ნიუ-იორკის პარკების დეპარტამენტი და Central Park Conservancy — სენტრალ-პარკის კარუსელის ისტორია (1871–1951)",
    originalTitle: "Central Park Carousel (Michael Friedsam Memorial Carousel) Historical Record",
    authorOrInstitution: "NYC Department of Parks & Recreation / Central Park Conservancy",
    publicationDate: "2024",
    url: "https://www.nycgovparks.org/parks/central-park/highlights/12650",
    category: "secondary_historical",
    relevantClaimKa:
      "ადასტურებს კრიტიკულ ისტორიულ ფაქტს: 1924 წლის მესამე კარუსელი (თითბრის/ოქროს რგოლის მექანიზმით, რომელსაც ფიბი სწვდება) 1950 წლის ნოემბერში ხანძარმა გაანადგურა; დღევანდელი კარუსელი (1908 წლის Stein & Goldstein) კონი-აილენდიდან 1951 წელს გადმოიტანეს.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (მუნიციპალური არქივი)",
  },
  {
    id: "src-nyc-parks-zoo-mall",
    titleKa: "ნიუ-იორკის პარკების დეპარტამენტი — სენტრალ-პარკის ხეივანი (The Mall), ტბორი და ზოოპარკი",
    originalTitle: "Central Park Highlights: The Pond, The Mall, and Central Park Zoo (1934 reconstruction)",
    authorOrInstitution: "NYC Department of Parks & Recreation",
    publicationDate: "2024",
    url: "https://www.nycgovparks.org/parks/central-park",
    category: "secondary_historical",
    relevantClaimKa:
      "ადასტურებს ოლმსტედისა და ვოქსის 1858 წლის გეგმარებას, 1923 წლის ნაუმბურგის ესტრადას მოლზე და 1934 წელს ეიმარ ემბერი II-ის პროექტით განახლებულ ზოოპარკს ზღვის ლომების ცენტრალური აუზით.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (მუნიციპალური წყარო)",
  },
  {
    id: "src-amnh-history",
    titleKa: "ამერიკის ბუნების ისტორიის მუზეუმი — ისტორიული ექსპოზიციები და ჰაიდას საბრძოლო კანოე",
    originalTitle: "American Museum of Natural History (200 Central Park West) — Institutional History",
    authorOrInstitution: "American Museum of Natural History",
    publicationDate: "2024",
    url: "https://www.amnh.org/about",
    category: "secondary_historical",
    relevantClaimKa:
      "ადასტურებს მუზეუმის მდებარეობას (Central Park West, 77-ე–81-ე ქუჩები), 18-მეტრიანი ჰაიდას საბრძოლო კანოესა და ჩრდილოეთის ხალხთა ეთნოგრაფიული დიორამების არსებობას მე-20 საუკუნის შუა ხანებში.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (სამუზეუმო არქივი)",
  },
  {
    id: "src-met-perneb",
    titleKa: "ხელოვნების მეტროპოლიტენ-მუზეუმი — მეხუთე ავენიუს შენობა და პერნების ეგვიპტური სამარხი",
    originalTitle: "The Metropolitan Museum of Art (1000 Fifth Avenue) — Egyptian Art & Mastaba Tomb of Perneb",
    authorOrInstitution: "The Metropolitan Museum of Art",
    publicationDate: "2024",
    url: "https://www.metmuseum.org/art/collection/search/543935",
    category: "secondary_historical",
    relevantClaimKa:
      "ადასტურებს მეტროპოლიტენ-მუზეუმის მდებარეობას (1000 Fifth Ave, 82-ე ქუჩა) და 1916 წლიდან გამოფენილ ძველი ეგვიპტური სამარხის (პერნების მასტაბა) ვიწრო ქვის კამერას, რომელიც შეესაბამება 25-ე თავის ეპიზოდს.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (სამუზეუმო კატალოგი)",
  },
  {
    id: "src-grand-central-lpc",
    titleKa: "გრანდ-სენტრალის ტერმინალი — ისტორია და არქიტექტურული დაცვა (1913–დღემდე)",
    originalTitle: "Grand Central Terminal (89 East 42nd Street) — Landmark History",
    authorOrInstitution: "Grand Central Terminal / Metropolitan Transportation Authority (MTA)",
    publicationDate: "2024",
    url: "https://grandcentralterminal.com/history/",
    category: "secondary_historical",
    relevantClaimKa:
      "ადასტურებს Reed & Stem-ისა და Warren & Wetmore-ის 1913 წლის ტერმინალის ისტორიას, მოსაცდელ დარბაზს, ლექსინგტონ-ავენიუს მეტროს კვანძსა და 1978 წლის უზენაესი სასამართლოს გადაწყვეტილებით შენობის გადარჩენას.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (ოფიციალური ინსტიტუციური ისტორია)",
  },
  {
    id: "src-stork-paley",
    titleKa: "„სტორკ-კლუბი“ (1934–1965) და პეილი-პარკის დაარსება აღმოსავლეთ 53-ე ქუჩის №3-ში",
    originalTitle: "Stork Club (3 East 53rd Street) and Paley Park (opened 1967)",
    authorOrInstitution: "The Cultural Landscape Foundation / Wikipedia Archival Summary",
    publicationDate: "2024",
    url: "https://en.wikipedia.org/wiki/Stork_Club",
    category: "secondary_historical",
    relevantClaimKa:
      "ადასტურებს, რომ შერმან ბილინგსლის „სტორკ-კლუბი“ 1934–1965 წლებში მდებარეობდა 3 East 53rd Street-ზე, 1966 წელს დაინგრა და 1967 წელს მის ადგილას გაიხსნა საჯარო ჯიბის პარკი Paley Park.",
    accessedDate: "2026-04",
    reliabilityKa: "მაღალი (გადამოწმებული ურბანული ისტორია)",
  },
  {
    id: "src-salinger-scholarship",
    titleKa: "ლიტერატურათმცოდნეობითი რეკონსტრუქცია — 1949 წლის 17–19 დეკემბრის ქრონოლოგია და გამოგონილი სასტუმროები",
    originalTitle: "Holden's New York & The Catcher in the Rye Chronology (Thomas Beller / Literary Scholarship)",
    authorOrInstitution: "Mr. Beller's Neighborhood / კენეთ სლავენსკის ბიოგრაფიული კვლევა (J. D. Salinger: A Life)",
    publicationDate: "2010 / 2011",
    url: "https://mrbellersneighborhood.com/2010/01/holdens-new-york",
    category: "literary_scholarship",
    relevantClaimKa:
      "განიხილავს სასტუმრო „ედმონტის“, „ერნის“ კლუბისა და „უიკერ-ბარის“ გამოგონილ ბუნებას, სასტუმრო „სეტონის“ (E 40th vs. E 54th) შეუსაბამობასა და 1949 წლის დეკემბრის კალენდარულ რეკონსტრუქციას. (შენიშვნა: ამავე წყაროში დაშვებული უზუსტობა Biltmore Theater-ის შესახებ ჩვენს აუდიტში გასწორებულია).",
    accessedDate: "2026-04",
    reliabilityKa: "საშუალო-მაღალი (გადამოწმებულია პირველად ტექსტთან)",
  },
  {
    id: "src-osm-geo",
    titleKa: "OpenStreetMap და ნიუ-იორკის ქუჩების გეოდეზიური მონაცემთა ბაზა (WGS84)",
    originalTitle: "OpenStreetMap Contributors — Manhattan Street Network, Parks & Building Footprints",
    authorOrInstitution: "OpenStreetMap Foundation & Contributors",
    publicationDate: "2026",
    url: "https://www.openstreetmap.org/copyright",
    category: "geographical",
    relevantClaimKa:
      "უზრუნველყოფს ნიუ-იორკის რეალურ კარტოგრაფიულ საფუძველს, მანჰეტენის ქუჩების გეომეტრიას, პარკების საზღვრებსა და გადამოწმებული ობიექტების WGS84 კოორდინატებს.",
    accessedDate: "2026-04",
    reliabilityKa: "უმაღლესი (ღია გეოდეზიური მონაცემები)",
  },
];

export const AUDIT_ITEMS: AuditItem[] = [
  {
    id: "audit-penn-vs-gct",
    questionKa: "რომელ სადგურში ჩამოდის ჰოლდენი ნიუ-იორკში — გრანდ-სენტრალში თუ პენსილვანიის სადგურში?",
    commonMythKa:
      "ზოგიერთი ონლაინ ლიტერატურული გზამკვლევი შეცდომით წერს, რომ ჰოლდენი პენსი-პრეპიდან გრანდ-სენტრალის სადგურში ჩამოდის.",
    verifiedFindingKa:
      "მე-9 თავის პირველივე წინადადება ცალსახად ასახელებს პენსილვანიის სადგურს (Penn Station), რაც რკინიგზის ისტორიასაც შეესაბამება (პენსილვანიიდან და ტრენტონიდან მატარებლები პენ-სადგურში შემოდიოდა). გრანდ-სენტრალში ჰოლდენი მეორე დილით (თავი 15) და ორშაბათ გამთენიისას (თავი 25) მიდის.",
    resolutionConfidence: "high",
    relatedLocationId: "penn-station",
    sourceIds: ["src-salinger-1951", "src-nps-penn", "src-grand-central-lpc"],
  },
  {
    id: "audit-biltmore-hotel",
    questionKa: "სალი ჰეიზს ჰოლდენი სასტუმრო „ბილტმორში“ ხვდება თუ „ბილტმორის“ თეატრში?",
    commonMythKa:
      "რამდენიმე ესეისტი და ტურისტული ბლოგი ერთმანეთში ურევს ბროდვეის Biltmore Theatre-ს (47-ე ქუჩა) და სასტუმრო New York Biltmore Hotel-ს (43-ე ქუჩა და მედისონ-ავენიუ).",
    verifiedFindingKa:
      "მე-17 თავში ჰოლდენი სალის უნიშნავს შეხვედრას „ბილტმორის საათის ქვეშ“ („under the clock at the Biltmore“) და ჯდება ვესტიბიულის ტყავის დივანზე — ეს არის ლეგენდარული სასტუმრო Biltmore (335 Madison Ave, 1981 წელს გადაკეთებული), საიდანაც შემდეგ ტაქსით მიდიან შუბერტის თეატრში.",
    resolutionConfidence: "high",
    relatedLocationId: "biltmore-hotel",
    sourceIds: ["src-salinger-1951", "src-nytimes-biltmore-1981"],
  },
  {
    id: "audit-carousel-1950",
    questionKa: "არის თუ არა სენტრალ-პარკის დღევანდელი კარუსელი იგივე, რომელზეც ფიბი იჯდა?",
    commonMythKa:
      "თითქმის ყველა ტურისტული საიტი დღევანდელ Friedsam Memorial Carousel-ს უშუალოდ რომანის კარუსელად წარმოაჩენს.",
    verifiedFindingKa:
      "მდებარეობა ზუსტად იგივეა (64-ე–65-ე ქუჩა), მაგრამ თავად მექანიზმი — არა. 1924 წლის კარუსელი, რომელსაც ჰქონდა 25-ე თავში აღწერილი ოქროს/თითბრის რგოლი, 1950 წლის ნოემბერში დაიწვა (მოქმედებიდან 11 თვის შემდეგ, წიგნის გამოცემამდე). დღევანდელი 1908 წლის კარუსელი კონი-აილენდიდან 1951 წელს გადმოიტანეს.",
    resolutionConfidence: "high",
    relatedLocationId: "central-park-carousel",
    sourceIds: ["src-salinger-1951", "src-nyc-parks-carousel"],
  },
  {
    id: "audit-edmont-fictional",
    questionKa: "შესაძლებელია თუ არა სასტუმრო „ედმონტის“ ზუსტი მისამართისა და კოორდინატის დადგენა?",
    commonMythKa:
      "სამოყვარულო რუკები „ედმონტს“ თვითნებურად სვამენ ხან 34-ე ქუჩისა და მე-8 ავენიუს კუთხეში, ხან 130 West 57th Street-ზე.",
    verifiedFindingKa:
      "სასტუმრო „ედმონტი“ და მისი „ლავენდერ რუმი“ სელინჯერის გამოგონილი ობიექტია. ერთადერთი სივრცითი მინიშნება მე-13 თავის „41 კვარტალია“ გრინვიჩ-ვილიჯიდან ჩრდილოეთით (რაც 45-ე–55-ე ქუჩების მიდთაუნზე მიუთითებს). ჩვენს ატლასში მას ყალბი კოორდინატი არ ენიჭება.",
    resolutionConfidence: "unverified",
    relatedLocationId: "edmont-hotel",
    sourceIds: ["src-salinger-1951", "src-salinger-scholarship"],
  },
  {
    id: "audit-wicker-bar-seton",
    questionKa: "არსებობდა თუ არა „უიკერ-ბარი“ აღმოსავლეთ მე-40 ქუჩის რეალურ სასტუმრო „სეტონში“?",
    commonMythKa:
      "რადგან 144 East 40th Street-ზე დღემდე არსებობს სასტუმრო Seton Hotel, ბევრი მკითხველი იქ ეძებს „უიკერ-ბარს“.",
    verifiedFindingKa:
      "რომანში (თავები 18–20) „უიკერ-ბარი“ მდებარეობს „მდიდრულ“ სასტუმრო „სეტონში“ აღმოსავლეთ 54-ე ქუჩაზე და იქ ფრანგი დუეტი უკრავს. მე-40 ქუჩის მოკრძალებულ Seton Hotel-ში ასეთი ბარი არ დასტურდება; მკვლევრები სავარაუდო პროტოტიპად 54-ე ქუჩის Weylin Bar-ს (40 E 54th St) მიიჩნევენ. აღნიშნულია საშუალო სანდოობით.",
    resolutionConfidence: "medium",
    relatedLocationId: "wicker-bar-seton",
    sourceIds: ["src-salinger-1951", "src-salinger-scholarship"],
  },
  {
    id: "audit-amnh-entry",
    questionKa: "შედის თუ არა ჰოლდენი ბუნების ისტორიის მუზეუმში კვირა შუადღეს?",
    commonMythKa:
      "მოკლე შინაარსებში ხშირად წერია, რომ ჰოლდენი კვირას სტუმრობს ბუნების ისტორიის მუზეუმის დარბაზებს.",
    verifiedFindingKa:
      "მე-16 თავში ჰოლდენი დეტალურად იხსენებს მუზეუმის ექსპონატებს ბავშვობის ექსკურსიებიდან, მთელ პარკს ფეხით გადაჭრის და შენობის შესასვლელთან მიდის, მაგრამ უეცრად შესვლის ხალისი უქრება და გარედანვე ტაქსის აჩერებს. ამიტომ მისი სტატუსია „გარედან დანახული“ (კატეგორია C) და არა შიგნით შესული.",
    resolutionConfidence: "high",
    relatedLocationId: "museum-of-natural-history",
    sourceIds: ["src-salinger-1951", "src-amnh-history"],
  },
];

export const LITERARY_THEMES: LiteraryTheme[] = [
  {
    id: "theme-accommodation",
    number: "01",
    titleKa: "დროებითი თავშესაფრები და სასტუმროს უცხოობა",
    subtitleKa: "გაქცევა საკუთარ ქალაქში: „ედმონტიდან“ გრანდ-სენტრალის სკამამდე",
    factualBasisKa:
      "პენსი-პრეპიდან ოთხშაბათამდე გამოპარული 16 წლის ჰოლდენი საკუთარი მშობლების კომფორტულ ბინაში ვერ ბრუნდება და შაბათ ღამეს გამოგონილ სასტუმრო „ედმონტში“ ჩერდება (თავები 9–15). კვირა ღამეს ის ჯერ ფარულად იპარება მშობლების ბინაში (თავები 21–23), შემდეგ მისტერ ანტოლინისთან სატონ-პლეისზე მიდის (თავი 24), ბოლოს კი ორშაბათ გამთენიას გრანდ-სენტრალის მოსაცდელი დარბაზის ხის სკამზე ათევს (თავი 25).",
    literaryInterpretationKa:
      "ლიტერატურული ინტერპრეტაცია: ჰოლდენის საცხოვრებელი სივრცეები 48 საათის განმავლობაში თანდათან ვიწროვდება და უსაფრთხოებას კარგავს — ანონიმური სასტუმროს ნომერი (სადაც მორისის ძალადობას ეჯახება), მშობლების კარადაში დამალვა, მენტორის ბინიდან პანიკური გაქცევა და ბოლოს სადგურის საჯარო სკამი. ნიუ-იორკი მისთვის ერთდროულად მშობლიური სახლიცაა და მიუსაფრობის ლაბირინთიც.",
    relatedLocationIds: [
      "edmont-hotel",
      "caulfield-apartment",
      "antolini-sutton-place",
      "grand-central-terminal",
    ],
    chapters: "თავები 9–15, 21–25",
  },
  {
    id: "theme-nightlife",
    number: "02",
    titleKa: "ღამის ცხოვრება, ჯაზი და „სიყალბის“ თეატრი",
    subtitleKa: "„ლავენდერ რუმი“, „ერნის“ კლუბი და 54-ე ქუჩის „უიკერ-ბარი“",
    factualBasisKa:
      "ორ ღამეში ჰოლდენი სამ სხვადასხვა ბარსა და ღამის კლუბს სტუმრობს: „ედმონტის“ უღიმღამო „ლავენდერ რუმს“ (სადაც არასრულწლოვანს ალკოჰოლს არ აძლევენ, თავი 10), გრინვიჩ-ვილიჯის გადაჭედილ ჯაზ-კლუბ „ერნის“ (თავი 12) და სასტუმრო „სეტონის“ ელეგანტურ „უიკერ-ბარს“ (თავები 19–20), სადაც ვისკით მძიმედ თვრება. პარალელურად იხსენიება ელიტური „სტორკ-კლუბი“.",
    literaryInterpretationKa:
      "ლიტერატურული ინტერპრეტაცია: ომისშემდგომი მანჰეტენის კაფე-საზოგადოება ჰოლდენს ზრდასრულობის ნიღაბს სთავაზობს, მაგრამ ყოველი დარბაზი მის გაუცხოებას აღრმავებს. ის აღმერთებს ერნის დაკვრას, მაგრამ ვერ იტანს აპლოდისმენტებზე გათვლილ ვირტუოზულობას — ხელოვნების კომერციალიზაცია მისთვის იგივე ტკივილია, რაც უფროსი ძმის, დ. ბ.-ის ჰოლივუდში წასვლა.",
    relatedLocationIds: [
      "edmont-hotel",
      "ernies-nightclub",
      "wicker-bar-seton",
      "stork-club",
    ],
    chapters: "თავები 10, 12, 19–20",
  },
  {
    id: "theme-encounters",
    number: "03",
    titleKa: "სოციალური შეხვედრები და გაწყვეტილი დიალოგები",
    subtitleKa: "სატელეფონო ჯიხურები, ტაქსის მძღოლები, მონაზვნები, სალი და ფიბი",
    factualBasisKa:
      "პენ-სადგურის სატელეფონო ჯიხურიდან დაწყებული (თავი 9), ჰოლდენი მუდმივად ეძებს თანამოსაუბრეს: ეკამათება ტაქსის მძღოლებს იხვების ბედზე (თავები 9, 12), უხერხულად ესაუბრება სანის (თავი 13), გულწრფელად საუბრობს „რომეო და ჯულიეტაზე“ ჩიკაგოელ მონაზვნებთან გრანდ-სენტრალთან (თავი 15), ხვდება სალი ჰეიზს „ბილტმორში“ (თავი 17), კარლ ლუსს „უიკერ-ბარში“ (თავი 19) და ბოლოს — ათი წლის დას, ფიბის (თავები 21–23, 25).",
    literaryInterpretationKa:
      "ლიტერატურული ინტერპრეტაცია: თითქმის ყველა შეხვედრა უფროსებთან ან თანატოლებთან კომუნიკაციური მარცხით სრულდება, რადგან ჰოლდენი ერთდროულად ითხოვს სრულ სიახლოვეს და თავდაცვითი ცინიზმით იგერიებს ადამიანებს. გამონაკლისია ორი მონაზონი, შემთხვევითი ბავშვები და ფიბი — ერთადერთი ადამიანი, რომელიც ჰოლდენს უპირობოდ უსმენს და თან სიმართლესაც პირდაპირ ეუბნება.",
    relatedLocationIds: [
      "penn-station",
      "grand-central-terminal",
      "biltmore-hotel",
      "caulfield-apartment",
    ],
    chapters: "თავები 9, 12–13, 15, 17, 19, 21–25",
  },
  {
    id: "theme-wandering",
    number: "04",
    titleKa: "ზამთრის ხეტიალი და სენტრალ-პარკის იხვები",
    subtitleKa: "41 კვარტალი ღამით, გაყინული ტბორი და მეხუთე ავენიუს გზაჯვარედინები",
    factualBasisKa:
      "ჰოლდენი მანჰეტენს არა რაციონალური მარშრუტით, არამედ ემოციური იმპულსებით კვეთს: ღამით ფეხით გადის 41 კვარტალს გრინვიჩ-ვილიჯიდან მიდთაუნამდე (თავი 13), კვირას კვეთს ბროდვეისა და სენტრალ-პარკის მოლს (თავი 16), კვირა შუაღამეს ნასვამი ეძებს იხვებს სენტრალ-პარკის სამხრეთის ტბორთან (თავი 20), ხოლო ორშაბათ დილით მიუყვება საშობაოდ მორთულ მეხუთე ავენიუს (თავი 25).",
    literaryInterpretationKa:
      "ლიტერატურული ინტერპრეტაცია: კითხვა — „სად მიდიან იხვები, როცა ტბორი იყინება?“ — ლიტერატურათმცოდნეობაში განიხილება როგორც გარდამავალი ასაკის, გადარჩენისა და უმცროსი ძმის, ალის გარდაცვალებით გამოწვეული დაუცველობის მეტაფორა. მეხუთე ავენიუს ყოველ ტროტუართან „გაქრობის“ შიში კი მიანიშნებს, როგორ იქცევა მანჰეტენის მკაცრი ქუჩათა ბადე ჰოლდენის შინაგანი კრიზისის რუკად.",
    relatedLocationIds: [
      "central-park-pond",
      "central-park-mall",
      "fifth-avenue-walk",
      "broadway-record-district",
    ],
    chapters: "თავები 9, 12–13, 16, 20, 25",
  },
  {
    id: "theme-culture",
    number: "05",
    titleKa: "მუზეუმები, თეატრები და დროის გაჩერების სურვილი",
    subtitleKa: "მინის ვიტრინებიდან წვიმიან კარუსელამდე",
    factualBasisKa:
      "ჰოლდენის მარშრუტი მანჰეტენის უმთავრეს კულტურულ ინსტიტუციებს მოიცავს: შუბერტის თეატრს ბროდვეიზე (თავი 17), როკფელერ-ცენტრის საციგურაო მოედანს (თავი 17), „რედიო-სითი მიუზიკ-ჰოლს“ (თავი 18), ამერიკის ბუნების ისტორიის მუზეუმს (თავი 16), მეტროპოლიტენ-მუზეუმის ეგვიპტურ დარბაზს (თავი 25) და სენტრალ-პარკის ზოოპარკსა და კარუსელს (თავი 25).",
    literaryInterpretationKa:
      "ლიტერატურული ინტერპრეტაცია: რომანში მკვეთრი კონტრასტია კომერციულ სანახაობასა (ბროდვეი, რედიო-სითი) და მუზეუმების მდუმარე მარადიულობას შორის. ჰოლდენს სურს სამყარო ბუნების ისტორიის მუზეუმის ვიტრინასავით უცვლელი დარჩეს, მაგრამ ეგვიპტურ სამარხშიც კი უხამსი წარწერა ხვდება. მხოლოდ კარუსელთან, წვიმაში, აღიარებს იგი, რომ მოძრაობისა და რისკის შეჩერება შეუძლებელია.",
    relatedLocationIds: [
      "museum-of-natural-history",
      "metropolitan-museum",
      "shubert-theatre",
      "radio-city-music-hall",
      "rockefeller-center-rink",
      "central-park-carousel",
    ],
    chapters: "თავები 16–18, 25",
  },
  {
    id: "theme-isolation",
    number: "06",
    titleKa: "მარტოობა სადღესასწაულო მეგაპოლისში",
    subtitleKa: "საშობაო მანჰეტენის ბრწყინვალება და გლოვის უხილავი გეოგრაფია",
    factualBasisKa:
      "მოქმედება შობის წინა დღეებში ვითარდება: მეხუთე ავენიუზე სანტა-კლაუსები დგანან, „რედიო-სითიში“ საშობაო წარმოდგენა იმართება, ქუჩები საჩუქრებით დატვირთული ხალხითაა სავსე, ფიბის სკოლაში საშობაო არდადეგები იწყება, ხოლო ჰოლდენი დასავლეთში გაქცევასა და ჰოლანდის გვირაბით ქალაქის დატოვებაზე ოცნებობს (თავი 25).",
    literaryInterpretationKa:
      "ლიტერატურული ინტერპრეტაცია: 1949 წლის დეკემბრის სადღესასწაულო ეიფორია ამძაფრებს ჰოლდენის გამოუთქმელ გლოვას ლეიკემიით გარდაცვლილი ძმის, ალის მიმართ. აღსანიშნავია, რომ ეს ფსიქოლოგიური წაკითხვა ლიტერატურული ანალიზია და არა ტექსტში პირდაპირ დასმული დიაგნოზი; თავად სელინჯერი მკითხველს საშუალებას აძლევს, ჰოლდენის ტკივილი მის დაუღალავ, წრიულ სიარულში ამოიკითხოს.",
    relatedLocationIds: [
      "fifth-avenue-walk",
      "phoebes-school",
      "central-park-zoo",
      "holland-tunnel",
      "lexington-ave-subway",
    ],
    chapters: "თავები 1, 18, 20, 22, 25–26",
  },
];

export const INITIAL_READER_NOTES = [
  {
    locationId: "penn-station",
    authorName: "ნინო მაჭავარიანი",
    authorRole: "ლიტერატურის მკვლევარი",
    noteType: "historical",
    content:
      "საოცარია, რომ 1949 წელს პენ-სადგურში ჩამოსული ჰოლდენი რომაული თერმების მასშტაბის ვარდისფერი გრანიტის დარბაზში იდგა, მაგრამ მისთვის მთელი ეს დიდებულება ერთ ჩაკეტილ სატელეფონო ჯიხურამდე დავიწროვდა.",
    chapterRef: "თავი 9",
  },
  {
    locationId: "central-park-pond",
    authorName: "გიორგი ბერიძე",
    authorRole: "ურბანული ისტორიკოსი",
    noteType: "geographical",
    content:
      "ჰოლდენი ამ წყალსატევს „ლაგუნას“ (lagoon) უწოდებს, თუმცა ოლმსტედისა და ვოქსის ოფიციალურ რუკებზე მას The Pond ჰქვია. მეხუთე ავენიუსა და 59-ე ქუჩის კუთხიდან სულ ორი წუთის სავალზეა.",
    chapterRef: "თავები 9, 12, 20",
  },
  {
    locationId: "shubert-theatre",
    authorName: "თამარ კვარაცხელია",
    authorRole: "თეატრმცოდნე",
    noteType: "historical",
    content:
      "საინტერესო საარქივო დამთხვევაა: 1949 წლის „I Know My Love“-ის დასში მეორეხარისხოვან როლს მსახიობი ბეტი კოლფილდი (Betty Caulfield) ასრულებდა, თუმცა სელინჯერს გვარი Caulfield უფრო ადრინდელ მოთხრობებშიც ჰქონდა გამოყენებული.",
    chapterRef: "თავები 16–17",
  },
  {
    locationId: "central-park-carousel",
    authorName: "დავით ჩხეიძე",
    authorRole: "მკითხველი",
    noteType: "literary",
    content:
      "ვახტანგ ჭელიძის ქართულ თარგმანში კარუსელის ფინალური სცენა განსაკუთრებული სისადავითა და სითბოთი იკითხება — წითელი სანადირო ქუდი აქ ხდება ფიბისა და ჰოლდენის შერიგების ნიშანი.",
    chapterRef: "თავი 25",
  },
];
