"use client";

import { useMemo, useState } from "react";
import {
  Columns2,
  SlidersHorizontal,
  MapPin,
  ExternalLink,
  Camera,
} from "lucide-react";
import {
  type AtlasLocation,
  HISTORICAL_STATUS_META,
  CONFIDENCE_META,
} from "@/lib/types";

interface ThenNowSliderProps {
  locations: AtlasLocation[];
  onFocusOnMap: (locationId: string) => void;
  onOpenDetail: (locationId: string) => void;
}

export default function ThenNowSlider({
  locations,
  onFocusOnMap,
  onOpenDetail,
}: ThenNowSliderProps) {
  const comparableLocations = useMemo(
    () => locations.filter((l) => l.thenNow !== null),
    [locations]
  );

  const [selectedId, setSelectedId] = useState<string>(
    comparableLocations[0]?.id ?? "penn-station"
  );
  const [sliderPos, setSliderPos] = useState<number>(52);
  const [viewMode, setViewMode] = useState<"slider" | "side">("slider");

  const active =
    comparableLocations.find((l) => l.id === selectedId) ??
    comparableLocations[0];

  if (!active || !active.thenNow) return null;

  const histImg = active.images.find((i) => i.era === "historical") ?? null;
  const modImg = active.images.find((i) => i.era === "modern") ?? null;
  const hasBothImages = Boolean(histImg && modImg);
  const singleImg = histImg ?? modImg;
  const histStatus = HISTORICAL_STATUS_META[active.historicalStatus];
  const confMeta = CONFIDENCE_META[active.confidence];
  const tn = active.thenNow;

  const tableRows = [
    {
      label: "სახელწოდება",
      then: tn.historicalName,
      now: tn.modernName,
    },
    {
      label: "არქიტექტურული იერსახე",
      then: tn.historicalAppearance,
      now: tn.modernAppearance,
    },
    {
      label: "დანიშნულება",
      then: tn.historicalFunction,
      now: tn.modernFunction,
    },
    {
      label: "მისამართი",
      then: tn.historicalAddress,
      now: tn.modernAddress,
    },
    {
      label: "კულტურული მნიშვნელობა",
      then: tn.historicalSignificance,
      now: tn.modernSignificance,
    },
  ];

  return (
    <section
      id="then-and-now"
      className="py-16 sm:py-20 bg-[#EFE9DC]/75 border-y border-[#DDD5C7]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#7A1F2B]">
            ისტორიული შედარება · 1949 და დღევანდელობა
          </p>
          <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#1F1D1A] tracking-tight">
            მაშინ და ახლა: როგორ შეიცვალა ჰოლდენის მანჰეტენი
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#57524A] leading-relaxed">
            შეადარეთ რომანის ეპოქის (1949 წლის დეკემბერი) დოკუმენტირებული ნიუ-იორკი თანამედროვე ქალაქს. სადაც საჯარო დომენის საარქივო და თანამედროვე ფოტოწყვილი დასტურდება, ხელმისაწვდომია ინტერაქტიული სლაიდერი.
          </p>
        </div>

        {/* Location selector pills */}
        <div className="mt-7 flex flex-wrap gap-2" role="tablist" aria-label="შესადარებელი ლოკაციები">
          {comparableLocations.map((loc) => {
            const isSelected = loc.id === active.id;
            const pairBadge =
              loc.images.some((i) => i.era === "historical") &&
              loc.images.some((i) => i.era === "modern");
            const st = HISTORICAL_STATUS_META[loc.historicalStatus];
            return (
              <button
                key={loc.id}
                type="button"
                role="tab"
                aria-selected={isSelected}
                onClick={() => setSelectedId(loc.id)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md text-xs sm:text-sm font-medium border transition ${
                  isSelected
                    ? "bg-[#7A1F2B] text-[#FDFBF7] border-[#7A1F2B] shadow-sm"
                    : "bg-[#FDFBF7] text-[#1F1D1A] border-[#D5CCBC] hover:border-[#7A1F2B]/50 hover:bg-[#FDFBF7]"
                }`}
              >
                <span className="font-mono text-[11px] opacity-80">{st.symbol}</span>
                <span>{loc.nameKa.split(" (")[0]}</span>
                {pairBadge && (
                  <Camera
                    className={`w-3.5 h-3.5 ${
                      isSelected ? "text-[#FDFBF7]/90" : "text-[#7A1F2B]"
                    }`}
                    aria-label="საარქივო და თანამედროვე ფოტოწყვილი"
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Active comparison card */}
        <div className="mt-6 bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl shadow-sm overflow-hidden">
          <div className="p-5 sm:p-6 border-b border-[#DDD5C7] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-medium border ${histStatus.badgeClass}`}
                >
                  <span>{histStatus.symbol}</span>
                  <span>{histStatus.labelKa}</span>
                </span>
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-medium border ${confMeta.badgeClass}`}
                >
                  <span>{confMeta.symbol}</span>
                  <span>{confMeta.labelKa}</span>
                </span>
                <span className="text-xs text-[#57524A] font-mono">
                  თავი {active.chapters.join(", ")}
                </span>
              </div>
              <h3 className="mt-2 font-serif text-2xl font-bold text-[#1F1D1A]">
                {active.nameKa}
              </h3>
              <p className="text-xs sm:text-sm text-[#57524A]">
                {active.nameEn} · {active.neighborhoodKa}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {hasBothImages && (
                <div className="inline-flex rounded-md border border-[#D5CCBC] bg-[#F7F3EB] p-0.5">
                  <button
                    type="button"
                    onClick={() => setViewMode("slider")}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition ${
                      viewMode === "slider"
                        ? "bg-[#243447] text-[#FDFBF7]"
                        : "text-[#57524A] hover:text-[#1F1D1A]"
                    }`}
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    სლაიდერი
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode("side")}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition ${
                      viewMode === "side"
                        ? "bg-[#243447] text-[#FDFBF7]"
                        : "text-[#57524A] hover:text-[#1F1D1A]"
                    }`}
                  >
                    <Columns2 className="w-3.5 h-3.5" />
                    გვერდიგვერდ
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={() => onFocusOnMap(active.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-[#F7F3EB] text-[#1F1D1A] border border-[#C9BFAE] hover:border-[#7A1F2B] hover:text-[#7A1F2B] transition"
              >
                <MapPin className="w-3.5 h-3.5" />
                რუკაზე ნახვა
              </button>
              <button
                type="button"
                onClick={() => onOpenDetail(active.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-[#7A1F2B] text-[#FDFBF7] hover:bg-[#5E1620] transition"
              >
                სრული დოსიე
              </button>
            </div>
          </div>

          {/* Visual Comparison Area */}
          {hasBothImages && histImg && modImg ? (
            <div className="p-5 sm:p-6 bg-[#F7F3EB]/60 border-b border-[#DDD5C7]">
              {viewMode === "slider" ? (
                <div>
                  <div className="relative w-full aspect-[16/9] max-h-[480px] rounded-lg overflow-hidden border border-[#C9BFAE] bg-[#1F1D1A] select-none">
                    {/* Modern photo underneath */}
                    <img
                      src={modImg.url}
                      alt={modImg.titleKa}
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    {/* Historical photo clipped on left */}
                    <div
                      className="absolute inset-0 overflow-hidden"
                      style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
                    >
                      <img
                        src={histImg.url}
                        alt={histImg.titleKa}
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    </div>

                    {/* Vertical divider */}
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-[#FDFBF7] shadow-[0_0_10px_rgba(0,0,0,0.6)] pointer-events-none"
                      style={{ left: `${sliderPos}%` }}
                    >
                      <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-[#7A1F2B] text-[#FDFBF7] border-2 border-[#FDFBF7] shadow-lg flex items-center justify-center text-xs font-bold">
                        ⇄
                      </div>
                    </div>

                    {/* Era badges */}
                    <span className="absolute top-3 left-3 px-2.5 py-1 rounded bg-[#1F1D1A]/85 text-[#FDFBF7] text-xs font-medium backdrop-blur-sm">
                      მაშინ · {histImg.dateLabel}
                    </span>
                    <span className="absolute top-3 right-3 px-2.5 py-1 rounded bg-[#243447]/85 text-[#FDFBF7] text-xs font-medium backdrop-blur-sm">
                      ახლა · {modImg.dateLabel}
                    </span>

                    {/* Accessible range slider overlay */}
                    <input
                      type="range"
                      min={5}
                      max={95}
                      value={sliderPos}
                      onChange={(e) => setSliderPos(Number(e.target.value))}
                      aria-label="ისტორიული და თანამედროვე ფოტოს შედარების სლაიდერი"
                      className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
                    />
                  </div>

                  {/* Archival attributions below */}
                  <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-[#57524A]">
                    <div className="bg-[#FDFBF7] border border-[#DDD5C7] rounded-md p-3">
                      <p className="font-semibold text-[#1F1D1A]">
                        საარქივო კადრი ({histImg.dateLabel}): {histImg.titleKa}
                      </p>
                      <p className="mt-1 leading-relaxed">{histImg.captionKa}</p>
                      <p className="mt-1.5 text-[11px]">
                        ავტორი: {histImg.creator} · {histImg.institution} · {histImg.license} ·{" "}
                        <a
                          href={histImg.sourceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[#7A1F2B] underline inline-flex items-center gap-0.5"
                        >
                          წყარო <ExternalLink className="w-3 h-3" />
                        </a>
                      </p>
                    </div>
                    <div className="bg-[#FDFBF7] border border-[#DDD5C7] rounded-md p-3">
                      <p className="font-semibold text-[#1F1D1A]">
                        თანამედროვე კადრი ({modImg.dateLabel}): {modImg.titleKa}
                      </p>
                      <p className="mt-1 leading-relaxed">{modImg.captionKa}</p>
                      <p className="mt-1.5 text-[11px]">
                        ავტორი: {modImg.creator} · {modImg.institution} · {modImg.license} ·{" "}
                        <a
                          href={modImg.sourceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[#7A1F2B] underline inline-flex items-center gap-0.5"
                        >
                          წყარო <ExternalLink className="w-3 h-3" />
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[histImg, modImg].map((img) => (
                    <figure
                      key={img.id}
                      className="bg-[#FDFBF7] border border-[#DDD5C7] rounded-lg overflow-hidden"
                    >
                      <div className="relative aspect-[4/3] bg-[#1F1D1A]">
                        <img
                          src={img.url}
                          alt={img.titleKa}
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded bg-[#1F1D1A]/85 text-[#FDFBF7] text-xs font-medium">
                          {img.era === "historical" ? "მაშინ" : "ახლა"} · {img.dateLabel}
                        </span>
                      </div>
                      <figcaption className="p-3 text-xs text-[#57524A]">
                        <p className="font-semibold text-[#1F1D1A]">{img.titleKa}</p>
                        <p className="mt-1">{img.captionKa}</p>
                        <p className="mt-1 text-[11px]">
                          {img.creator} · {img.institution} ({img.license})
                        </p>
                      </figcaption>
                    </figure>
                  ))}
                </div>
              )}
            </div>
          ) : singleImg ? (
            <div className="p-5 sm:p-6 bg-[#F7F3EB]/60 border-b border-[#DDD5C7] grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
              <div className="lg:col-span-7 relative aspect-[16/10] rounded-lg overflow-hidden border border-[#C9BFAE] bg-[#1F1D1A]">
                <img
                  src={singleImg.url}
                  alt={singleImg.titleKa}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-3 left-3 px-2.5 py-1 rounded bg-[#1F1D1A]/85 text-[#FDFBF7] text-xs font-medium">
                  {singleImg.era === "historical"
                    ? `საარქივო ფოტო · ${singleImg.dateLabel}`
                    : `დოკუმენტური ფოტო · ${singleImg.dateLabel}`}
                </span>
              </div>
              <div className="lg:col-span-5 space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-[#7A1F2B]">
                  რა შეიცვალა 1949 წლის შემდეგ
                </p>
                <p className="text-sm text-[#1F1D1A] leading-relaxed font-medium">
                  {tn.whatChanged}
                </p>
                <div className="pt-2 border-t border-[#DDD5C7] text-xs text-[#57524A]">
                  <p className="font-semibold text-[#1F1D1A]">{singleImg.titleKa}</p>
                  <p className="mt-1">{singleImg.captionKa}</p>
                  <p className="mt-1.5 text-[11px]">
                    {singleImg.creator} · {singleImg.institution} · {singleImg.license} ·{" "}
                    <a
                      href={singleImg.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#7A1F2B] underline inline-flex items-center gap-0.5"
                    >
                      წყარო <ExternalLink className="w-3 h-3" />
                    </a>
                  </p>
                </div>
              </div>
            </div>
          ) : null}

          {/* Structured Then vs. Now Comparison Table */}
          <div className="p-5 sm:p-6">
            {hasBothImages && (
              <div className="mb-5 p-4 rounded-lg bg-[#7A1F2B]/[0.06] border border-[#7A1F2B]/20">
                <p className="text-xs font-semibold uppercase tracking-wider text-[#7A1F2B]">
                  მთავარი ისტორიული ცვლილება
                </p>
                <p className="mt-1 text-sm text-[#1F1D1A] leading-relaxed">
                  {tn.whatChanged}
                </p>
              </div>
            )}

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b-2 border-[#D5CCBC] text-xs uppercase tracking-wider text-[#57524A]">
                    <th className="py-2.5 pr-4 w-44 font-semibold">პარამეტრი</th>
                    <th className="py-2.5 px-4 font-semibold text-[#7A1F2B]">
                      ისტორიული ნიუ-იორკი (1949)
                    </th>
                    <th className="py-2.5 pl-4 font-semibold text-[#243447]">
                      თანამედროვე ნიუ-იორკი (დღეს)
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5DEC9]">
                  {tableRows.map((row) => (
                    <tr key={row.label} className="align-top">
                      <td className="py-3 pr-4 text-xs font-semibold text-[#57524A]">
                        {row.label}
                      </td>
                      <td className="py-3 px-4 text-xs sm:text-sm text-[#1F1D1A] leading-relaxed">
                        {row.then}
                      </td>
                      <td className="py-3 pl-4 text-xs sm:text-sm text-[#1F1D1A] leading-relaxed">
                        {row.now}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
