"use client";

import { useState } from "react";
import Link from "next/link";
import {
  MapPin,
  BookOpen,
  Users,
  Clock,
  ShieldCheck,
  ExternalLink,
  MessageSquarePlus,
  Trash2,
  Send,
  ArrowUpRight,
} from "lucide-react";
import {
  type AtlasLocation,
  type ChronologicalEvent,
  type ResearchSource,
  type StoryCharacter,
  type ReaderNote,
  CATEGORY_META,
  LITERARY_STATUS_META,
  HISTORICAL_STATUS_META,
  CONFIDENCE_META,
  SOURCE_CATEGORY_META,
} from "@/lib/types";

const NOTE_TYPE_LABELS: Record<ReaderNote["noteType"], string> = {
  literary: "ლიტერატურული დაკვირვება",
  historical: "ისტორიული კონტექსტი",
  geographical: "გეოგრაფიული შენიშვნა",
};

interface LocationDossierContentProps {
  location: AtlasLocation;
  events: ChronologicalEvent[];
  characters: StoryCharacter[];
  sources: ResearchSource[];
  notes: ReaderNote[];
  onNoteCreated?: (note: ReaderNote) => void;
  onNoteDeleted?: (noteId: number) => void;
  onFocusOnMap?: (locationId: string) => void;
  onSelectCharacter?: (characterId: string) => void;
  showStandaloneLink?: boolean;
}

export default function LocationDossierContent({
  location,
  events,
  characters,
  sources,
  notes,
  onNoteCreated,
  onNoteDeleted,
  onFocusOnMap,
  onSelectCharacter,
  showStandaloneLink = false,
}: LocationDossierContentProps) {
  const [localNotes, setLocalNotes] = useState<ReaderNote[]>(notes);
  const [authorName, setAuthorName] = useState("");
  const [authorRole, setAuthorRole] = useState("მკითხველი");
  const [noteType, setNoteType] = useState<ReaderNote["noteType"]>("literary");
  const [chapterRef, setChapterRef] = useState(
    location.chapters.length > 0 ? `თავი ${location.chapters[0]}` : ""
  );
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  const displayNotes = onNoteCreated ? notes : localNotes;
  const locationNotes = displayNotes.filter((n) => n.locationId === location.id);

  const cat = CATEGORY_META[location.category];
  const lit = LITERARY_STATUS_META[location.literaryStatus];
  const hist = HISTORICAL_STATUS_META[location.historicalStatus];
  const conf = CONFIDENCE_META[location.confidence];

  const relatedEvents = events.filter((e) => e.locationId === location.id);
  const relatedCharacters = characters.filter((c) =>
    location.characterIds.includes(c.id)
  );
  const relatedSources = sources.filter((s) =>
    location.sourceIds.includes(s.id)
  );

  const handleSubmitNote = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(null);
    setSubmitting(true);

    try {
      const res = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          locationId: location.id,
          authorName,
          authorRole,
          noteType,
          chapterRef,
          content,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFormError(data.error || "შენახვა ვერ მოხერხდა.");
      } else if (data.note) {
        if (onNoteCreated) {
          onNoteCreated(data.note);
        } else {
          setLocalNotes((prev) => [data.note, ...prev]);
        }
        setAuthorName("");
        setContent("");
        setFormSuccess("ჩანაწერი წარმატებით შეინახა ატლასის არქივში.");
      }
    } catch {
      setFormError("სერვერთან კავშირი ვერ დამყარდა.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteNote = async (noteId: number) => {
    try {
      const res = await fetch(`/api/notes/${noteId}`, { method: "DELETE" });
      if (res.ok) {
        if (onNoteDeleted) {
          onNoteDeleted(noteId);
        } else {
          setLocalNotes((prev) => prev.filter((n) => n.id !== noteId));
        }
      }
    } catch {
      // Ignore transient failure
    }
  };

  return (
    <div className="space-y-7">
      {/* Header metadata & badges */}
      <div>
        <div className="flex flex-wrap items-center gap-2">
          <span
            className="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-semibold text-[#FDFBF7]"
            style={{ backgroundColor: cat.color }}
          >
            {cat.labelKa}
          </span>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-medium bg-[#EFE9DC] text-[#1F1D1A] border border-[#D5CCBC]">
            კატეგორია {lit.code}: {lit.labelKa}
          </span>
          <span
            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-medium border ${hist.badgeClass}`}
          >
            <span>{hist.symbol}</span>
            <span>{hist.labelKa}</span>
          </span>
          <span
            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-medium border ${conf.badgeClass}`}
          >
            <span>{conf.symbol}</span>
            <span>{conf.labelKa}</span>
          </span>
        </div>

        <h2 className="mt-3 font-serif text-2xl sm:text-3xl font-bold text-[#1F1D1A] leading-tight">
          {location.nameKa}
        </h2>
        <p className="mt-1 text-sm text-[#57524A]">
          ინგლისური სახელწოდება: <span className="font-medium text-[#1F1D1A]">{location.nameEn}</span> ·
          რომანში: <span className="italic">„{location.novelNameEn}“</span>
        </p>

        <div className="mt-4 flex flex-wrap gap-2.5">
          {onFocusOnMap && location.latitude !== null && (
            <button
              type="button"
              onClick={() => onFocusOnMap(location.id)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md text-xs font-semibold bg-[#7A1F2B] text-[#FDFBF7] hover:bg-[#5E1620] transition"
            >
              <MapPin className="w-3.5 h-3.5" />
              ფოკუსირება ნიუ-იორკის რუკაზე
            </button>
          )}
          {showStandaloneLink && (
            <Link
              href={`/locations/${location.id}`}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md text-xs font-semibold bg-[#F7F3EB] text-[#1F1D1A] border border-[#C9BFAE] hover:border-[#243447] transition"
            >
              ცალკე საარქივო გვერდის გახსნა
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          )}
        </div>
      </div>

      {/* Geographical Info Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-[#F7F3EB] border border-[#DDD5C7] rounded-lg p-4 text-xs">
        <div>
          <p className="font-semibold text-[#57524A] uppercase tracking-wider text-[10.5px]">
            ისტორიული მისამართი (1949)
          </p>
          <p className="mt-1 text-[#1F1D1A] leading-snug font-medium">
            {location.historicalAddress}
          </p>
        </div>
        <div>
          <p className="font-semibold text-[#57524A] uppercase tracking-wider text-[10.5px]">
            თანამედროვე მისამართი
          </p>
          <p className="mt-1 text-[#1F1D1A] leading-snug font-medium">
            {location.modernAddress}
          </p>
        </div>
        <div>
          <p className="font-semibold text-[#57524A] uppercase tracking-wider text-[10.5px]">
            უბანი და რაიონი
          </p>
          <p className="mt-1 text-[#1F1D1A] leading-snug font-medium">
            {location.neighborhoodKa} · {location.boroughKa}
          </p>
        </div>
        <div>
          <p className="font-semibold text-[#57524A] uppercase tracking-wider text-[10.5px]">
            WGS84 კოორდინატები
          </p>
          <p className="mt-1 font-mono text-[#1F1D1A] leading-snug">
            {location.latitude !== null && location.longitude !== null
              ? `${location.latitude.toFixed(5)}° N, ${Math.abs(
                  location.longitude
                ).toFixed(5)}° W`
              : "არ ენიჭება (გამოგონილი)"}
          </p>
        </div>
      </div>

      {/* Visual Archive Gallery */}
      {location.images.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-serif text-lg font-bold text-[#1F1D1A]">
            საარქივო და თანამედროვე ვიზუალური მასალა
          </h3>
          <div
            className={`grid grid-cols-1 ${
              location.images.length > 1 ? "md:grid-cols-2" : ""
            } gap-4`}
          >
            {location.images.map((img) => (
              <figure
                key={img.id}
                className="bg-[#F7F3EB] border border-[#D5CCBC] rounded-lg overflow-hidden"
              >
                <div className="relative aspect-[16/10] bg-[#1F1D1A]">
                  <img
                    src={img.url}
                    alt={img.titleKa}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  <span className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded bg-[#1F1D1A]/85 text-[#FDFBF7] text-[11px] font-medium">
                    {img.era === "historical" ? "ისტორიული არქივი" : "დღევანდელობა"} ·{" "}
                    {img.dateLabel}
                  </span>
                  {img.depictsNovelPeriod && (
                    <span className="absolute bottom-2.5 left-2.5 px-2 py-0.5 rounded bg-[#7A1F2B]/90 text-[#FDFBF7] text-[10.5px] font-medium">
                      რომანის ეპოქის კადრი
                    </span>
                  )}
                </div>
                <figcaption className="p-3 text-xs text-[#57524A] space-y-1">
                  <p className="font-semibold text-[#1F1D1A]">{img.titleKa}</p>
                  <p className="leading-relaxed">{img.captionKa}</p>
                  <p className="text-[11px] pt-1 border-t border-[#DDD5C7]">
                    {img.creator} · {img.institution} · {img.license} ·{" "}
                    <a
                      href={img.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#7A1F2B] underline inline-flex items-center gap-0.5"
                    >
                      არქივის ბმული <ExternalLink className="w-3 h-3" />
                    </a>
                  </p>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      )}

      {/* Holden's Experience */}
      <div className="space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-serif text-lg font-bold text-[#1F1D1A] flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#7A1F2B]" />
            როლი რომანში და ჰოლდენის გამოცდილება
          </h3>
          <span className="inline-flex items-center gap-1 text-xs text-[#57524A]">
            <Clock className="w-3.5 h-3.5" />
            {location.durationNoteKa}
          </span>
        </div>
        <p className="text-sm text-[#1F1D1A] leading-relaxed">
          {location.holdensExperienceKa}
        </p>
      </div>

      {/* Historical vs. Today */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#F7F3EB] border border-[#DDD5C7] rounded-lg p-4 space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wider text-[#7A1F2B]">
            ისტორიული კონტექსტი (1949 წლის დეკემბერი)
          </p>
          <p className="text-xs font-medium text-[#57524A]">
            {location.historicalNameKa}
          </p>
          <p className="text-sm text-[#1F1D1A] leading-relaxed">
            {location.historicalContextKa}
          </p>
        </div>

        <div className="bg-[#F7F3EB] border border-[#DDD5C7] rounded-lg p-4 space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wider text-[#243447]">
            რა ხდება ამ ადგილას დღეს
          </p>
          <p className="text-xs font-medium text-[#57524A]">
            {location.modernNameKa}
          </p>
          <p className="text-sm text-[#1F1D1A] leading-relaxed">
            {location.modernContextKa}
          </p>
        </div>
      </div>

      {/* Chronological Events at this location */}
      {relatedEvents.length > 0 && (
        <div className="space-y-2.5">
          <h3 className="font-serif text-lg font-bold text-[#1F1D1A]">
            დაკავშირებული ქრონოლოგიური მოვლენები
          </h3>
          <div className="space-y-2">
            {relatedEvents.map((ev) => (
              <div
                key={ev.id}
                className="p-3.5 rounded-lg bg-[#FDFBF7] border border-[#DDD5C7] text-xs space-y-1"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold text-[#7A1F2B]">
                    ეტაპი #{ev.sequence} · {ev.dayLabelKa} · {ev.timeLabelKa}
                  </span>
                  <span className="font-mono text-[#57524A]">თავი {ev.chapter}</span>
                </div>
                <p className="text-sm font-semibold text-[#1F1D1A]">{ev.titleKa}</p>
                <p className="text-[#57524A] leading-relaxed">{ev.summaryKa}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Characters & Literary References */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="space-y-2.5">
          <h3 className="font-serif text-base font-bold text-[#1F1D1A] flex items-center gap-2">
            <Users className="w-4 h-4 text-[#243447]" />
            დაკავშირებული პერსონაჟები
          </h3>
          {relatedCharacters.length === 0 ? (
            <p className="text-xs text-[#57524A]">
              ამ ლოკაციაზე ჰოლდენი მარტოა და კონკრეტულ დასახელებულ პერსონაჟს არ ხვდება.
            </p>
          ) : (
            <div className="space-y-2">
              {relatedCharacters.map((ch) => (
                <div
                  key={ch.id}
                  className="p-3 rounded-md bg-[#F7F3EB] border border-[#DDD5C7] flex items-start justify-between gap-2"
                >
                  <div>
                    <p className="text-xs font-bold text-[#1F1D1A]">
                      {ch.nameKa}{" "}
                      <span className="font-normal text-[#57524A]">({ch.nameEn})</span>
                    </p>
                    <p className="text-[11px] text-[#57524A] mt-0.5">{ch.roleKa}</p>
                  </div>
                  {onSelectCharacter && (
                    <button
                      type="button"
                      onClick={() => onSelectCharacter(ch.id)}
                      className="shrink-0 text-[11px] font-semibold text-[#7A1F2B] hover:underline"
                    >
                      კავშირები →
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-2.5">
          <h3 className="font-serif text-base font-bold text-[#1F1D1A]">
            ლიტერატურული მითითებები (თავების მიხედვით)
          </h3>
          <div className="space-y-2">
            {location.literaryReferences.map((ref, idx) => (
              <div
                key={`${ref.chapter}-${idx}`}
                className="p-3 rounded-md bg-[#F7F3EB] border border-[#DDD5C7] text-xs space-y-1"
              >
                <p className="font-mono font-semibold text-[#7A1F2B]">
                  თავი {ref.chapter} — {ref.contextKa}
                </p>
                <p className="text-[#57524A] leading-relaxed">
                  {ref.briefExcerptNoteKa}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Research Reliability & Uncertainties */}
      <div className="p-4 rounded-lg bg-[#243447]/[0.06] border border-[#243447]/25 space-y-1.5">
        <div className="flex flex-wrap items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#243447]" />
          <h3 className="text-sm font-bold text-[#1F1D1A]">
            კვლევის სანდოობა და გადაუჭრელი საკითხები: {conf.symbol} {conf.labelKa}
          </h3>
        </div>
        <p className="text-xs text-[#1F1D1A] leading-relaxed">
          {location.uncertaintyNoteKa}
        </p>
      </div>

      {/* Sources */}
      <div className="space-y-2.5">
        <h3 className="font-serif text-base font-bold text-[#1F1D1A]">
          დამადასტურებელი წყაროები ({relatedSources.length})
        </h3>
        <ul className="space-y-2">
          {relatedSources.map((src) => (
            <li
              key={src.id}
              className="p-3 rounded-md bg-[#FDFBF7] border border-[#DDD5C7] text-xs flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2"
            >
              <div className="space-y-0.5">
                <span className="inline-block text-[10.5px] font-semibold uppercase tracking-wider text-[#7A1F2B]">
                  {SOURCE_CATEGORY_META[src.category]} · {src.publicationDate}
                </span>
                <p className="font-semibold text-[#1F1D1A]">{src.titleKa}</p>
                <p className="text-[#57524A] leading-snug">{src.relevantClaimKa}</p>
              </div>
              <a
                href={src.url}
                target="_blank"
                rel="noopener noreferrer"
                className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1 rounded border border-[#C9BFAE] text-[11px] font-medium text-[#243447] hover:border-[#7A1F2B] hover:text-[#7A1F2B] transition"
              >
                წყარო <ExternalLink className="w-3 h-3" />
              </a>
            </li>
          ))}
        </ul>
      </div>

      {/* Reader & Scholar Marginalia Notes (PostgreSQL-backed CRUD) */}
      <div className="pt-5 border-t border-[#D5CCBC] space-y-4">
        <div>
          <h3 className="font-serif text-lg font-bold text-[#1F1D1A] flex items-center gap-2">
            <MessageSquarePlus className="w-4 h-4 text-[#7A1F2B]" />
            მკითხველთა და მკვლევართა მინაწერები ({locationNotes.length})
          </h3>
          <p className="text-xs text-[#57524A] mt-0.5">
            დატოვეთ ლიტერატურული, ისტორიული ან გეოგრაფიული დაკვირვება ამ ადგილის შესახებ (ინახება მონაცემთა ბაზაში).
          </p>
        </div>

        {locationNotes.length > 0 && (
          <div className="space-y-2.5">
            {locationNotes.map((note) => (
              <div
                key={note.id}
                className="p-3.5 rounded-lg bg-[#F7F3EB] border border-[#D5CCBC] text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold text-[#1F1D1A]">{note.authorName}</span>
                    <span className="text-[#57524A]">· {note.authorRole}</span>
                    <span className="px-2 py-0.5 rounded bg-[#FDFBF7] border border-[#DDD5C7] text-[10.5px] font-medium text-[#7A1F2B]">
                      {NOTE_TYPE_LABELS[note.noteType] ?? note.noteType}
                    </span>
                    {note.chapterRef && (
                      <span className="font-mono text-[10.5px] text-[#57524A]">
                        ({note.chapterRef})
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDeleteNote(note.id)}
                    className="p-1 text-[#57524A] hover:text-[#7A1F2B] transition"
                    title="ჩანაწერის წაშლა"
                    aria-label="ჩანაწერის წაშლა"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-sm text-[#1F1D1A] leading-relaxed">{note.content}</p>
              </div>
            ))}
          </div>
        )}

        <form
          onSubmit={handleSubmitNote}
          className="p-4 rounded-lg bg-[#FDFBF7] border border-[#D5CCBC] space-y-3"
        >
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-[#57524A] mb-1">
                თქვენი სახელი *
              </label>
              <input
                type="text"
                required
                minLength={2}
                maxLength={80}
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder="მაგ., ანა გელაშვილი"
                className="w-full px-3 py-1.5 rounded border border-[#C9BFAE] bg-[#F7F3EB] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-[#57524A] mb-1">
                სტატუსი / სფერო
              </label>
              <input
                type="text"
                maxLength={60}
                value={authorRole}
                onChange={(e) => setAuthorRole(e.target.value)}
                placeholder="მკითხველი, მკვლევარი..."
                className="w-full px-3 py-1.5 rounded border border-[#C9BFAE] bg-[#F7F3EB] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-[#57524A] mb-1">
                ჩანაწერის ტიპი
              </label>
              <select
                value={noteType}
                onChange={(e) =>
                  setNoteType(e.target.value as ReaderNote["noteType"])
                }
                className="w-full px-3 py-1.5 rounded border border-[#C9BFAE] bg-[#F7F3EB] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
              >
                <option value="literary">ლიტერატურული დაკვირვება</option>
                <option value="historical">ისტორიული კონტექსტი</option>
                <option value="geographical">გეოგრაფიული შენიშვნა</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-3">
              <label className="block text-[11px] font-semibold text-[#57524A] mb-1">
                მინაწერის ტექსტი *
              </label>
              <textarea
                rows={2}
                required
                minLength={10}
                maxLength={1000}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="გაგვიზიარეთ ტექსტობრივი პარალელი, საარქივო ცნობა ან დაკვირვება..."
                className="w-full px-3 py-1.5 rounded border border-[#C9BFAE] bg-[#F7F3EB] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
              />
            </div>
            <div className="flex flex-col justify-between gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-[#57524A] mb-1">
                  თავის მითითება
                </label>
                <input
                  type="text"
                  maxLength={40}
                  value={chapterRef}
                  onChange={(e) => setChapterRef(e.target.value)}
                  placeholder="მაგ., თავი 16"
                  className="w-full px-3 py-1.5 rounded border border-[#C9BFAE] bg-[#F7F3EB] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
                />
              </div>
              <button
                type="submit"
                disabled={submitting}
                className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded bg-[#7A1F2B] text-[#FDFBF7] text-xs font-semibold hover:bg-[#5E1620] disabled:opacity-50 transition"
              >
                <Send className="w-3.5 h-3.5" />
                {submitting ? "ინახება..." : "დამატება"}
              </button>
            </div>
          </div>

          {formError && (
            <p className="text-xs font-medium text-[#7A1F2B]">{formError}</p>
          )}
          {formSuccess && (
            <p className="text-xs font-medium text-[#2E5A44]">{formSuccess}</p>
          )}
        </form>
      </div>
    </div>
  );
}
