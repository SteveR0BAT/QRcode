"use client";

import { useState } from "react";
import {
  Download,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  BookMarked,
  Map as MapIcon,
} from "lucide-react";
import {
  type ResearchSource,
  type SourceCategory,
  CONFIDENCE_META,
  SOURCE_CATEGORY_META,
} from "@/lib/types";
import { AUDIT_ITEMS } from "@/data/sources";

interface MethodologyAndSourcesProps {
  sources: ResearchSource[];
  onOpenDetail: (locationId: string) => void;
}

const RESEARCH_ROUNDS = [
  {
    round: "რაუნდი I",
    title: "პირველადი ლიტერატურული რეკონსტრუქცია",
    desc: "რომანის 26-ვე თავის სისტემური დამუშავება; ნიუ-იორკის ობიექტების დაყოფა 5 კატეგორიად (A: მონახულებული, B: გავლილი, C: გარედან დანახული, D: მოხსენიებული, E: გამოგონილი).",
  },
  {
    round: "რაუნდი II",
    title: "ისტორიული დათარიღება და ვერიფიკაცია",
    desc: "სპექტაკლის „I Know My Love“ (შუბერტის თეატრი, ნოემბ. 1949 – ივნ. 1950) და 1950 წელს დამწვარი კარუსელის მიხედვით მოქმედების დათარიღება 1949 წლის 17–19 დეკემბრით.",
  },
  {
    round: "რაუნდი III",
    title: "გეოგრაფიული კოორდინატები და სიზუსტე",
    desc: "WGS84 კოორდინატების მინიჭება მხოლოდ დადასტურებული და არგუმენტირებული ადგილებისთვის; სასტუმრო „ედმონტის“ დატოვება ხელოვნური კოორდინატის გარეშე.",
  },
  {
    round: "რაუნდი IV",
    title: "ქრონოლოგიისა და გადაადგილების ანალიზი",
    desc: "22 თანმიმდევრული ეტაპის აგება ტექსტური დროის მინიშნებებით; ქრონოლოგიური ხაზების გამიჯვნა გამოგონილი ქუჩა-ქუჩა მარშრუტებისგან.",
  },
  {
    round: "რაუნდი V",
    title: "საარქივო ვიზუალური კვლევა",
    desc: "აშშ-ის კონგრესის ბიბლიოთეკის (მარჯორი კოლინზი, სამუელ გოტშო, ანჯელო რიცუტო, ირვინგ ანდერჰილი) და ღია ლიცენზიის ფოტოების შეჯერება ზუსტი ატრიბუციით.",
  },
  {
    round: "რაუნდი VI",
    title: "წყაროთა ჯვარედინი აუდიტი",
    desc: "მეორეულ გზამკვლევებში გავრცელებული 6 მცდარი მტკიცების (გრანდ-სენტრალში ჩამოსვლა, Biltmore Theatre, კარუსელის იდენტურობა, AMNH-ში შესვლა) გასწორება.",
  },
];

export default function MethodologyAndSources({
  sources,
  onOpenDetail,
}: MethodologyAndSourcesProps) {
  const [sourceFilter, setSourceFilter] = useState<"all" | SourceCategory>("all");

  const filteredSources =
    sourceFilter === "all"
      ? sources
      : sources.filter((s) => s.category === sourceFilter);

  return (
    <section id="methodology" className="py-16 sm:py-20 bg-[#F7F3EB]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-14">
        {/* Intro + GeoJSON Download */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
          <div className="max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#7A1F2B]">
              კვლევის გამჭვირვალობა · მეთოდოლოგია და აუდიტი
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#1F1D1A] tracking-tight">
              რეკონსტრუქციის შესახებ
            </h2>
            <p className="mt-3 text-sm sm:text-base text-[#57524A] leading-relaxed">
              ეს ატლასი დამოუკიდებელი საგანმანათლებლო-ლიტერატურული პროექტია. ჩვენი მთავარი პრინციპია: რომანის ტექსტი უზენაესი ლიტერატურული ავტორიტეტია, ხოლო იქ, სადაც ისტორიული ან გეოგრაფიული მტკიცებულება წყდება, გაურკვევლობა ღიად არის აღნიშნული.
            </p>
          </div>

          <a
            href="/api/geojson?download=1"
            className="self-start lg:self-auto inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#243447] text-[#FDFBF7] text-xs font-semibold hover:bg-[#192533] transition shadow-sm"
          >
            <Download className="w-4 h-4" />
            GeoJSON მონაცემთა ბაზის ჩამოტვირთვა
          </a>
        </div>

        {/* Editions & Cartographic Transparency */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl p-5 space-y-2">
            <div className="flex items-center gap-2 text-[#7A1F2B]">
              <BookMarked className="w-4 h-4" />
              <h3 className="font-serif text-lg font-bold text-[#1F1D1A]">
                გამოყენებული გამოცემები და ციტირების წესი
              </h3>
            </div>
            <p className="text-xs sm:text-sm text-[#57524A] leading-relaxed">
              ტექსტობრივი შემოწმება ეყრდნობა ჯ. დ. სელინჯერის 1951 წლის 26-თავიან პირველ გამოცემას (<em>Little, Brown and Company</em>, ბოსტონი), ხოლო ქართული ტერმინოლოგია და სათაური — ვახტანგ ჭელიძის კლასიკურ თარგმანს (<em>„თამაში ჭვავის ყანაში“</em>). რადგან გვერდების ნუმერაცია გამოცემების მიხედვით იცვლება, ყველა მითითება მოცემულია თავების მიხედვით; საავტორო უფლებების დაცვის მიზნით გამოყენებულია ორიგინალური ანალიტიკური შეჯამებები და მოკლე პარაფრაზები.
            </p>
          </div>

          <div className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl p-5 space-y-2">
            <div className="flex items-center gap-2 text-[#243447]">
              <MapIcon className="w-4 h-4" />
              <h3 className="font-serif text-lg font-bold text-[#1F1D1A]">
                კარტოგრაფიული მონაცემები და შეზღუდვები
              </h3>
            </div>
            <p className="text-xs sm:text-sm text-[#57524A] leading-relaxed">
              ინტერაქტიული რუკა აგებულია <strong>Leaflet</strong>-ისა და <strong>OpenStreetMap</strong>-ის რეალურ გეოგრაფიულ მონაცემებზე (დამატებითი ფენა: OpenTopoMap; სურვილისამებრ ფილების სერვერი იცვლება <code className="font-mono text-[11px] bg-[#EFE9DC] px-1 py-0.5 rounded">NEXT_PUBLIC_MAP_TILE_URL</code> გარემოს ცვლადით). ყველა კოორდინატი წინასწარ გადამოწმებულია და ინახება PostgreSQL-სა და GeoJSON-ში. კალენდარული თარიღი (17–19 დეკემბერი, 1949) წარმოადგენს მაღალი სანდოობის ისტორიულ რეკონსტრუქციას, რადგან თავად წელი რომანში პირდაპირ არ წერია.
            </p>
          </div>
        </div>

        {/* 6 Research Rounds */}
        <div>
          <h3 className="font-serif text-xl font-bold text-[#1F1D1A] mb-4">
            ექვსრაუნდიანი კვლევითი პროცესი
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {RESEARCH_ROUNDS.map((r) => (
              <div
                key={r.round}
                className="p-4 rounded-lg bg-[#FDFBF7] border border-[#DDD5C7] space-y-1.5"
              >
                <span className="font-mono text-xs font-semibold text-[#7A1F2B]">
                  {r.round}
                </span>
                <h4 className="text-sm font-bold text-[#1F1D1A]">{r.title}</h4>
                <p className="text-xs text-[#57524A] leading-relaxed">{r.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Confidence Rubric */}
        <div className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl p-5 sm:p-6">
          <h3 className="font-serif text-xl font-bold text-[#1F1D1A] mb-4">
            სანდოობის შეფასების შკალა
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {(["high", "medium", "low", "unverified"] as const).map((lvl) => {
              const m = CONFIDENCE_META[lvl];
              return (
                <div
                  key={lvl}
                  className="p-3.5 rounded-lg bg-[#F7F3EB] border border-[#DDD5C7] space-y-1.5"
                >
                  <span
                    className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs font-semibold border ${m.badgeClass}`}
                  >
                    <span>{m.symbol}</span>
                    <span>{m.labelKa}</span>
                  </span>
                  <p className="text-xs text-[#57524A] leading-relaxed">
                    {m.explanationKa}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Round 6 Factual Audit & Resolved Contradictions */}
        <div>
          <h3 className="font-serif text-xl font-bold text-[#1F1D1A] mb-1">
            ფაქტობრივი აუდიტი: გადაჭრილი წინააღმდეგობები და გაურკვევლობები
          </h3>
          <p className="text-xs sm:text-sm text-[#57524A] mb-5">
            ჯვარედინი გადამოწმებისას გამოვლენილი შეცდომები, რომლებიც ხშირად გვხვდება მეორეულ წყაროებში, და მათი დასაბუთებული გადაწყვეტა.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {AUDIT_ITEMS.map((item) => {
              const cm = CONFIDENCE_META[item.resolutionConfidence];
              return (
                <div
                  key={item.id}
                  className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl p-5 flex flex-col justify-between gap-3"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-sm font-bold text-[#1F1D1A] leading-snug">
                        {item.questionKa}
                      </h4>
                      <span
                        className={`shrink-0 px-2 py-0.5 rounded text-[10.5px] font-semibold border ${cm.badgeClass}`}
                      >
                        {cm.symbol}
                      </span>
                    </div>
                    <div className="flex items-start gap-2 text-xs text-[#7A1F2B] bg-[#7A1F2B]/[0.05] p-2.5 rounded">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                      <p>
                        <strong>გავრცელებული უზუსტობა:</strong> {item.commonMythKa}
                      </p>
                    </div>
                    <div className="flex items-start gap-2 text-xs text-[#1F1D1A]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#2E5A44] shrink-0 mt-0.5" />
                      <p className="leading-relaxed">
                        <strong>აუდიტის დასკვნა:</strong> {item.verifiedFindingKa}
                      </p>
                    </div>
                  </div>
                  <div className="pt-2 border-t border-[#E5DEC9] flex justify-end">
                    <button
                      type="button"
                      onClick={() => onOpenDetail(item.relatedLocationId)}
                      className="text-xs font-semibold text-[#7A1F2B] hover:underline"
                    >
                      ობიექტის დოსიეს გახსნა →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Full Source Registry & Bibliography */}
        <div id="sources" className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
            <div>
              <h3 className="font-serif text-2xl font-bold text-[#1F1D1A]">
                წყაროთა რეესტრი და ბიბლიოგრაფია ({filteredSources.length})
              </h3>
              <p className="text-xs sm:text-sm text-[#57524A] mt-1">
                დაჯგუფებულია პირველად ლიტერატურულ, საარქივო, ისტორიულ, ლიტერატურათმცოდნეობით და გეოგრაფიულ წყაროებად.
              </p>
            </div>

            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => setSourceFilter("all")}
                className={`px-3 py-1.5 rounded text-xs font-medium border transition ${
                  sourceFilter === "all"
                    ? "bg-[#7A1F2B] text-[#FDFBF7] border-[#7A1F2B]"
                    : "bg-[#FDFBF7] text-[#1F1D1A] border-[#D5CCBC] hover:border-[#7A1F2B]"
                }`}
              >
                ყველა ({sources.length})
              </button>
              {(Object.keys(SOURCE_CATEGORY_META) as SourceCategory[]).map(
                (cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSourceFilter(cat)}
                    className={`px-3 py-1.5 rounded text-xs font-medium border transition ${
                      sourceFilter === cat
                        ? "bg-[#7A1F2B] text-[#FDFBF7] border-[#7A1F2B]"
                        : "bg-[#FDFBF7] text-[#1F1D1A] border-[#D5CCBC] hover:border-[#7A1F2B]"
                    }`}
                  >
                    {SOURCE_CATEGORY_META[cat].split(" ")[0]}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredSources.map((src) => (
              <div
                key={src.id}
                className="p-4 rounded-lg bg-[#FDFBF7] border border-[#DDD5C7] flex flex-col justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold text-[#7A1F2B] text-[11px]">
                      {SOURCE_CATEGORY_META[src.category]}
                    </span>
                    <span className="font-mono text-[10.5px] text-[#57524A]">
                      {src.id} · {src.publicationDate}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-[#1F1D1A] leading-snug">
                    {src.titleKa}
                  </h4>
                  <p className="text-[11px] text-[#57524A] italic">
                    {src.originalTitle} — {src.authorOrInstitution}
                  </p>
                  <p className="text-[#1F1D1A]/90 leading-relaxed pt-1">
                    {src.relevantClaimKa}
                  </p>
                </div>

                <div className="pt-2 border-t border-[#E5DEC9] flex items-center justify-between gap-2 text-[11px]">
                  <span className="text-[#2E5A44] font-medium">
                    სანდოობა: {src.reliabilityKa}
                  </span>
                  <a
                    href={src.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 font-semibold text-[#243447] hover:text-[#7A1F2B] underline"
                  >
                    გადასვლა <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
