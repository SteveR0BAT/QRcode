"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import {
  Compass,
  MapPin,
  Search,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  X,
  BookOpen,
  Clock,
  Users,
  Filter,
  RotateCcw,
  Menu,
  ArrowUpRight,
  MessageSquare,
  Sparkles,
  AlertCircle,
} from "lucide-react";
import {
  type AtlasLocation,
  type ChronologicalEvent,
  type ResearchSource,
  type StoryCharacter,
  type ReaderNote,
  type LocationCategory,
  type ConfidenceLevel,
  type LiteraryStatus,
  CATEGORY_META,
  LITERARY_STATUS_META,
  HISTORICAL_STATUS_META,
  CONFIDENCE_META,
  MOVEMENT_META,
} from "@/lib/types";
import ThenNowSlider from "./ThenNowSlider";
import LocationDossierContent from "./LocationDossierContent";
import ThemesAndStatsSection from "./ThemesAndStatsSection";
import MethodologyAndSources from "./MethodologyAndSources";

const NewYorkLeafletMap = dynamic(() => import("./NewYorkLeafletMap"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full min-h-[540px] bg-[#E8E1D3] flex flex-col items-center justify-center text-[#57524A] gap-3 p-6 text-center">
      <Compass className="w-8 h-8 text-[#7A1F2B] animate-spin" />
      <p className="font-serif text-base font-semibold text-[#1F1D1A]">
        იტვირთება ნიუ-იორკის რეალური გეოგრაფიული რუკა...
      </p>
      <p className="text-xs text-[#57524A]">
        OpenStreetMap · მანჰეტენის ქუჩათა ბადე და გადამოწმებული კოორდინატები
      </p>
    </div>
  ),
});

interface HoldenAtlasAppProps {
  initialLocations: AtlasLocation[];
  initialEvents: ChronologicalEvent[];
  initialSources: ResearchSource[];
  initialCharacters: StoryCharacter[];
  initialNotes: ReaderNote[];
}

export default function HoldenAtlasApp({
  initialLocations,
  initialEvents,
  initialSources,
  initialCharacters,
  initialNotes,
}: HoldenAtlasAppProps) {
  const [notes, setNotes] = useState<ReaderNote[]>(initialNotes);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  // Synchronized Map + Timeline State
  const [selectedLocationId, setSelectedLocationId] =
    useState<string>("penn-station");
  const [activeEventIndex, setActiveEventIndex] = useState<number>(0);
  const [guidedMode, setGuidedMode] = useState<boolean>(false);
  const [autoPlaying, setAutoPlaying] = useState<boolean>(false);
  const [showRoute, setShowRoute] = useState<boolean>(true);
  const [historicalMode, setHistoricalMode] = useState<boolean>(false);
  const [panelPhotoEra, setPanelPhotoEra] = useState<"historical" | "modern">(
    "historical"
  );

  // Map Filters
  const [mapSearch, setMapSearch] = useState<string>("");
  const [onlyVisited, setOnlyVisited] = useState<boolean>(false);
  const [onlySurviving, setOnlySurviving] = useState<boolean>(false);
  const [onlyFictionalOrUncertain, setOnlyFictionalOrUncertain] =
    useState<boolean>(false);
  const [categoryFilter, setCategoryFilter] = useState<
    "all" | LocationCategory
  >("all");
  const [confidenceFilter, setConfidenceFilter] = useState<
    "all" | ConfidenceLevel
  >("all");
  const [selectedCharacterId, setSelectedCharacterId] =
    useState<string>("all");

  // Timeline Day Filter
  const [timelineDay, setTimelineDay] = useState<
    "all" | "day1" | "day2" | "day3"
  >("all");

  // Directory Filters
  const [dirSearch, setDirSearch] = useState<string>("");
  const [dirLitStatus, setDirLitStatus] = useState<"all" | LiteraryStatus>(
    "all"
  );
  const [dirConfidence, setDirConfidence] = useState<"all" | ConfidenceLevel>(
    "all"
  );

  // Full Dossier Modal
  const [modalLocationId, setModalLocationId] = useState<string | null>(null);

  const sortedEvents = useMemo(
    () => [...initialEvents].sort((a, b) => a.sequence - b.sequence),
    [initialEvents]
  );

  const locMap = useMemo(
    () => new Map(initialLocations.map((l) => [l.id, l])),
    [initialLocations]
  );

  const charMap = useMemo(
    () => new Map(initialCharacters.map((c) => [c.id, c])),
    [initialCharacters]
  );

  const activeEvent = sortedEvents[activeEventIndex] ?? sortedEvents[0] ?? null;
  const prevEvent =
    activeEventIndex > 0 ? sortedEvents[activeEventIndex - 1] : null;
  const nextEvent =
    activeEventIndex < sortedEvents.length - 1
      ? sortedEvents[activeEventIndex + 1]
      : null;

  const selectedLocation =
    locMap.get(selectedLocationId) ?? initialLocations[0];
  const modalLocation = modalLocationId
    ? locMap.get(modalLocationId) ?? null
    : null;

  const selectedCharacter =
    selectedCharacterId !== "all"
      ? charMap.get(selectedCharacterId) ?? null
      : null;

  const highlightedCharacterLocationIds = useMemo(() => {
    if (!selectedCharacter) return null;
    return new Set(selectedCharacter.locationIds);
  }, [selectedCharacter]);

  // Visible map locations according to filters + search
  const visibleMapLocations = useMemo(() => {
    const q = mapSearch.trim().toLowerCase();
    return initialLocations.filter((loc) => {
      if (onlyVisited && loc.literaryStatus !== "physically_visited") {
        return false;
      }
      if (onlySurviving && !loc.stillExistsToday) {
        return false;
      }
      if (
        onlyFictionalOrUncertain &&
        loc.historicalStatus !== "fictional" &&
        loc.historicalStatus !== "fictional_inspired" &&
        loc.historicalStatus !== "approximate"
      ) {
        return false;
      }
      if (categoryFilter !== "all" && loc.category !== categoryFilter) {
        return false;
      }
      if (confidenceFilter !== "all" && loc.confidence !== confidenceFilter) {
        return false;
      }
      if (
        highlightedCharacterLocationIds &&
        !highlightedCharacterLocationIds.has(loc.id)
      ) {
        return false;
      }
      if (q) {
        const hay = [
          loc.nameKa,
          loc.nameEn,
          loc.novelNameEn,
          loc.historicalNameKa,
          loc.modernNameKa,
          loc.neighborhoodKa,
          loc.neighborhoodEn,
          loc.historicalAddress,
          loc.modernAddress,
        ]
          .join(" ")
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [
    initialLocations,
    mapSearch,
    onlyVisited,
    onlySurviving,
    onlyFictionalOrUncertain,
    categoryFilter,
    confidenceFilter,
    highlightedCharacterLocationIds,
  ]);

  const hasActiveMapFilters =
    Boolean(mapSearch.trim()) ||
    onlyVisited ||
    onlySurviving ||
    onlyFictionalOrUncertain ||
    categoryFilter !== "all" ||
    confidenceFilter !== "all" ||
    selectedCharacterId !== "all";

  const resetMapFilters = useCallback(() => {
    setMapSearch("");
    setOnlyVisited(false);
    setOnlySurviving(false);
    setOnlyFictionalOrUncertain(false);
    setCategoryFilter("all");
    setConfidenceFilter("all");
    setSelectedCharacterId("all");
  }, []);

  // Sync when selecting an event by index
  const goToEventIndex = useCallback(
    (index: number, scrollMap = false) => {
      const clamped = Math.max(0, Math.min(sortedEvents.length - 1, index));
      const ev = sortedEvents[clamped];
      if (!ev) return;
      setActiveEventIndex(clamped);
      setSelectedLocationId(ev.locationId);
      setPanelPhotoEra("historical");
      if (scrollMap) {
        document
          .getElementById("atlas")
          ?.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    },
    [sortedEvents]
  );

  // Sync when selecting a map marker or location
  const handleSelectLocation = useCallback(
    (locationId: string, shouldScrollToMap = false) => {
      setSelectedLocationId(locationId);
      setAutoPlaying(false);
      setPanelPhotoEra("historical");

      const matchingIdx = sortedEvents.findIndex(
        (e) => e.locationId === locationId
      );
      if (matchingIdx !== -1) {
        setActiveEventIndex(matchingIdx);
      }

      if (shouldScrollToMap) {
        // Ensure filters don't hide the target location
        resetMapFilters();
        document
          .getElementById("atlas")
          ?.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    },
    [sortedEvents, resetMapFilters]
  );

  // Start Feature 1: "Follow Holden" Guided Exploration
  const startFollowHolden = useCallback(() => {
    resetMapFilters();
    setShowRoute(true);
    setGuidedMode(true);
    setAutoPlaying(false);
    goToEventIndex(0, true);
  }, [resetMapFilters, goToEventIndex]);

  // Auto-play timer for Guided Mode
  useEffect(() => {
    if (!autoPlaying) return;
    const timer = setInterval(() => {
      setActiveEventIndex((prev) => {
        if (prev >= sortedEvents.length - 1) {
          setAutoPlaying(false);
          return prev;
        }
        const nextIdx = prev + 1;
        const nextEv = sortedEvents[nextIdx];
        if (nextEv) {
          setSelectedLocationId(nextEv.locationId);
        }
        return nextIdx;
      });
    }, 5500);
    return () => clearInterval(timer);
  }, [autoPlaying, sortedEvents]);

  // Close modal on Escape key
  useEffect(() => {
    if (!modalLocationId) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setModalLocationId(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [modalLocationId]);

  // Filtered Timeline Events
  const displayedTimelineEvents = useMemo(
    () =>
      timelineDay === "all"
        ? sortedEvents
        : sortedEvents.filter((e) => e.dayId === timelineDay),
    [sortedEvents, timelineDay]
  );

  // Filtered Directory Locations
  const filteredDirectoryLocations = useMemo(() => {
    const q = dirSearch.trim().toLowerCase();
    return initialLocations.filter((loc) => {
      if (dirLitStatus !== "all") {
        if (dirLitStatus === "fictional_unverified") {
          if (
            loc.historicalStatus !== "fictional" &&
            loc.historicalStatus !== "fictional_inspired"
          ) {
            return false;
          }
        } else if (loc.literaryStatus !== dirLitStatus) {
          return false;
        }
      }
      if (dirConfidence !== "all" && loc.confidence !== dirConfidence) {
        return false;
      }
      if (q) {
        const hay = [
          loc.nameKa,
          loc.nameEn,
          loc.novelNameEn,
          loc.historicalNameKa,
          loc.modernNameKa,
          loc.neighborhoodKa,
          loc.summaryKa,
        ]
          .join(" ")
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [initialLocations, dirSearch, dirLitStatus, dirConfidence]);

  // Note counts per location
  const noteCountByLocation = useMemo(() => {
    const map = new Map<string, number>();
    for (const n of notes) {
      map.set(n.locationId, (map.get(n.locationId) ?? 0) + 1);
    }
    return map;
  }, [notes]);

  const handleNoteCreated = useCallback((newNote: ReaderNote) => {
    setNotes((prev) => [newNote, ...prev]);
  }, []);

  const handleNoteDeleted = useCallback((noteId: number) => {
    setNotes((prev) => prev.filter((n) => n.id !== noteId));
  }, []);

  const handleFocusCharacterOnMap = useCallback(
    (charId: string) => {
      setModalLocationId(null);
      resetMapFilters();
      setSelectedCharacterId(charId);
      const ch = charMap.get(charId);
      const firstMappable = ch?.locationIds.find((id) => {
        const l = locMap.get(id);
        return l && l.latitude !== null;
      });
      if (firstMappable) {
        setSelectedLocationId(firstMappable);
      }
      document
        .getElementById("atlas")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    },
    [charMap, locMap, resetMapFilters]
  );

  // Side panel image handling
  const sideHistImg =
    selectedLocation.images.find((i) => i.era === "historical") ?? null;
  const sideModImg =
    selectedLocation.images.find((i) => i.era === "modern") ?? null;
  const activeSideImg =
    panelPhotoEra === "historical"
      ? sideHistImg ?? sideModImg
      : sideModImg ?? sideHistImg;

  const progressPercent = Math.round(
    ((activeEventIndex + 1) / Math.max(1, sortedEvents.length)) * 100
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F3EB] text-[#1F1D1A]">
      {/* STICKY EDITORIAL HEADER */}
      <header className="sticky top-0 z-[600] bg-[#FDFBF7]/95 backdrop-blur-md border-b border-[#DDD5C7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <a href="#top" className="flex items-center gap-2.5 group shrink-0">
            <span className="w-8 h-8 rounded-md bg-[#7A1F2B] text-[#FDFBF7] font-serif font-bold text-sm flex items-center justify-center shadow-sm">
              ჰ
            </span>
            <div className="leading-tight">
              <span className="block font-serif text-sm sm:text-base font-bold text-[#1F1D1A] group-hover:text-[#7A1F2B] transition">
                ჰოლდენი ნიუ-იორკში
              </span>
              <span className="block text-[10.5px] text-[#57524A]">
                ლიტერატურული ატლასი · 1949
              </span>
            </div>
          </a>

          <nav
            className="hidden lg:flex items-center gap-6 text-xs font-medium text-[#57524A]"
            aria-label="მთავარი ნავიგაცია"
          >
            <a href="#atlas" className="hover:text-[#7A1F2B] transition">
              რუკა
            </a>
            <a href="#timeline" className="hover:text-[#7A1F2B] transition">
              ქრონოლოგია
            </a>
            <a href="#locations" className="hover:text-[#7A1F2B] transition">
              ადგილები
            </a>
            <a href="#then-and-now" className="hover:text-[#7A1F2B] transition">
              მაშინ და ახლა
            </a>
            <a href="#themes" className="hover:text-[#7A1F2B] transition">
              გამოცდილება
            </a>
            <a href="#methodology" className="hover:text-[#7A1F2B] transition">
              მეთოდოლოგია
            </a>
          </nav>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={startFollowHolden}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md bg-[#7A1F2B] text-[#FDFBF7] text-xs font-semibold hover:bg-[#5E1620] transition shadow-sm"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>გაჰყევი ჰოლდენს</span>
            </button>

            <button
              type="button"
              onClick={() => setMobileNavOpen((p) => !p)}
              className="lg:hidden p-2 rounded-md border border-[#D5CCBC] text-[#1F1D1A] hover:bg-[#EFE9DC]"
              aria-label="მენიუს გახსნა"
            >
              {mobileNavOpen ? (
                <X className="w-4 h-4" />
              ) : (
                <Menu className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>

        {mobileNavOpen && (
          <div className="lg:hidden border-t border-[#DDD5C7] bg-[#FDFBF7] px-4 py-3 flex flex-col gap-2 text-sm font-medium">
            {[
              { href: "#atlas", label: "ინტერაქტიული რუკა" },
              { href: "#timeline", label: "ქრონოლოგიური ხაზი" },
              { href: "#locations", label: "ადგილების კატალოგი" },
              { href: "#then-and-now", label: "მაშინ და ახლა (1949 / დღეს)" },
              { href: "#themes", label: "ჰოლდენის გამოცდილება და სტატისტიკა" },
              { href: "#methodology", label: "რეკონსტრუქციის შესახებ და წყაროები" },
            ].map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMobileNavOpen(false)}
                className="py-1.5 text-[#1F1D1A] hover:text-[#7A1F2B]"
              >
                {item.label}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* SECTION A — IMMERSIVE EDITORIAL LANDING PAGE */}
      <section
        id="top"
        className="relative border-b border-[#DDD5C7] bg-gradient-to-b from-[#FDFBF7] to-[#F4EFE3]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
            {/* Left Editorial Introduction */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex flex-wrap items-center gap-2 px-3 py-1 rounded-full bg-[#EFE9DC] border border-[#D5CCBC] text-[11px] font-medium text-[#57524A]">
                <span className="w-2 h-2 rounded-full bg-[#7A1F2B]" />
                <span>
                  დამოუკიდებელი საგანმანათლებლო-ლიტერატურული პროექტი · ჯ. დ. სელინჯერის „თამაში ჭვავის ყანაში“
                </span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-[3.35rem] font-bold text-[#1F1D1A] leading-[1.15] tracking-tight">
                ნიუ-იორკი ჰოლდენ კოლფილდის თვალით.
              </h1>

              <p className="text-base sm:text-lg text-[#57524A] leading-relaxed max-w-2xl">
                გაჰყევით თექვსმეტი წლის ახალგაზრდის ადგილებს, შეხვედრებსა და მოუსვენარ ხეტიალს 1949 წლის დეკემბრის მანჰეტენის რეალურ ქუჩებში — დანგრეული პენსილვანიის სადგურიდან და „ბილტმორის“ საათიდან სენტრალ-პარკის გაყინულ ტბორსა და წვიმიან კარუსელამდე.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={startFollowHolden}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-md bg-[#7A1F2B] text-[#FDFBF7] text-sm font-semibold hover:bg-[#5E1620] transition shadow-sm"
                >
                  <Compass className="w-4 h-4" />
                  გაჰყევი ჰოლდენის გზას
                </button>

                <a
                  href="#locations"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-md bg-[#FDFBF7] text-[#1F1D1A] border border-[#C9BFAE] text-sm font-semibold hover:border-[#7A1F2B] hover:text-[#7A1F2B] transition"
                >
                  <MapPin className="w-4 h-4 text-[#7A1F2B]" />
                  აღმოაჩინე ადგილები
                </a>
              </div>

              {/* Compact Methodology & Key Metrics Strip */}
              <div className="pt-5 border-t border-[#DDD5C7] grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <p className="font-serif text-xl font-bold text-[#1F1D1A]">
                    {initialLocations.length} ლოკაცია
                  </p>
                  <p className="mt-0.5 text-[#57524A] leading-snug">
                    გამიჯნულია მონახულებული, გარედან დანახული, მოხსენიებული და გამოგონილი ადგილები.
                  </p>
                </div>
                <div>
                  <p className="font-serif text-xl font-bold text-[#1F1D1A]">
                    17–19 დეკემბერი, 1949
                  </p>
                  <p className="mt-0.5 text-[#57524A] leading-snug">
                    {sortedEvents.length} ქრონოლოგიური ეტაპი, დათარიღებული ბროდვეისა და პარკის არქივებით.
                  </p>
                </div>
                <div>
                  <p className="font-serif text-xl font-bold text-[#1F1D1A]">
                    6-რაუნდიანი აუდიტი
                  </p>
                  <p className="mt-0.5 text-[#57524A] leading-snug">
                    OpenStreetMap-ის რეალური რუკა, კონგრესის ბიბლიოთეკის ფოტოები და {initialSources.length} წყარო.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Atmospheric Winter Manhattan Plate */}
            <div className="lg:col-span-5">
              <figure className="bg-[#FDFBF7] p-3 rounded-xl border border-[#D5CCBC] shadow-md">
                <div className="relative aspect-[4/5] max-h-[470px] w-full rounded-lg overflow-hidden bg-[#1F1D1A]">
                  <img
                    src="/images/hero-manhattan-winter.jpg"
                    alt="ზამთრის მწუხრი მანჰეტენზე — სენტრალ-პარკის სამხრეთის ტბორი და 59-ე ქუჩის სინათლეები"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#141311]/80 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 text-[#FDFBF7]">
                    <p className="font-mono text-[11px] uppercase tracking-widest text-[#E4C9A8]">
                      მანჰეტენი · Central Park South · ზამთარი
                    </p>
                    <p className="mt-1 font-serif text-lg font-semibold leading-snug">
                      „ნეტავ სად მიდიან იხვები, როცა ტბორი მთლიანად იყინება?“
                    </p>
                    <p className="mt-1 text-[11px] text-[#FDFBF7]/75">
                      თავები 2, 9, 12, 20 — სენტრალ-პარკის სამხრეთის ტბორი
                    </p>
                  </div>
                </div>
                <figcaption className="mt-2.5 px-1 flex items-center justify-between gap-2 text-[11px] text-[#57524A]">
                  <span>
                    სარედაქციო ილუსტრაცია (საარქივო ფოტოები იხ. ლოკაციების დოსიეებში)
                  </span>
                  <a
                    href="#methodology"
                    className="shrink-0 font-semibold text-[#7A1F2B] hover:underline"
                  >
                    მეთოდოლოგია →
                  </a>
                </figcaption>
              </figure>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION B — THE INTERACTIVE NEW YORK MAP WORKBENCH */}
      <section id="atlas" className="py-12 sm:py-16 bg-[#F7F3EB] scroll-mt-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-5">
          {/* Section Title + Mode Switch */}
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#7A1F2B]">
                ცენტრალური კარტოგრაფიული ატლასი · OpenStreetMap
              </p>
              <h2 className="mt-1 font-serif text-3xl sm:text-4xl font-bold text-[#1F1D1A] tracking-tight">
                ჰოლდენის მანჰეტენი — ინტერაქტიული რუკა
              </h2>
            </div>

            {/* Feature 1 vs Feature 2 Switch */}
            <div className="inline-flex rounded-lg border border-[#C9BFAE] bg-[#FDFBF7] p-1 self-start md:self-auto shadow-xs">
              <button
                type="button"
                onClick={() => {
                  setGuidedMode(false);
                  setAutoPlaying(false);
                }}
                className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition ${
                  !guidedMode
                    ? "bg-[#243447] text-[#FDFBF7]"
                    : "text-[#57524A] hover:text-[#1F1D1A]"
                }`}
              >
                თავისუფალი კვლევა
              </button>
              <button
                type="button"
                onClick={() => {
                  resetMapFilters();
                  setShowRoute(true);
                  setGuidedMode(true);
                }}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition ${
                  guidedMode
                    ? "bg-[#7A1F2B] text-[#FDFBF7]"
                    : "text-[#57524A] hover:text-[#1F1D1A]"
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                გაჰყევი ჰოლდენს
              </button>
            </div>
          </div>

          {/* Guided Journey Step Player Bar */}
          <div
            className={`rounded-xl border p-3.5 sm:p-4 transition ${
              guidedMode
                ? "bg-[#243447] text-[#FDFBF7] border-[#1A2635] shadow-md"
                : "bg-[#FDFBF7] text-[#1F1D1A] border-[#D5CCBC]"
            }`}
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    setAutoPlaying(false);
                    goToEventIndex(activeEventIndex - 1);
                  }}
                  disabled={activeEventIndex <= 0}
                  className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-semibold border disabled:opacity-40 transition ${
                    guidedMode
                      ? "bg-[#FDFBF7]/10 border-[#FDFBF7]/20 text-[#FDFBF7] hover:bg-[#FDFBF7]/20"
                      : "bg-[#F7F3EB] border-[#C9BFAE] text-[#1F1D1A] hover:border-[#7A1F2B]"
                  }`}
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  წინა
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (!guidedMode) {
                      resetMapFilters();
                      setShowRoute(true);
                      setGuidedMode(true);
                    }
                    setAutoPlaying((p) => !p);
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold bg-[#7A1F2B] text-[#FDFBF7] hover:bg-[#5E1620] transition"
                >
                  {autoPlaying ? (
                    <>
                      <Pause className="w-3.5 h-3.5" /> პაუზა
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5" /> ავტო-მსვლელობა
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAutoPlaying(false);
                    goToEventIndex(activeEventIndex + 1);
                  }}
                  disabled={activeEventIndex >= sortedEvents.length - 1}
                  className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-semibold border disabled:opacity-40 transition ${
                    guidedMode
                      ? "bg-[#FDFBF7]/10 border-[#FDFBF7]/20 text-[#FDFBF7] hover:bg-[#FDFBF7]/20"
                      : "bg-[#F7F3EB] border-[#C9BFAE] text-[#1F1D1A] hover:border-[#7A1F2B]"
                  }`}
                >
                  შემდეგი
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {activeEvent && (
                <div className="flex-1 min-w-0 lg:px-3">
                  <div className="flex items-center gap-2 text-[11px]">
                    <span
                      className={`font-mono font-semibold ${
                        guidedMode ? "text-[#E4C9A8]" : "text-[#7A1F2B]"
                      }`}
                    >
                      ეტაპი {activeEvent.sequence}/{sortedEvents.length}
                    </span>
                    <span className="opacity-70">·</span>
                    <span className="truncate opacity-85">
                      {activeEvent.dayLabelKa} · {activeEvent.timeLabelKa} (თავი{" "}
                      {activeEvent.chapter})
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm font-semibold truncate mt-0.5">
                    {activeEvent.titleKa}
                  </p>
                </div>
              )}

              <div className="shrink-0">
                <label className="sr-only" htmlFor="event-jump-select">
                  ქრონოლოგიურ ეტაპზე გადასვლა
                </label>
                <select
                  id="event-jump-select"
                  value={activeEventIndex}
                  onChange={(e) => {
                    setAutoPlaying(false);
                    goToEventIndex(Number(e.target.value));
                  }}
                  className={`w-full lg:w-56 px-2.5 py-1.5 rounded-md text-xs border focus:outline-none ${
                    guidedMode
                      ? "bg-[#1A2635] text-[#FDFBF7] border-[#FDFBF7]/25"
                      : "bg-[#F7F3EB] text-[#1F1D1A] border-[#C9BFAE]"
                  }`}
                >
                  {sortedEvents.map((ev, idx) => (
                    <option key={ev.id} value={idx}>
                      #{ev.sequence} — {ev.titleKa.slice(0, 38)}...
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Journey progress bar */}
            <div
              className={`mt-3 h-1.5 rounded-full overflow-hidden ${
                guidedMode ? "bg-[#FDFBF7]/15" : "bg-[#E5DEC9]"
              }`}
            >
              <div
                className="h-full bg-[#7A1F2B] transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Map Search, Filters & Character Story Connections Toolbar */}
          <div className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl p-3.5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-2.5">
              {/* Search historical & modern names */}
              <div className="lg:col-span-4 relative">
                <Search className="w-4 h-4 text-[#57524A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  value={mapSearch}
                  onChange={(e) => setMapSearch(e.target.value)}
                  placeholder="ძიება (ქართ./ინგლ., ისტორიული ან ახალი სახელი)..."
                  className="w-full pl-9 pr-3 py-2 rounded-md bg-[#F7F3EB] border border-[#C9BFAE] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
                  aria-label="რუკაზე ლოკაციის ძიება"
                />
              </div>

              {/* Category select */}
              <div className="lg:col-span-3">
                <select
                  value={categoryFilter}
                  onChange={(e) =>
                    setCategoryFilter(
                      e.target.value as "all" | LocationCategory
                    )
                  }
                  aria-label="კატეგორიის ფილტრი"
                  className="w-full px-3 py-2 rounded-md bg-[#F7F3EB] border border-[#C9BFAE] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
                >
                  <option value="all">ყველა კატეგორია</option>
                  {(Object.keys(CATEGORY_META) as LocationCategory[]).map(
                    (cat) => (
                      <option key={cat} value={cat}>
                        {CATEGORY_META[cat].labelKa}
                      </option>
                    )
                  )}
                </select>
              </div>

              {/* Feature 5: Confidence filter */}
              <div className="lg:col-span-2">
                <select
                  value={confidenceFilter}
                  onChange={(e) =>
                    setConfidenceFilter(
                      e.target.value as "all" | ConfidenceLevel
                    )
                  }
                  aria-label="სანდოობის დონის ფილტრი"
                  className="w-full px-3 py-2 rounded-md bg-[#F7F3EB] border border-[#C9BFAE] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
                >
                  <option value="all">ყველა სანდოობა</option>
                  <option value="high">●●● მაღალი</option>
                  <option value="medium">●●○ საშუალო</option>
                  <option value="low">●○○ დაბალი</option>
                </select>
              </div>

              {/* Feature 6: Character Story Connections */}
              <div className="lg:col-span-3">
                <select
                  value={selectedCharacterId}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSelectedCharacterId(val);
                    if (val !== "all") {
                      const ch = charMap.get(val);
                      const firstMap = ch?.locationIds.find(
                        (id) => locMap.get(id)?.latitude !== null
                      );
                      if (firstMap) setSelectedLocationId(firstMap);
                    }
                  }}
                  aria-label="პერსონაჟის მიხედვით დაკავშირებული ადგილები"
                  className="w-full px-3 py-2 rounded-md bg-[#F7F3EB] border border-[#C9BFAE] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
                >
                  <option value="all">პერსონაჟთა კავშირები (ყველა)</option>
                  {initialCharacters.map((ch) => (
                    <option key={ch.id} value={ch.id}>
                      {ch.nameKa} ({ch.locationIds.length} ადგილი)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Quick Toggle Chips (Feature 4 + Historical Status) */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#57524A]">
                  <Filter className="w-3 h-3" /> სწრაფი ფილტრი:
                </span>

                <button
                  type="button"
                  onClick={() => setOnlyVisited((p) => !p)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium border transition ${
                    onlyVisited
                      ? "bg-[#7A1F2B] text-[#FDFBF7] border-[#7A1F2B]"
                      : "bg-[#F7F3EB] text-[#1F1D1A] border-[#D5CCBC] hover:border-[#7A1F2B]"
                  }`}
                >
                  მხოლოდ ფიზიკურად მონახულებული
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setOnlySurviving((p) => !p);
                    if (!onlySurviving) setOnlyFictionalOrUncertain(false);
                  }}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium border transition ${
                    onlySurviving
                      ? "bg-[#2E5A44] text-[#FDFBF7] border-[#2E5A44]"
                      : "bg-[#F7F3EB] text-[#1F1D1A] border-[#D5CCBC] hover:border-[#2E5A44]"
                  }`}
                >
                  დღემდე შემორჩენილი
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setOnlyFictionalOrUncertain((p) => !p);
                    if (!onlyFictionalOrUncertain) setOnlySurviving(false);
                  }}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium border transition ${
                    onlyFictionalOrUncertain
                      ? "bg-[#6B2D5C] text-[#FDFBF7] border-[#6B2D5C]"
                      : "bg-[#F7F3EB] text-[#1F1D1A] border-[#D5CCBC] hover:border-[#6B2D5C]"
                  }`}
                >
                  გამოგონილი / მიახლოებითი
                </button>

                {hasActiveMapFilters && (
                  <button
                    type="button"
                    onClick={resetMapFilters}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold text-[#7A1F2B] hover:bg-[#7A1F2B]/10 transition"
                  >
                    <RotateCcw className="w-3 h-3" /> გასუფთავება
                  </button>
                )}
              </div>

              <span className="text-[11px] text-[#57524A]">
                ნაჩვენებია{" "}
                <strong className="text-[#1F1D1A]">
                  {visibleMapLocations.filter((l) => l.latitude !== null).length}
                </strong>{" "}
                რუკის მარკერი
                {visibleMapLocations.some((l) => l.latitude === null)
                  ? " (+ 1 უკოორდინატო: „ედმონტი“)"
                  : ""}
              </span>
            </div>

            {/* Active Character Connection Banner */}
            {selectedCharacter && (
              <div className="p-3 rounded-lg bg-[#7A1F2B]/[0.06] border border-[#7A1F2B]/25 flex flex-col sm:flex-row sm:items-start justify-between gap-2 text-xs">
                <div className="space-y-1">
                  <p className="font-bold text-[#7A1F2B] flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5" />
                    {selectedCharacter.nameKa} ({selectedCharacter.nameEn}) —{" "}
                    <span className="font-normal text-[#1F1D1A]">
                      {selectedCharacter.roleKa}
                    </span>
                  </p>
                  <p className="text-[#57524A] leading-relaxed">
                    {selectedCharacter.descriptionKa}
                  </p>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {selectedCharacter.locationIds.map((lid) => {
                      const l = locMap.get(lid);
                      if (!l) return null;
                      return (
                        <button
                          key={lid}
                          type="button"
                          onClick={() => setSelectedLocationId(lid)}
                          className={`px-2 py-0.5 rounded text-[11px] font-medium border transition ${
                            selectedLocationId === lid
                              ? "bg-[#7A1F2B] text-[#FDFBF7] border-[#7A1F2B]"
                              : "bg-[#FDFBF7] text-[#1F1D1A] border-[#D5CCBC] hover:border-[#7A1F2B]"
                          }`}
                        >
                          {l.nameKa.split(" (")[0]}
                          {l.latitude === null ? " (უკოორდ.)" : ""}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedCharacterId("all")}
                  className="shrink-0 p-1 text-[#57524A] hover:text-[#7A1F2B]"
                  aria-label="პერსონაჟის ფილტრის დახურვა"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Main 12-Col Map + Synchronized Location Inspector */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
            {/* Real Leaflet NYC Map (8 cols) */}
            <div className="lg:col-span-8 h-[520px] sm:h-[600px] lg:h-[660px] rounded-xl overflow-hidden border border-[#C9BFAE] shadow-sm bg-[#E8E1D3]">
              <NewYorkLeafletMap
                allLocations={initialLocations}
                visibleLocations={visibleMapLocations}
                events={sortedEvents}
                selectedLocationId={selectedLocationId}
                activeEvent={activeEvent}
                prevLocationId={prevEvent?.locationId ?? null}
                nextLocationId={nextEvent?.locationId ?? null}
                guidedMode={guidedMode}
                showRoute={showRoute}
                onToggleRoute={() => setShowRoute((p) => !p)}
                historicalMode={historicalMode}
                onToggleHistoricalMode={() => setHistoricalMode((p) => !p)}
                highlightedCharacterLocationIds={highlightedCharacterLocationIds}
                onSelectLocation={(id) => handleSelectLocation(id, false)}
              />
            </div>

            {/* Synchronized Location & Story Side Panel (4 cols) */}
            <aside
              className="lg:col-span-4 lg:h-[660px] bg-[#FDFBF7] border border-[#C9BFAE] rounded-xl shadow-sm flex flex-col overflow-hidden"
              aria-label="არჩეული ლოკაციის საინფორმაციო პანელი"
            >
              {/* Panel Body (scrollable) */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
                {/* Category + Confidence + Historical Status */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <span
                    className="px-2 py-0.5 rounded text-[10.5px] font-semibold text-[#FDFBF7]"
                    style={{
                      backgroundColor:
                        CATEGORY_META[selectedLocation.category].color,
                    }}
                  >
                    {CATEGORY_META[selectedLocation.category].shortKa}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10.5px] font-semibold border ${
                      CONFIDENCE_META[selectedLocation.confidence].badgeClass
                    }`}
                  >
                    {CONFIDENCE_META[selectedLocation.confidence].symbol}{" "}
                    {CONFIDENCE_META[selectedLocation.confidence].labelKa}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10.5px] font-medium border ${
                      HISTORICAL_STATUS_META[selectedLocation.historicalStatus]
                        .badgeClass
                    }`}
                  >
                    {
                      HISTORICAL_STATUS_META[selectedLocation.historicalStatus]
                        .symbol
                    }{" "}
                    {
                      HISTORICAL_STATUS_META[selectedLocation.historicalStatus]
                        .labelKa
                    }
                  </span>
                </div>

                <div>
                  <h3 className="font-serif text-xl font-bold text-[#1F1D1A] leading-snug">
                    {selectedLocation.nameKa}
                  </h3>
                  <p className="text-xs text-[#57524A] mt-0.5">
                    {selectedLocation.novelNameEn} ·{" "}
                    {selectedLocation.neighborhoodKa}
                  </p>
                  <p className="text-[11px] text-[#57524A] mt-1">
                    <strong className="text-[#1F1D1A]">მისამართი:</strong>{" "}
                    {selectedLocation.historicalAddress}
                  </p>
                </div>

                {/* Archival / Modern Photo with inline Then/Now toggle */}
                {activeSideImg && (
                  <div className="rounded-lg overflow-hidden border border-[#DDD5C7] bg-[#F7F3EB]">
                    <div className="relative aspect-[16/10] bg-[#1F1D1A]">
                      <img
                        src={activeSideImg.url}
                        alt={activeSideImg.titleKa}
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-[#1F1D1A]/85 text-[#FDFBF7] text-[10.5px] font-medium">
                        {activeSideImg.era === "historical"
                          ? `მაშინ · ${activeSideImg.dateLabel}`
                          : `ახლა · ${activeSideImg.dateLabel}`}
                      </span>
                      {sideHistImg && sideModImg && (
                        <div className="absolute bottom-2 right-2 inline-flex rounded bg-[#FDFBF7]/95 p-0.5 text-[10.5px] font-semibold shadow">
                          <button
                            type="button"
                            onClick={() => setPanelPhotoEra("historical")}
                            className={`px-2 py-0.5 rounded ${
                              panelPhotoEra === "historical"
                                ? "bg-[#7A1F2B] text-[#FDFBF7]"
                                : "text-[#1F1D1A]"
                            }`}
                          >
                            მაშინ
                          </button>
                          <button
                            type="button"
                            onClick={() => setPanelPhotoEra("modern")}
                            className={`px-2 py-0.5 rounded ${
                              panelPhotoEra === "modern"
                                ? "bg-[#243447] text-[#FDFBF7]"
                                : "text-[#1F1D1A]"
                            }`}
                          >
                            ახლა
                          </button>
                        </div>
                      )}
                    </div>
                    <p className="px-2.5 py-1.5 text-[10.5px] text-[#57524A] truncate">
                      {activeSideImg.creator} · {activeSideImg.institution}
                    </p>
                  </div>
                )}

                {/* Literary Status Badge */}
                <div className="p-3 rounded-lg bg-[#F7F3EB] border border-[#DDD5C7] text-xs space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-[#7A1F2B]">
                      {
                        LITERARY_STATUS_META[selectedLocation.literaryStatus]
                          .labelKa
                      }
                    </span>
                    <span className="font-mono text-[11px] text-[#57524A]">
                      თავი {selectedLocation.chapters.join(", ")}
                    </span>
                  </div>
                  <p className="text-[#1F1D1A] leading-relaxed">
                    {selectedLocation.summaryKa}
                  </p>
                </div>

                {/* What Holden Did */}
                <div className="space-y-1.5 text-xs">
                  <h4 className="font-bold text-[#1F1D1A] uppercase tracking-wider text-[11px]">
                    ჰოლდენის გამოცდილება
                  </h4>
                  <p className="text-[#57524A] leading-relaxed">
                    {selectedLocation.holdensExperienceKa}
                  </p>
                </div>

                {/* Where Was It Then vs Today */}
                <div className="space-y-2 pt-2 border-t border-[#E5DEC9] text-xs">
                  <div>
                    <span className="font-bold text-[#7A1F2B]">
                      1949 წელს:{" "}
                    </span>
                    <span className="text-[#57524A] leading-relaxed">
                      {selectedLocation.historicalContextKa}
                    </span>
                  </div>
                  <div>
                    <span className="font-bold text-[#243447]">დღეს: </span>
                    <span className="text-[#57524A] leading-relaxed">
                      {selectedLocation.modernContextKa}
                    </span>
                  </div>
                </div>

                {/* Encountered Characters */}
                {selectedLocation.characterIds.length > 0 && (
                  <div className="pt-2 border-t border-[#E5DEC9]">
                    <p className="text-[11px] font-bold text-[#1F1D1A] mb-1.5">
                      დაკავშირებული პერსონაჟები:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedLocation.characterIds.map((cid) => {
                        const ch = charMap.get(cid);
                        if (!ch) return null;
                        return (
                          <button
                            key={cid}
                            type="button"
                            onClick={() => setSelectedCharacterId(cid)}
                            className="px-2 py-0.5 rounded bg-[#EFE9DC] hover:bg-[#7A1F2B] text-[#1F1D1A] hover:text-[#FDFBF7] text-[11px] font-medium transition"
                          >
                            {ch.nameKa}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Sticky Footer inside Panel: Full Dossier + Prev/Next Story Step */}
              <div className="p-3.5 border-t border-[#DDD5C7] bg-[#F7F3EB] space-y-2">
                <button
                  type="button"
                  onClick={() => setModalLocationId(selectedLocation.id)}
                  className="w-full inline-flex items-center justify-center gap-2 px-3.5 py-2 rounded-md bg-[#7A1F2B] text-[#FDFBF7] text-xs font-semibold hover:bg-[#5E1620] transition"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  სრული დოსიე, წყაროები ({selectedLocation.sourceIds.length}) და მინაწერები (
                  {noteCountByLocation.get(selectedLocation.id) ?? 0})
                </button>

                <div className="flex items-center justify-between gap-2 text-[11px]">
                  <button
                    type="button"
                    disabled={!prevEvent}
                    onClick={() => goToEventIndex(activeEventIndex - 1)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-[#C9BFAE] bg-[#FDFBF7] text-[#1F1D1A] font-medium disabled:opacity-40 hover:border-[#7A1F2B] transition truncate"
                  >
                    <ChevronLeft className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">
                      {prevEvent ? `#${prevEvent.sequence} წინა` : "დასაწყისი"}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedLocationId("edmont-hotel")}
                    className="px-2 py-1 text-[10.5px] text-[#57524A] hover:text-[#7A1F2B] underline shrink-0"
                    title="გამოგონილი სასტუმრო „ედმონტის“ ნახვა"
                  >
                    „ედმონტი“ (?)
                  </button>

                  <button
                    type="button"
                    disabled={!nextEvent}
                    onClick={() => goToEventIndex(activeEventIndex + 1)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-[#C9BFAE] bg-[#FDFBF7] text-[#1F1D1A] font-medium disabled:opacity-40 hover:border-[#7A1F2B] transition truncate"
                  >
                    <span className="truncate">
                      {nextEvent ? `#${nextEvent.sequence} შემდეგი` : "ფინალი"}
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 shrink-0" />
                  </button>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </section>

      {/* SECTION C — CHRONOLOGICAL TIMELINE */}
      <section
        id="timeline"
        className="py-16 sm:py-20 bg-[#FDFBF7] border-y border-[#DDD5C7] scroll-mt-14"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-5">
            <div className="max-w-3xl">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#7A1F2B]">
                ქრონოლოგიური რეკონსტრუქცია · 22 ეტაპი
              </p>
              <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#1F1D1A] tracking-tight">
                სამი დღე ნიუ-იორკში — მოვლენათა თანმიმდევრობა
              </h2>
              <p className="mt-2.5 text-sm text-[#57524A] leading-relaxed">
                ნებისმიერ მოვლენაზე დაჭერა ავტომატურად აახლებს რუკის ფოკუსს. შენიშვნა: კალენდარული თარიღები (17–19 დეკემბერი, 1949) ეფუძნება შუბერტის თეატრის რეპერტუარისა და სასკოლო კალენდრის შეჯერებას; თავად თხრობას ჰოლდენი მომდევნო წელს კალიფორნიის სანატორიუმიდან აწარმოებს (თავები 1 და 26).
              </p>
            </div>

            {/* Day tabs */}
            <div
              className="flex flex-wrap gap-1.5"
              role="tablist"
              aria-label="დღეების ფილტრი"
            >
              {[
                { id: "all" as const, label: `სრული (${sortedEvents.length})` },
                { id: "day1" as const, label: "დღე I · შაბათი ღამე (4)" },
                { id: "day2" as const, label: "დღე II · კვირა (13)" },
                { id: "day3" as const, label: "დღე III · ორშაბათი (5)" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={timelineDay === tab.id}
                  onClick={() => setTimelineDay(tab.id)}
                  className={`px-3.5 py-2 rounded-md text-xs font-semibold border transition ${
                    timelineDay === tab.id
                      ? "bg-[#7A1F2B] text-[#FDFBF7] border-[#7A1F2B]"
                      : "bg-[#F7F3EB] text-[#1F1D1A] border-[#D5CCBC] hover:border-[#7A1F2B]"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Timeline Cards */}
          <div className="mt-8 relative border-l-2 border-[#D5CCBC] ml-3 sm:ml-5 space-y-5">
            {displayedTimelineEvents.map((ev) => {
              const globalIdx = sortedEvents.findIndex((x) => x.id === ev.id);
              const isCurrent = globalIdx === activeEventIndex;
              const loc = locMap.get(ev.locationId);
              const moveMeta = MOVEMENT_META[ev.movementCertainty];
              const evChars = ev.characterIds
                .map((id) => charMap.get(id))
                .filter(Boolean) as StoryCharacter[];

              return (
                <article
                  key={ev.id}
                  className="relative pl-6 sm:pl-8"
                >
                  {/* Step circle on vertical rail */}
                  <span
                    className={`absolute -left-[15px] top-4 w-7 h-7 rounded-full text-[11px] font-mono font-bold flex items-center justify-center border-2 transition ${
                      isCurrent
                        ? "bg-[#7A1F2B] text-[#FDFBF7] border-[#FDFBF7] ring-2 ring-[#7A1F2B]"
                        : "bg-[#FDFBF7] text-[#243447] border-[#C9BFAE]"
                    }`}
                  >
                    {ev.sequence}
                  </span>

                  <div
                    onClick={() => goToEventIndex(globalIdx, false)}
                    className={`cursor-pointer rounded-xl border p-4 sm:p-5 transition ${
                      isCurrent
                        ? "bg-[#F7F3EB] border-[#7A1F2B] shadow-sm"
                        : "bg-[#FDFBF7] border-[#DDD5C7] hover:border-[#C9BFAE] hover:bg-[#F7F3EB]/50"
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-semibold text-[#7A1F2B]">
                          {ev.dayLabelKa}
                        </span>
                        <span className="text-[#57524A]">·</span>
                        <span className="inline-flex items-center gap-1 text-[#1F1D1A] font-medium">
                          <Clock className="w-3.5 h-3.5 text-[#7C5C3B]" />
                          {ev.timeLabelKa}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-[#EFE9DC] text-[#57524A] text-[10.5px]">
                          {ev.activityCategoryKa}
                        </span>
                      </div>
                      <span className="font-mono text-xs text-[#57524A]">
                        თავი {ev.chapter} · {ev.durationKa}
                      </span>
                    </div>

                    <h3 className="mt-2 font-serif text-lg sm:text-xl font-bold text-[#1F1D1A]">
                      {ev.titleKa}
                    </h3>

                    <p className="mt-1.5 text-xs sm:text-sm text-[#1F1D1A]/90 leading-relaxed">
                      {ev.summaryKa}
                    </p>

                    <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs text-[#57524A]">
                      <div className="bg-[#FDFBF7] border border-[#E5DEC9] rounded p-2.5">
                        <strong className="text-[#1F1D1A]">
                          გადაადგილება:
                        </strong>{" "}
                        {ev.movementModeKa}{" "}
                        <span className="text-[11px] text-[#7A1F2B]">
                          ({moveMeta.labelKa})
                        </span>
                      </div>
                      <div className="bg-[#FDFBF7] border border-[#E5DEC9] rounded p-2.5">
                        <strong className="text-[#1F1D1A]">
                          შედეგი სიუჟეტში:
                        </strong>{" "}
                        {ev.whatChangesAfterKa}
                      </div>
                    </div>

                    <p className="mt-2.5 text-xs text-[#57524A] italic">
                      {ev.psychologicalNoteKa}
                    </p>

                    <div className="mt-3.5 pt-3 border-t border-[#E5DEC9] flex flex-wrap items-center justify-between gap-3">
                      <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                        {loc && (
                          <span className="inline-flex items-center gap-1 font-semibold text-[#243447]">
                            <MapPin className="w-3.5 h-3.5 text-[#7A1F2B]" />
                            {loc.nameKa}
                            {loc.latitude === null ? " (გამოგონილი — პინის გარეშე)" : ""}
                          </span>
                        )}
                        {evChars.length > 0 && (
                          <span className="text-[#57524A]">
                            · პერსონაჟები: {evChars.map((c) => c.nameKa).join(", ")}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            resetMapFilters();
                            goToEventIndex(globalIdx, true);
                          }}
                          className="inline-flex items-center gap-1 px-3 py-1 rounded bg-[#7A1F2B] text-[#FDFBF7] text-xs font-semibold hover:bg-[#5E1620] transition"
                        >
                          <MapPin className="w-3 h-3" />
                          რუკაზე ჩვენება
                        </button>
                        {loc && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setModalLocationId(loc.id);
                            }}
                            className="px-3 py-1 rounded border border-[#C9BFAE] bg-[#FDFBF7] text-[#1F1D1A] text-xs font-medium hover:border-[#243447] transition"
                          >
                            დოსიე
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* SECTION D — LOCATION EXPLORER DIRECTORY */}
      <section
        id="locations"
        className="py-16 sm:py-20 bg-[#F7F3EB] scroll-mt-14"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#7A1F2B]">
              სრული საკვლევი კატალოგი · {initialLocations.length} ობიექტი
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#1F1D1A] tracking-tight">
              ადგილების ენციკლოპედიური საძიებელი
            </h2>
            <p className="mt-2.5 text-sm text-[#57524A] leading-relaxed">
              მოიცავს როგორც რუკაზე დატანილ {initialLocations.filter((l) => l.latitude !== null).length} გეოგრაფიულ ობიექტს, ისე გამოგონილ სასტუმრო „ედმონტს“ (რომელსაც ხელოვნური კოორდინატი არ ენიჭება). გახსენით ნებისმიერი ადგილი სრული დოსიეს, წყაროებისა და მკითხველთა მინაწერების სანახავად.
            </p>
          </div>

          {/* Directory Controls */}
          <div className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl p-4 flex flex-col lg:flex-row gap-3 lg:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-[#57524A] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="search"
                value={dirSearch}
                onChange={(e) => setDirSearch(e.target.value)}
                placeholder="მოძებნეთ ადგილი, ქუჩა, უბანი ან ინგლისური სახელი..."
                className="w-full pl-9 pr-3 py-2 rounded-md bg-[#F7F3EB] border border-[#C9BFAE] text-xs text-[#1F1D1A] focus:outline-none focus:border-[#7A1F2B]"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              <select
                value={dirLitStatus}
                onChange={(e) =>
                  setDirLitStatus(e.target.value as "all" | LiteraryStatus)
                }
                aria-label="ლიტერატურული კატეგორიის ფილტრი"
                className="px-3 py-2 rounded-md bg-[#F7F3EB] border border-[#C9BFAE] text-xs text-[#1F1D1A]"
              >
                <option value="all">ყველა ლიტერატურული სტატუსი (A–E)</option>
                <option value="physically_visited">
                  A — ფიზიკურად მონახულებული
                </option>
                <option value="passed_through">B — გავლილი სივრცე</option>
                <option value="observed">C — გარედან დანახული</option>
                <option value="mentioned">D — მხოლოდ მოხსენიებული</option>
                <option value="fictional_unverified">
                  E — გამოგონილი / პროტოტიპული
                </option>
              </select>

              <select
                value={dirConfidence}
                onChange={(e) =>
                  setDirConfidence(e.target.value as "all" | ConfidenceLevel)
                }
                aria-label="კატალოგის სანდოობის ფილტრი"
                className="px-3 py-2 rounded-md bg-[#F7F3EB] border border-[#C9BFAE] text-xs text-[#1F1D1A]"
              >
                <option value="all">ყველა სანდოობა</option>
                <option value="high">●●● მაღალი</option>
                <option value="medium">●●○ საშუალო</option>
                <option value="low">●○○ დაბალი</option>
                <option value="unverified">○○○ დაუდასტურებელი</option>
              </select>
            </div>
          </div>

          {/* Cards Grid */}
          {filteredDirectoryLocations.length === 0 ? (
            <div className="p-10 rounded-xl bg-[#FDFBF7] border border-[#D5CCBC] text-center space-y-2">
              <AlertCircle className="w-6 h-6 text-[#7A1F2B] mx-auto" />
              <p className="font-serif text-lg font-semibold text-[#1F1D1A]">
                არჩეული პარამეტრებით ლოკაცია ვერ მოიძებნა
              </p>
              <button
                type="button"
                onClick={() => {
                  setDirSearch("");
                  setDirLitStatus("all");
                  setDirConfidence("all");
                }}
                className="text-xs font-semibold text-[#7A1F2B] underline"
              >
                ფილტრების განულება
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredDirectoryLocations.map((loc) => {
                const cat = CATEGORY_META[loc.category];
                const lit = LITERARY_STATUS_META[loc.literaryStatus];
                const hist = HISTORICAL_STATUS_META[loc.historicalStatus];
                const conf = CONFIDENCE_META[loc.confidence];
                const coverImg = loc.images[0] ?? null;
                const nCount = noteCountByLocation.get(loc.id) ?? 0;

                return (
                  <article
                    key={loc.id}
                    className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl overflow-hidden shadow-xs hover:shadow-md hover:border-[#B8AC97] transition flex flex-col justify-between"
                  >
                    <div>
                      {coverImg ? (
                        <div className="relative h-44 bg-[#1F1D1A] overflow-hidden">
                          <img
                            src={coverImg.url}
                            alt={coverImg.titleKa}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-[#1F1D1A]/65 via-transparent to-transparent" />
                          <span
                            className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded text-[10.5px] font-semibold text-[#FDFBF7]"
                            style={{ backgroundColor: cat.color }}
                          >
                            {cat.shortKa}
                          </span>
                          <span className="absolute bottom-2 left-2.5 text-[10.5px] text-[#FDFBF7]/90 font-medium">
                            {coverImg.era === "historical"
                              ? `არქივი · ${coverImg.dateLabel}`
                              : `დოკუმენტური · ${coverImg.dateLabel}`}
                          </span>
                        </div>
                      ) : (
                        <div
                          className="h-24 px-5 py-3.5 flex items-end justify-between border-b border-[#E5DEC9]"
                          style={{ backgroundColor: cat.bgHex }}
                        >
                          <span
                            className="px-2 py-0.5 rounded text-[10.5px] font-semibold text-[#FDFBF7]"
                            style={{ backgroundColor: cat.color }}
                          >
                            {cat.shortKa}
                          </span>
                          <span className="font-mono text-xs text-[#57524A]">
                            თავი {loc.chapters.join(", ")}
                          </span>
                        </div>
                      )}

                      <div className="p-5 space-y-2.5">
                        <div className="flex flex-wrap items-center gap-1.5 text-[10.5px]">
                          <span
                            className={`px-2 py-0.5 rounded font-semibold border ${conf.badgeClass}`}
                          >
                            {conf.symbol} {conf.labelKa}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded font-medium border ${hist.badgeClass}`}
                          >
                            {hist.symbol} {hist.labelKa}
                          </span>
                        </div>

                        <h3 className="font-serif text-lg font-bold text-[#1F1D1A] leading-snug">
                          {loc.nameKa}
                        </h3>
                        <p className="text-[11px] text-[#57524A]">
                          {loc.novelNameEn} · {loc.neighborhoodKa} · კატ.{" "}
                          {lit.code} ({lit.labelKa})
                        </p>
                        <p className="text-xs text-[#57524A] leading-relaxed line-clamp-3">
                          {loc.summaryKa}
                        </p>
                      </div>
                    </div>

                    <div className="px-5 py-3.5 bg-[#F7F3EB]/75 border-t border-[#E5DEC9] flex items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setModalLocationId(loc.id)}
                          className="px-3 py-1.5 rounded bg-[#7A1F2B] text-[#FDFBF7] font-semibold hover:bg-[#5E1620] transition"
                        >
                          დოსიე
                        </button>
                        {loc.latitude !== null ? (
                          <button
                            type="button"
                            onClick={() => handleSelectLocation(loc.id, true)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded border border-[#C9BFAE] bg-[#FDFBF7] text-[#1F1D1A] font-medium hover:border-[#7A1F2B] transition"
                          >
                            <MapPin className="w-3 h-3 text-[#7A1F2B]" />
                            რუკაზე
                          </button>
                        ) : (
                          <span className="text-[11px] text-[#57524A] italic">
                            უკოორდინატო
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-[#57524A]">
                        {nCount > 0 && (
                          <span
                            className="inline-flex items-center gap-1 text-[#7A1F2B] font-medium"
                            title="მკითხველთა მინაწერები"
                          >
                            <MessageSquare className="w-3 h-3" />
                            {nCount}
                          </span>
                        )}
                        <Link
                          href={`/locations/${loc.id}`}
                          className="p-1 text-[#243447] hover:text-[#7A1F2B]"
                          title="ცალკე გვერდის გახსნა"
                          aria-label={`${loc.nameKa} — ცალკე გვერდი`}
                        >
                          <ArrowUpRight className="w-4 h-4" />
                        </Link>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* SECTION F — THEN AND NOW COMPARISON */}
      <ThenNowSlider
        locations={initialLocations}
        onFocusOnMap={(id) => handleSelectLocation(id, true)}
        onOpenDetail={(id) => setModalLocationId(id)}
      />

      {/* SECTIONS E & G — LITERARY EXPERIENCE THEMES + JOURNEY STATISTICS */}
      <ThemesAndStatsSection
        locations={initialLocations}
        events={sortedEvents}
        characters={initialCharacters}
        sources={initialSources}
        onFocusOnMap={(id) => handleSelectLocation(id, true)}
        onOpenDetail={(id) => setModalLocationId(id)}
      />

      {/* SECTION 13 — ABOUT THE RECONSTRUCTION, FACTUAL AUDIT & SOURCE REGISTRY */}
      <MethodologyAndSources
        sources={initialSources}
        onOpenDetail={(id) => setModalLocationId(id)}
      />

      {/* EDITORIAL FOOTER */}
      <footer className="bg-[#1F1D1A] text-[#EFE9DC] py-12 border-t border-[#34312C]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8 text-xs">
          <div className="space-y-2">
            <p className="font-serif text-lg font-bold text-[#FDFBF7]">
              ჰოლდენი ნიუ-იორკში
            </p>
            <p className="text-[#EFE9DC]/75 leading-relaxed">
              ჯ. დ. სელინჯერის რომანის „თამაში ჭვავის ყანაში“ (1951) ინტერაქტიული ლიტერატურულ-ისტორიული და გეოგრაფიული ატლასი ქართულ ენაზე.
            </p>
          </div>

          <div className="space-y-2">
            <p className="font-semibold text-[#E4C9A8] uppercase tracking-wider">
              კარტოგრაფია და არქივები
            </p>
            <p className="text-[#EFE9DC]/75 leading-relaxed">
              რუკის მონაცემები: © OpenStreetMap-ის მონაწილეები (Leaflet) და OpenTopoMap. საარქივო ფოტოგრაფია: აშშ-ის კონგრესის ბიბლიოთეკა (Library of Congress) და Wikimedia Commons.
            </p>
          </div>

          <div className="space-y-2">
            <p className="font-semibold text-[#E4C9A8] uppercase tracking-wider">
              საგანმანათლებლო შენიშვნა
            </p>
            <p className="text-[#EFE9DC]/75 leading-relaxed">
              დამოუკიდებელი არაკომერციული საგანმანათლებლო-კვლევითი პროექტი (პროექტი „ჰოლდენი“). არ არის დაკავშირებული ჯ. დ. სელინჯერის მემკვიდრეთა ფონდთან ან გამომცემლობა Little, Brown and Company-სთან.
            </p>
          </div>
        </div>
      </footer>

      {/* FULL LOCATION DOSSIER MODAL */}
      {modalLocation && (
        <div
          className="fixed inset-0 z-[900] bg-[#1F1D1A]/70 backdrop-blur-xs flex items-start justify-center p-3 sm:p-6 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-label={modalLocation.nameKa}
          onClick={() => setModalLocationId(null)}
        >
          <div
            className="relative w-full max-w-4xl bg-[#FDFBF7] border border-[#C9BFAE] rounded-xl shadow-2xl my-4 sm:my-8 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 z-10 px-5 py-3.5 bg-[#F7F3EB]/95 backdrop-blur border-b border-[#DDD5C7] flex items-center justify-between gap-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#7A1F2B]">
                სამუზეუმო დოსიე · ობიექტის არქივი
              </span>
              <button
                type="button"
                onClick={() => setModalLocationId(null)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-[#C9BFAE] bg-[#FDFBF7] text-xs font-semibold text-[#1F1D1A] hover:border-[#7A1F2B] hover:text-[#7A1F2B] transition"
              >
                <X className="w-3.5 h-3.5" />
                დახურვა
              </button>
            </div>

            <div className="p-5 sm:p-8">
              <LocationDossierContent
                location={modalLocation}
                events={sortedEvents}
                characters={initialCharacters}
                sources={initialSources}
                notes={notes}
                onNoteCreated={handleNoteCreated}
                onNoteDeleted={handleNoteDeleted}
                onFocusOnMap={(locId) => {
                  setModalLocationId(null);
                  handleSelectLocation(locId, true);
                }}
                onSelectCharacter={handleFocusCharacterOnMap}
                showStandaloneLink={true}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
