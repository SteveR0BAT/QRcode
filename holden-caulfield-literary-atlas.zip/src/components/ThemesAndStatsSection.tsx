"use client";

import { useMemo } from "react";
import { MapPin, Compass } from "lucide-react";
import type {
  AtlasLocation,
  ChronologicalEvent,
  StoryCharacter,
  ResearchSource,
} from "@/lib/types";
import { LITERARY_THEMES } from "@/data/sources";
import { haversineKm } from "@/data/locations";

interface ThemesAndStatsSectionProps {
  locations: AtlasLocation[];
  events: ChronologicalEvent[];
  characters: StoryCharacter[];
  sources: ResearchSource[];
  onFocusOnMap: (locationId: string) => void;
  onOpenDetail: (locationId: string) => void;
}

export default function ThemesAndStatsSection({
  locations,
  events,
  characters,
  sources,
  onFocusOnMap,
  onOpenDetail,
}: ThemesAndStatsSectionProps) {
  const locMap = useMemo(
    () => new Map(locations.map((l) => [l.id, l])),
    [locations]
  );

  const stats = useMemo(() => {
    const physicallyVisited = locations.filter(
      (l) => l.literaryStatus === "physically_visited"
    ).length;
    const observedOrPassed = locations.filter(
      (l) =>
        l.literaryStatus === "observed" || l.literaryStatus === "passed_through"
    ).length;
    const mentionedOnly = locations.filter(
      (l) => l.literaryStatus === "mentioned"
    ).length;
    const highConfidence = locations.filter((l) => l.confidence === "high").length;
    const fictionalOrProto = locations.filter(
      (l) =>
        l.historicalStatus === "fictional" ||
        l.historicalStatus === "fictional_inspired"
    ).length;
    const survivingToday = locations.filter(
      (l) => l.historicalStatus === "surviving"
    ).length;
    const demolishedOrReplaced = locations.filter(
      (l) =>
        l.historicalStatus === "demolished" || l.historicalStatus === "replaced"
    ).length;
    const neighborhoods = new Set(locations.map((l) => l.neighborhoodKa)).size;
    const directEncounters = characters.filter(
      (c) => c.presenceType === "encountered_in_nyc"
    ).length;

    // Straight-line lower bound across confirmed mappable consecutive events
    let straightLineKm = 0;
    const sorted = [...events].sort((a, b) => a.sequence - b.sequence);
    let prev: AtlasLocation | null = null;
    for (const ev of sorted) {
      const curr = locMap.get(ev.locationId);
      if (!curr || curr.latitude === null || curr.longitude === null) continue;
      if (prev && prev.id !== curr.id) {
        straightLineKm += haversineKm(
          prev.latitude as number,
          prev.longitude as number,
          curr.latitude,
          curr.longitude
        );
      }
      prev = curr;
    }

    return {
      total: locations.length,
      physicallyVisited,
      observedOrPassed,
      mentionedOnly,
      highConfidence,
      fictionalOrProto,
      survivingToday,
      demolishedOrReplaced,
      neighborhoods,
      directEncounters,
      totalEvents: events.length,
      totalSources: sources.length,
      straightLineKm: straightLineKm.toFixed(1),
    };
  }, [locations, events, characters, sources, locMap]);

  return (
    <>
      {/* SECTION E — HOLDEN'S EXPERIENCE IN NEW YORK */}
      <section id="themes" className="py-16 sm:py-20 bg-[#F7F3EB]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#7A1F2B]">
              თემატური ნარატივი · ქალაქი და ცნობიერება
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold text-[#1F1D1A] tracking-tight">
              ჰოლდენის გამოცდილება ნიუ-იორკში
            </h2>
            <p className="mt-3 text-sm sm:text-base text-[#57524A] leading-relaxed">
              ექვსი თემატური ჭრილი, რომელიც გეოგრაფიულ წერტილებს რომანის შინაგან დრამატურგიასთან აკავშირებს. თითოეულ ბარათში მკაფიოდაა გამიჯნული ტექსტით დადგენილი ფაქტები და ლიტერატურათმცოდნეობითი ინტერპრეტაცია.
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
            {LITERARY_THEMES.map((theme) => (
              <article
                key={theme.id}
                className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl p-6 flex flex-col justify-between shadow-sm"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-mono font-bold text-[#7A1F2B] tracking-wider">
                      თემა {theme.number}
                    </span>
                    <span className="font-mono text-[#57524A]">{theme.chapters}</span>
                  </div>
                  <h3 className="mt-2 font-serif text-xl font-bold text-[#1F1D1A]">
                    {theme.titleKa}
                  </h3>
                  <p className="mt-1 text-xs font-medium text-[#7C5C3B]">
                    {theme.subtitleKa}
                  </p>

                  <div className="mt-4 space-y-3 text-sm leading-relaxed">
                    <div>
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-[#243447] block mb-0.5">
                        ტექსტობრივი ფაქტები
                      </span>
                      <p className="text-[#1F1D1A] text-xs sm:text-sm leading-relaxed">
                        {theme.factualBasisKa}
                      </p>
                    </div>
                    <div className="p-3 rounded-lg bg-[#F7F3EB] border-l-2 border-[#7A1F2B]">
                      <p className="text-[#57524A] text-xs leading-relaxed">
                        {theme.literaryInterpretationKa}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3.5 border-t border-[#E5DEC9]">
                  <p className="text-[11px] font-semibold text-[#57524A] mb-2">
                    დაკავშირებული ლოკაციები:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {theme.relatedLocationIds.map((locId) => {
                      const loc = locMap.get(locId);
                      if (!loc) return null;
                      const isMappable = loc.latitude !== null;
                      return (
                        <button
                          key={locId}
                          type="button"
                          onClick={() =>
                            isMappable ? onFocusOnMap(locId) : onOpenDetail(locId)
                          }
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#F7F3EB] hover:bg-[#7A1F2B] text-[#1F1D1A] hover:text-[#FDFBF7] border border-[#D5CCBC] hover:border-[#7A1F2B] text-[11px] font-medium transition"
                        >
                          <MapPin className="w-3 h-3 shrink-0" />
                          <span>{loc.nameKa.split(" (")[0]}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION G — STATISTICS AND JOURNEY SUMMARY */}
      <section
        id="statistics"
        className="py-16 bg-[#243447] text-[#FDFBF7] border-b border-[#1A2635]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#E4C9A8]">
                მონაცემთა შეჯამება · რაოდენობრივი სურათი
              </p>
              <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-bold tracking-tight">
                მოგზაურობის სტატისტიკა და ბალანსი
              </h2>
              <p className="mt-2 text-sm text-[#FDFBF7]/80 leading-relaxed">
                ყველა მაჩვენებელი გამოთვლილია უშუალოდ აუდიტირებული მონაცემთა ბაზიდან; ზუსტი რაოდენობები მკაცრადაა გამიჯნული გეოგრაფიული შეფასებებისგან.
              </p>
            </div>
            <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-md bg-[#FDFBF7]/10 border border-[#FDFBF7]/15 text-xs text-[#E4C9A8]">
              <Compass className="w-4 h-4" />
              <span>1 რაიონი (მანჰეტენი) · {stats.neighborhoods} უბანი · თავები 9–25</span>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-lg bg-[#FDFBF7]/[0.07] border border-[#FDFBF7]/15">
              <p className="font-serif text-3xl font-bold text-[#FDFBF7]">
                {stats.physicallyVisited}
              </p>
              <p className="mt-1 text-xs font-semibold text-[#E4C9A8]">
                ფიზიკურად მონახულებული
              </p>
              <p className="mt-1 text-[11px] text-[#FDFBF7]/70">
                ზუსტი მაჩვენებელი (სულ {stats.total} საკვლევი ობიექტიდან)
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#FDFBF7]/[0.07] border border-[#FDFBF7]/15">
              <p className="font-serif text-3xl font-bold text-[#FDFBF7]">
                {stats.highConfidence}
              </p>
              <p className="mt-1 text-xs font-semibold text-[#E4C9A8]">
                მაღალი სანდოობით დადასტურებული
              </p>
              <p className="mt-1 text-[11px] text-[#FDFBF7]/70">
                დამოუკიდებელი საარქივო და გეოდეზიური წყაროებით
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#FDFBF7]/[0.07] border border-[#FDFBF7]/15">
              <p className="font-serif text-3xl font-bold text-[#FDFBF7]">
                {stats.survivingToday}{" "}
                <span className="text-base font-normal text-[#FDFBF7]/65">
                  / {stats.demolishedOrReplaced} დაკარგული
                </span>
              </p>
              <p className="mt-1 text-xs font-semibold text-[#E4C9A8]">
                დღემდე შემორჩენილი ობიექტები
              </p>
              <p className="mt-1 text-[11px] text-[#FDFBF7]/70">
                3 დანგრეულია (პენ-სადგური, ბილტმორი, სტორკ-კლუბი), 1 ჩანაცვლდა (კარუსელი)
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#FDFBF7]/[0.07] border border-[#FDFBF7]/15">
              <p className="font-serif text-3xl font-bold text-[#FDFBF7]">
                {stats.fictionalOrProto}
              </p>
              <p className="mt-1 text-xs font-semibold text-[#E4C9A8]">
                გამოგონილი ან პროტოტიპული
              </p>
              <p className="mt-1 text-[11px] text-[#FDFBF7]/70">
                „ედმონტი“ (უკოორდინატო), „სტენფორდ-არმსი“, „ერნი“, „უიკერ-ბარი“
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#FDFBF7]/[0.07] border border-[#FDFBF7]/15">
              <p className="font-serif text-3xl font-bold text-[#FDFBF7]">
                {stats.mentionedOnly + stats.observedOrPassed}
              </p>
              <p className="mt-1 text-xs font-semibold text-[#E4C9A8]">
                მოხსენიებული / გარედან დანახული
              </p>
              <p className="mt-1 text-[11px] text-[#FDFBF7]/70">
                {stats.mentionedOnly} მხოლოდ მოხსენიებული, 1 გარედან დანახული (AMNH), 1 გავლილი
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#FDFBF7]/[0.07] border border-[#FDFBF7]/15">
              <p className="font-serif text-3xl font-bold text-[#FDFBF7]">
                {stats.totalEvents}
              </p>
              <p className="mt-1 text-xs font-semibold text-[#E4C9A8]">
                ქრონოლოგიური ეტაპი (3 დღე)
              </p>
              <p className="mt-1 text-[11px] text-[#FDFBF7]/70">
                შაბათი ღამიდან ორშაბათ ნაშუადღევამდე (~40 საათი ქალაქში)
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#FDFBF7]/[0.07] border border-[#FDFBF7]/15">
              <p className="font-serif text-3xl font-bold text-[#FDFBF7]">
                {stats.directEncounters}
              </p>
              <p className="mt-1 text-xs font-semibold text-[#E4C9A8]">
                დოკუმენტირებული შეხვედრა
              </p>
              <p className="mt-1 text-[11px] text-[#FDFBF7]/70">
                პირისპირ შეხვედრილი პერსონაჟები და ჯგუფები (+ 4 მოხსენიებული/ტელეფონით)
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#7A1F2B]/40 border border-[#E4C9A8]/30">
              <p className="font-serif text-3xl font-bold text-[#FDFBF7]">
                ≈ {stats.straightLineKm} კმ
              </p>
              <p className="mt-1 text-xs font-semibold text-[#E4C9A8]">
                პირდაპირი ხაზით შეფასება (არაზუსტი)
              </p>
              <p className="mt-1 text-[11px] text-[#FDFBF7]/80">
                მხოლოდ კოორდინატიან წერტილებს შორის ჯამი (ტაქსი, მეტრო და ფეხით; არ წარმოადგენს ზუსტ გავლილ მანძილს)
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
