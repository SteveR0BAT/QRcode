"use client";

import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import {
  Layers,
  Info,
  RotateCcw,
  History,
  Route,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import {
  type AtlasLocation,
  type ChronologicalEvent,
  type MovementCertainty,
  CATEGORY_META,
  CONFIDENCE_META,
  HISTORICAL_STATUS_META,
  MOVEMENT_META,
} from "@/lib/types";

type BaseLayerKey = "archival" | "standard" | "topo";

const DEFAULT_OSM_URL =
  process.env.NEXT_PUBLIC_MAP_TILE_URL ||
  "https://tile.openstreetmap.org/{z}/{x}/{y}.png";

const BASE_LAYERS: Record<
  BaseLayerKey,
  {
    labelKa: string;
    url: string;
    attribution: string;
    toneClass: string;
    maxZoom: number;
  }
> = {
  archival: {
    labelKa: "საარქივო ტონი (OSM)",
    url: DEFAULT_OSM_URL,
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>-ის მონაწილეები',
    toneClass: "map-archival-tone",
    maxZoom: 19,
  },
  standard: {
    labelKa: "სტანდარტული რუკა (OSM)",
    url: DEFAULT_OSM_URL,
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>-ის მონაწილეები',
    toneClass: "map-standard-tone",
    maxZoom: 19,
  },
  topo: {
    labelKa: "ტოპოგრაფიული (OpenTopoMap)",
    url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    attribution:
      'რუკა: &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>, SRTM | სტილი: &copy; <a href="https://opentopomap.org" target="_blank" rel="noopener noreferrer">OpenTopoMap</a> (CC-BY-SA)',
    toneClass: "map-winter-tone",
    maxZoom: 17,
  },
};

const MANHATTAN_CENTER: [number, number] = [40.7615, -73.9785];
const MANHATTAN_ZOOM = 13;

interface NewYorkLeafletMapProps {
  allLocations: AtlasLocation[];
  visibleLocations: AtlasLocation[];
  events: ChronologicalEvent[];
  selectedLocationId: string | null;
  activeEvent: ChronologicalEvent | null;
  prevLocationId: string | null;
  nextLocationId: string | null;
  guidedMode: boolean;
  showRoute: boolean;
  onToggleRoute: () => void;
  historicalMode: boolean;
  onToggleHistoricalMode: () => void;
  highlightedCharacterLocationIds: Set<string> | null;
  onSelectLocation: (locationId: string) => void;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function createMarkerIcon(opts: {
  location: AtlasLocation;
  isSelected: boolean;
  isPrev: boolean;
  isNext: boolean;
  isCharHighlighted: boolean;
  historicalMode: boolean;
  stepNumber: number | null;
}): L.DivIcon {
  const {
    location,
    isSelected,
    isPrev,
    isNext,
    isCharHighlighted,
    historicalMode,
    stepNumber,
  } = opts;

  const cat = CATEGORY_META[location.category];
  const hist = HISTORICAL_STATUS_META[location.historicalStatus];
  const isUncertain =
    location.confidence === "medium" ||
    location.confidence === "low" ||
    location.historicalStatus === "fictional_inspired" ||
    location.historicalStatus === "fictional";
  const isMentionedOnly =
    location.literaryStatus === "mentioned" ||
    location.literaryStatus === "observed";

  const size = isSelected ? 38 : isCharHighlighted ? 34 : 30;
  const fillColor = isSelected ? "#7A1F2B" : cat.color;
  const borderStyle = isUncertain ? "dashed" : "solid";
  const borderColor = isSelected
    ? "#FDFBF7"
    : isNext
      ? "#7A1F2B"
      : isPrev
        ? "#243447"
        : "#FDFBF7";
  const opacity = isMentionedOnly && !isSelected ? "0.86" : "1";

  const innerText =
    stepNumber !== null ? String(stepNumber) : escapeHtml(cat.code);

  const statusBadge = historicalMode
    ? `<span style="position:absolute;top:-6px;right:-6px;width:16px;height:16px;border-radius:9999px;background:${
        location.historicalStatus === "demolished"
          ? "#7A1F2B"
          : location.historicalStatus === "replaced"
            ? "#8A6520"
            : location.historicalStatus === "surviving"
              ? "#2E5A44"
              : "#57524A"
      };color:#FDFBF7;font-size:9px;font-weight:700;display:flex;align-items:center;justify-content:center;border:1.5px solid #FDFBF7;box-shadow:0 1px 3px rgba(0,0,0,0.3);">${escapeHtml(
        hist.symbol
      )}</span>`
    : isNext
      ? `<span style="position:absolute;top:-7px;right:-8px;padding:0 4px;height:15px;border-radius:9999px;background:#7A1F2B;color:#FDFBF7;font-size:9px;font-weight:700;display:flex;align-items:center;justify-content:center;border:1px solid #FDFBF7;">→</span>`
      : isPrev
        ? `<span style="position:absolute;top:-7px;left:-8px;padding:0 4px;height:15px;border-radius:9999px;background:#243447;color:#FDFBF7;font-size:9px;font-weight:700;display:flex;align-items:center;justify-content:center;border:1px solid #FDFBF7;">←</span>`
        : "";

  const pulseRing = isSelected
    ? `<span class="holden-marker-pulse" style="position:absolute;inset:-7px;border-radius:9999px;border:2.5px solid #7A1F2B;pointer-events:none;"></span>`
    : isCharHighlighted
      ? `<span style="position:absolute;inset:-5px;border-radius:9999px;border:2px solid #7A1F2B;background:rgba(122,31,43,0.12);pointer-events:none;"></span>`
      : "";

  const html = `
    <div style="position:relative;width:${size}px;height:${size}px;display:flex;align-items:center;justify-content:center;opacity:${opacity};">
      ${pulseRing}
      <div style="
        width:${size}px;
        height:${size}px;
        border-radius:${isMentionedOnly ? "8px" : "9999px"};
        background:${fillColor};
        color:#FDFBF7;
        border:2.5px ${borderStyle} ${borderColor};
        box-shadow:0 3px 10px rgba(20,18,15,${isSelected ? "0.42" : "0.28"});
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:${isSelected ? "12px" : "10.5px"};
        font-weight:700;
        letter-spacing:-0.02em;
        transition:transform 0.18s ease;
      ">${innerText}</div>
      ${statusBadge}
    </div>
  `;

  return L.divIcon({
    html,
    className: "holden-custom-marker",
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    tooltipAnchor: [0, -(size / 2 + 4)],
  });
}

export default function NewYorkLeafletMap({
  allLocations,
  visibleLocations,
  events,
  selectedLocationId,
  activeEvent,
  prevLocationId,
  nextLocationId,
  guidedMode,
  showRoute,
  onToggleRoute,
  historicalMode,
  onToggleHistoricalMode,
  highlightedCharacterLocationIds,
  onSelectLocation,
}: NewYorkLeafletMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const routesLayerRef = useRef<L.LayerGroup | null>(null);
  const onSelectRef = useRef(onSelectLocation);

  const [baseLayer, setBaseLayer] = useState<BaseLayerKey>("archival");
  const [legendOpen, setLegendOpen] = useState(false);
  const [layerMenuOpen, setLayerMenuOpen] = useState(false);
  const [tileWarning, setTileWarning] = useState(false);

  useEffect(() => {
    onSelectRef.current = onSelectLocation;
  }, [onSelectLocation]);

  // Initialize real Leaflet map centered on Manhattan
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: MANHATTAN_CENTER,
      zoom: MANHATTAN_ZOOM,
      minZoom: 11,
      maxZoom: 19,
      zoomControl: false,
      scrollWheelZoom: true,
    });

    L.control.zoom({ position: "bottomright" }).addTo(map);

    const cfg = BASE_LAYERS.archival;
    let errCount = 0;
    const tl = L.tileLayer(cfg.url, {
      attribution: cfg.attribution,
      maxZoom: cfg.maxZoom,
      crossOrigin: true,
    });

    tl.on("tileerror", () => {
      errCount += 1;
      if (errCount >= 4) setTileWarning(true);
    });
    tl.on("tileload", () => {
      errCount = 0;
      setTileWarning(false);
    });

    tl.addTo(map);
    tileLayerRef.current = tl;
    routesLayerRef.current = L.layerGroup().addTo(map);
    markersLayerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;

    setTimeout(() => {
      map.invalidateSize();
    }, 150);

    return () => {
      map.remove();
      mapRef.current = null;
      tileLayerRef.current = null;
      markersLayerRef.current = null;
      routesLayerRef.current = null;
    };
  }, []);

  // Switch real tile provider layer cleanly
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
    }

    const cfg = BASE_LAYERS[baseLayer];
    let errCount = 0;
    const tl = L.tileLayer(cfg.url, {
      attribution: cfg.attribution,
      maxZoom: cfg.maxZoom,
      crossOrigin: true,
    });

    tl.on("tileerror", () => {
      errCount += 1;
      if (errCount >= 4) setTileWarning(true);
    });
    tl.on("tileload", () => {
      errCount = 0;
      setTileWarning(false);
    });

    tl.addTo(map);
    tl.bringToBack();
    tileLayerRef.current = tl;
  }, [baseLayer]);

  // Draw chronological route connectors (never fabricated street-by-street paths)
  useEffect(() => {
    const routesLayer = routesLayerRef.current;
    if (!routesLayer) return;
    routesLayer.clearLayers();

    if (!showRoute) return;

    const locMap = new Map(allLocations.map((l) => [l.id, l]));
    const sorted = [...events].sort((a, b) => a.sequence - b.sequence);
    const activeSeq = activeEvent?.sequence ?? 999;

    let lastMapped: AtlasLocation | null = null;
    let crossedUnmapped = false;

    for (const ev of sorted) {
      const curr = locMap.get(ev.locationId);
      if (!curr || curr.latitude === null || curr.longitude === null) {
        crossedUnmapped = true;
        continue;
      }

      if (lastMapped && lastMapped.id !== curr.id) {
        const certainty: MovementCertainty = crossedUnmapped
          ? "editorial"
          : ev.movementCertainty;
        const meta = MOVEMENT_META[certainty];
        const isCurrentLeg = activeEvent?.id === ev.id;
        const isFutureInGuided = guidedMode && ev.sequence > activeSeq;

        const line = L.polyline(
          [
            [lastMapped.latitude as number, lastMapped.longitude as number],
            [curr.latitude, curr.longitude],
          ],
          {
            color: isCurrentLeg ? "#7A1F2B" : meta.color,
            weight: isCurrentLeg ? 4 : 2.3,
            opacity: isCurrentLeg ? 0.95 : isFutureInGuided ? 0.2 : 0.58,
            dashArray: meta.dashArray || undefined,
            lineCap: "round",
          }
        );

        line.bindTooltip(
          `<div style="max-width:250px;font-size:12px;line-height:1.45;">
            <div style="font-weight:700;color:#7A1F2B;">ეტაპი #${ev.sequence}: ${escapeHtml(
              ev.movementModeKa
            )}</div>
            <div style="margin-top:2px;color:#1F1D1A;">${escapeHtml(
              meta.labelKa
            )}</div>
            <div style="margin-top:3px;font-size:11px;color:#57524A;">ქრონოლოგიური დამაკავშირებელი ხაზი (არ ასახავს ზუსტ ქუჩა-ქუჩა მარშრუტს)</div>
          </div>`,
          { sticky: true, className: "holden-tooltip" }
        );

        line.addTo(routesLayer);

        // Midpoint directional dot for current active leg
        if (isCurrentLeg) {
          const midLat = ((lastMapped.latitude as number) + curr.latitude) / 2;
          const midLng =
            ((lastMapped.longitude as number) + curr.longitude) / 2;
          L.circleMarker([midLat, midLng], {
            radius: 5,
            color: "#FDFBF7",
            weight: 2,
            fillColor: "#7A1F2B",
            fillOpacity: 1,
          }).addTo(routesLayer);
        }
      }

      lastMapped = curr;
      crossedUnmapped = false;
    }
  }, [allLocations, events, showRoute, activeEvent, guidedMode]);

  // Draw location markers
  useEffect(() => {
    const markersLayer = markersLayerRef.current;
    if (!markersLayer) return;
    markersLayer.clearLayers();

    // Compute first chronological event sequence per location
    const firstSeqByLoc = new Map<string, number>();
    for (const ev of events) {
      if (!firstSeqByLoc.has(ev.locationId)) {
        firstSeqByLoc.set(ev.locationId, ev.sequence);
      }
    }

    for (const loc of visibleLocations) {
      if (loc.latitude === null || loc.longitude === null) continue;

      const isSelected = loc.id === selectedLocationId;
      const isPrev = loc.id === prevLocationId && !isSelected;
      const isNext = loc.id === nextLocationId && !isSelected;
      const isCharHighlighted = Boolean(
        highlightedCharacterLocationIds?.has(loc.id)
      );

      const stepNumber =
        activeEvent?.locationId === loc.id
          ? activeEvent.sequence
          : firstSeqByLoc.get(loc.id) ?? null;

      const icon = createMarkerIcon({
        location: loc,
        isSelected,
        isPrev,
        isNext,
        isCharHighlighted,
        historicalMode,
        stepNumber,
      });

      const marker = L.marker([loc.latitude, loc.longitude], {
        icon,
        zIndexOffset: isSelected ? 1000 : isNext || isPrev ? 500 : 0,
        title: loc.nameKa,
        alt: `${loc.nameKa} — ${CATEGORY_META[loc.category].labelKa}`,
      });

      const confMeta = CONFIDENCE_META[loc.confidence];
      const histMeta = HISTORICAL_STATUS_META[loc.historicalStatus];
      const displayTitle = historicalMode ? loc.historicalNameKa : loc.nameKa;

      marker.bindTooltip(
        `<div style="max-width:250px;">
          <div style="font-size:13px;font-weight:700;color:#1F1D1A;line-height:1.3;">${escapeHtml(
            displayTitle
          )}</div>
          <div style="font-size:11px;color:#57524A;margin-top:2px;">${escapeHtml(
            loc.novelNameEn
          )} · ${escapeHtml(loc.neighborhoodKa)}</div>
          <div style="display:flex;gap:8px;align-items:center;margin-top:5px;font-size:10.5px;font-weight:600;color:#7A1F2B;">
            <span>${escapeHtml(confMeta.symbol)} ${escapeHtml(
              confMeta.labelKa
            )}</span>
            <span style="color:#57524A;">· ${escapeHtml(histMeta.symbol)} ${escapeHtml(
              histMeta.labelKa
            )}</span>
          </div>
        </div>`,
        {
          direction: "top",
          className: "holden-tooltip",
        }
      );

      marker.on("click", () => {
        onSelectRef.current(loc.id);
      });

      marker.addTo(markersLayer);
    }
  }, [
    visibleLocations,
    events,
    selectedLocationId,
    activeEvent,
    prevLocationId,
    nextLocationId,
    historicalMode,
    highlightedCharacterLocationIds,
  ]);

  // Smooth flyTo when selected location changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedLocationId) return;

    const target = allLocations.find((l) => l.id === selectedLocationId);
    if (!target || target.latitude === null || target.longitude === null) {
      return;
    }

    const targetZoom =
      target.coordinatePrecision === "building" ||
      target.coordinatePrecision === "site"
        ? 15
        : 14;

    map.flyTo([target.latitude, target.longitude], Math.max(map.getZoom(), targetZoom), {
      duration: 0.85,
      easeLinearity: 0.25,
    });
  }, [selectedLocationId, allLocations]);

  const handleResetView = () => {
    mapRef.current?.flyTo(MANHATTAN_CENTER, MANHATTAN_ZOOM, { duration: 0.7 });
  };

  return (
    <div
      className={`relative w-full h-full min-h-[500px] ${BASE_LAYERS[baseLayer].toneClass}`}
    >
      <div
        ref={containerRef}
        className="w-full h-full z-0"
        role="application"
        aria-label="ნიუ-იორკის ინტერაქტიული გეოგრაფიული რუკა — ჰოლდენ კოლფილდის მარშრუტი"
      />

      {/* Top-left floating cartographic controls */}
      <div className="absolute top-3 left-3 z-[450] flex flex-wrap items-center gap-2 max-w-[calc(100%-24px)]">
        <button
          type="button"
          onClick={onToggleRoute}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border shadow-sm transition ${
            showRoute
              ? "bg-[#7A1F2B] text-[#FDFBF7] border-[#7A1F2B]"
              : "bg-[#FDFBF7]/95 text-[#1F1D1A] border-[#C9BFAE] hover:bg-[#EFE9DC]"
          }`}
        >
          <Route className="w-3.5 h-3.5" />
          <span>ქრონოლოგიური ხაზი</span>
        </button>

        <button
          type="button"
          onClick={onToggleHistoricalMode}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border shadow-sm transition ${
            historicalMode
              ? "bg-[#243447] text-[#FDFBF7] border-[#243447]"
              : "bg-[#FDFBF7]/95 text-[#1F1D1A] border-[#C9BFAE] hover:bg-[#EFE9DC]"
          }`}
          title="აჩვენებს 1949 წლის ისტორიულ სახელწოდებებსა და შენობების გადარჩენის სტატუსს"
        >
          <History className="w-3.5 h-3.5" />
          <span>1949 წლის სტატუსი</span>
        </button>

        <div className="relative">
          <button
            type="button"
            onClick={() => setLayerMenuOpen((prev) => !prev)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-[#FDFBF7]/95 text-[#1F1D1A] border border-[#C9BFAE] shadow-sm hover:bg-[#EFE9DC] transition"
          >
            <Layers className="w-3.5 h-3.5 text-[#243447]" />
            <span>ფენა</span>
          </button>

          {layerMenuOpen && (
            <div className="absolute left-0 mt-1.5 w-60 rounded-lg bg-[#FDFBF7] border border-[#C9BFAE] shadow-xl p-2 space-y-1 z-[500]">
              <p className="px-2 py-1 text-[11px] font-semibold text-[#57524A] uppercase tracking-wider">
                რეალური კარტოგრაფიული საფუძველი
              </p>
              {(Object.keys(BASE_LAYERS) as BaseLayerKey[]).map((key) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    setBaseLayer(key);
                    setLayerMenuOpen(false);
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded text-xs transition ${
                    baseLayer === key
                      ? "bg-[#7A1F2B]/12 text-[#7A1F2B] font-semibold"
                      : "text-[#1F1D1A] hover:bg-[#EFE9DC]"
                  }`}
                >
                  {BASE_LAYERS[key].labelKa}
                </button>
              ))}
              <p className="px-2 pt-1.5 pb-0.5 text-[10.5px] leading-snug text-[#57524A] border-t border-[#DDD5C7]">
                ყალბი 1940-იანი რუკა არ გამოიყენება: ისტორიული შედარება ეყრდნობა OpenStreetMap-ის რეალურ ქუჩათა ბადესა და დადასტურებულ საარქივო ფოტოებს.
              </p>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={handleResetView}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium bg-[#FDFBF7]/95 text-[#1F1D1A] border border-[#C9BFAE] shadow-sm hover:bg-[#EFE9DC] transition"
          title="მანჰეტენის საერთო ხედზე დაბრუნება"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">მანჰეტენი</span>
        </button>
      </div>

      {/* Optional graceful tile warning */}
      {tileWarning && (
        <div className="absolute top-14 left-3 z-[450] max-w-xs bg-[#FDFBF7]/95 border border-[#9A3B26]/40 text-[#1F1D1A] rounded-md px-3 py-2 text-xs shadow-md flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-[#9A3B26] shrink-0 mt-0.5" />
          <span>
            რუკის ზოგიერთი ფრაგმენტი ნელა იტვირთება. ყველა კოორდინატი და მარკერი ლოკალურად ხელმისაწვდომია; შეგიძლიათ სცადოთ სხვა ფენა.
          </span>
        </div>
      )}

      {/* Unmapped fictional location honest notice when Edmont Hotel is active */}
      {selectedLocationId === "edmont-hotel" && (
        <div className="absolute top-14 left-3 right-3 sm:right-auto sm:max-w-md z-[450] bg-[#243447] text-[#FDFBF7] rounded-lg px-3.5 py-2.5 text-xs shadow-lg border border-[#FDFBF7]/20">
          <p className="font-semibold">
            სასტუმრო „ედმონტი“ — გამოგონილი ლოკაცია (უკოორდინატო)
          </p>
          <p className="mt-1 text-[#FDFBF7]/85 leading-relaxed">
            რომანში ზუსტი მისამართი არ სახელდება (მხოლოდ მიდთაუნი, გრინვიჩ-ვილიჯიდან 41 კვარტალით ჩრდილოეთით). კვლევითი სიზუსტის დასაცავად რუკაზე ყალბი პინი არ დაიტანება.
          </p>
        </div>
      )}

      {/* Bottom-left collapsible Map Legend */}
      <div className="absolute bottom-3 left-3 z-[450] max-w-[290px]">
        <div className="bg-[#FDFBF7]/95 backdrop-blur-sm border border-[#C9BFAE] rounded-lg shadow-md overflow-hidden">
          <button
            type="button"
            onClick={() => setLegendOpen((prev) => !prev)}
            className="w-full flex items-center justify-between gap-3 px-3 py-2 text-xs font-semibold text-[#1F1D1A] hover:bg-[#EFE9DC]/70 transition"
          >
            <span className="inline-flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-[#7A1F2B]" />
              პირობითი აღნიშვნები ({visibleLocations.filter((l) => l.latitude !== null).length} პინი)
            </span>
            {legendOpen ? (
              <ChevronDown className="w-3.5 h-3.5 text-[#57524A]" />
            ) : (
              <ChevronUp className="w-3.5 h-3.5 text-[#57524A]" />
            )}
          </button>

          {legendOpen && (
            <div className="px-3 pb-3 pt-1.5 border-t border-[#DDD5C7] space-y-2.5 max-h-72 overflow-y-auto text-[11px]">
              <div>
                <p className="font-semibold text-[#57524A] mb-1">კატეგორიები</p>
                <div className="grid grid-cols-2 gap-1">
                  {Object.entries(CATEGORY_META).map(([k, v]) => (
                    <div key={k} className="flex items-center gap-1.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: v.color }}
                      />
                      <span className="truncate text-[#1F1D1A]">{v.shortKa}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-[#DDD5C7] pt-2">
                <p className="font-semibold text-[#57524A] mb-1">
                  მარკერის ფორმა და სანდოობა
                </p>
                <div className="space-y-1 text-[#1F1D1A]">
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-[#243447] border-2 border-[#FDFBF7] ring-1 ring-[#243447] shrink-0" />
                    <span>●●● უწყვეტი წრე — მაღალი სანდოობა</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-[#7C5C3B] border-2 border-dashed border-[#FDFBF7] ring-1 ring-[#7C5C3B] shrink-0" />
                    <span>●●○ / ●○○ წყვეტილი — მიახლოებითი / პროტოტიპი</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-[3px] bg-[#57524A] shrink-0" />
                    <span>კვადრატი — გარედან დანახული ან მოხსენიებული</span>
                  </div>
                </div>
              </div>

              <div className="border-t border-[#DDD5C7] pt-2">
                <p className="font-semibold text-[#57524A] mb-1">
                  ქრონოლოგიური კავშირები
                </p>
                <div className="space-y-1 text-[#1F1D1A]">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-0.5 bg-[#7A1F2B] shrink-0" />
                    <span>ტექსტით დადასტურებული თანმიმდევრობა</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 border-t-2 border-dashed border-[#7C5C3B] shrink-0" />
                    <span>უბნის მიახლოება / სარედაქციო კავშირი</span>
                  </div>
                  <p className="text-[10px] text-[#57524A] leading-snug pt-0.5">
                    ხაზები ასახავს მოვლენათა ქრონოლოგიას და არა გამოგონილ ქუჩა-ქუჩა მარშრუტს.
                  </p>
                </div>
              </div>

              {historicalMode && (
                <div className="border-t border-[#DDD5C7] pt-2">
                  <p className="font-semibold text-[#57524A] mb-1">
                    1949 → დღეს სტატუსის ნიშნები
                  </p>
                  <div className="space-y-0.5 text-[#1F1D1A]">
                    <div>✓ შემორჩენილია · ✕ დანგრეულია · ↺ ჩანაცვლებულია · ≈ პროტოტიპი</div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
