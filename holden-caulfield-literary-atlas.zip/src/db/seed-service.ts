import { asc, desc, count } from "drizzle-orm";
import { db, pool } from "@/db";
import {
  locationsTable,
  eventsTable,
  sourcesTable,
  charactersTable,
  readerNotesTable,
} from "@/db/schema";
import { ATLAS_LOCATIONS } from "@/data/locations";
import { CHRONOLOGICAL_EVENTS } from "@/data/events";
import { RESEARCH_SOURCES, INITIAL_READER_NOTES } from "@/data/sources";
import { STORY_CHARACTERS } from "@/data/characters";
import type {
  AtlasLocation,
  ChronologicalEvent,
  ResearchSource,
  StoryCharacter,
  ReaderNote,
} from "@/lib/types";

let schemaEnsured = false;

/**
 * Ensures PostgreSQL tables exist and are seeded idempotently with all researched data.
 */
export async function ensureAtlasSeeded(): Promise<void> {
  if (!schemaEnsured) {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS atlas_locations (
        id TEXT PRIMARY KEY,
        name_ka TEXT NOT NULL,
        name_en TEXT NOT NULL,
        novel_name_en TEXT NOT NULL,
        historical_name_ka TEXT NOT NULL,
        modern_name_ka TEXT NOT NULL,
        category TEXT NOT NULL,
        literary_status TEXT NOT NULL,
        historical_status TEXT NOT NULL,
        confidence TEXT NOT NULL,
        coordinate_precision TEXT NOT NULL,
        latitude DOUBLE PRECISION,
        longitude DOUBLE PRECISION,
        historical_address TEXT NOT NULL,
        modern_address TEXT NOT NULL,
        neighborhood_ka TEXT NOT NULL,
        neighborhood_en TEXT NOT NULL,
        borough_ka TEXT NOT NULL,
        still_exists_today BOOLEAN NOT NULL DEFAULT TRUE,
        first_chapter INTEGER NOT NULL,
        chapters JSONB NOT NULL,
        summary_ka TEXT NOT NULL,
        holdens_experience_ka TEXT NOT NULL,
        historical_context_ka TEXT NOT NULL,
        modern_context_ka TEXT NOT NULL,
        uncertainty_note_ka TEXT NOT NULL,
        duration_note_ka TEXT NOT NULL,
        character_ids JSONB NOT NULL,
        event_ids JSONB NOT NULL,
        source_ids JSONB NOT NULL,
        literary_references JSONB NOT NULL,
        images JSONB NOT NULL,
        then_now JSONB
      );

      CREATE TABLE IF NOT EXISTS chronological_events (
        id TEXT PRIMARY KEY,
        sequence INTEGER NOT NULL,
        day_id TEXT NOT NULL,
        day_label_ka TEXT NOT NULL,
        date_estimate_ka TEXT NOT NULL,
        time_label_ka TEXT NOT NULL,
        time_confidence TEXT NOT NULL,
        chapter INTEGER NOT NULL,
        location_id TEXT NOT NULL,
        previous_location_id TEXT,
        title_ka TEXT NOT NULL,
        activity_category_ka TEXT NOT NULL,
        summary_ka TEXT NOT NULL,
        why_he_goes_ka TEXT NOT NULL,
        what_changes_after_ka TEXT NOT NULL,
        duration_ka TEXT NOT NULL,
        movement_certainty TEXT NOT NULL,
        movement_mode_ka TEXT NOT NULL,
        movement_note_ka TEXT NOT NULL,
        character_ids JSONB NOT NULL,
        source_ids JSONB NOT NULL,
        confidence TEXT NOT NULL,
        psychological_note_ka TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS research_sources (
        id TEXT PRIMARY KEY,
        title_ka TEXT NOT NULL,
        original_title TEXT NOT NULL,
        author_or_institution TEXT NOT NULL,
        publication_date TEXT NOT NULL,
        url TEXT NOT NULL,
        category TEXT NOT NULL,
        relevant_claim_ka TEXT NOT NULL,
        accessed_date TEXT NOT NULL,
        reliability_ka TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS story_characters (
        id TEXT PRIMARY KEY,
        name_ka TEXT NOT NULL,
        name_en TEXT NOT NULL,
        role_ka TEXT NOT NULL,
        presence_type TEXT NOT NULL,
        description_ka TEXT NOT NULL,
        location_ids JSONB NOT NULL,
        event_ids JSONB NOT NULL,
        chapters JSONB NOT NULL
      );

      CREATE TABLE IF NOT EXISTS reader_notes (
        id SERIAL PRIMARY KEY,
        location_id TEXT NOT NULL,
        author_name TEXT NOT NULL,
        author_role TEXT NOT NULL DEFAULT 'მკითხველი',
        note_type TEXT NOT NULL DEFAULT 'literary',
        content TEXT NOT NULL,
        chapter_ref TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);
    schemaEnsured = true;
  }

  const [{ value: locCount }] = await db
    .select({ value: count() })
    .from(locationsTable);

  if (locCount < ATLAS_LOCATIONS.length) {
    await db
      .insert(locationsTable)
      .values(ATLAS_LOCATIONS)
      .onConflictDoNothing();
  }

  const [{ value: evCount }] = await db
    .select({ value: count() })
    .from(eventsTable);

  if (evCount < CHRONOLOGICAL_EVENTS.length) {
    await db
      .insert(eventsTable)
      .values(CHRONOLOGICAL_EVENTS)
      .onConflictDoNothing();
  }

  const [{ value: srcCount }] = await db
    .select({ value: count() })
    .from(sourcesTable);

  if (srcCount < RESEARCH_SOURCES.length) {
    await db
      .insert(sourcesTable)
      .values(RESEARCH_SOURCES)
      .onConflictDoNothing();
  }

  const [{ value: charCount }] = await db
    .select({ value: count() })
    .from(charactersTable);

  if (charCount < STORY_CHARACTERS.length) {
    await db
      .insert(charactersTable)
      .values(STORY_CHARACTERS)
      .onConflictDoNothing();
  }

  const [{ value: noteCount }] = await db
    .select({ value: count() })
    .from(readerNotesTable);

  if (noteCount === 0) {
    await db.insert(readerNotesTable).values(INITIAL_READER_NOTES);
  }
}

export async function getCompleteAtlasData(): Promise<{
  locations: AtlasLocation[];
  events: ChronologicalEvent[];
  sources: ResearchSource[];
  characters: StoryCharacter[];
  notes: ReaderNote[];
}> {
  try {
    await ensureAtlasSeeded();

    const [locRows, evRows, srcRows, charRows, noteRows] = await Promise.all([
      db.select().from(locationsTable).orderBy(asc(locationsTable.firstChapter)),
      db.select().from(eventsTable).orderBy(asc(eventsTable.sequence)),
      db.select().from(sourcesTable),
      db.select().from(charactersTable),
      db
        .select()
        .from(readerNotesTable)
        .orderBy(desc(readerNotesTable.createdAt)),
    ]);

    return {
      locations: locRows as unknown as AtlasLocation[],
      events: evRows as unknown as ChronologicalEvent[],
      sources: srcRows as unknown as ResearchSource[],
      characters: charRows as unknown as StoryCharacter[],
      notes: noteRows.map((n) => ({
        id: n.id,
        locationId: n.locationId,
        authorName: n.authorName,
        authorRole: n.authorRole,
        noteType: n.noteType as ReaderNote["noteType"],
        content: n.content,
        chapterRef: n.chapterRef,
        createdAt: n.createdAt.toISOString(),
      })),
    };
  } catch {
    // Graceful static fallback during build-time prerender if DB isn't yet running
    return {
      locations: ATLAS_LOCATIONS,
      events: CHRONOLOGICAL_EVENTS,
      sources: RESEARCH_SOURCES,
      characters: STORY_CHARACTERS,
      notes: INITIAL_READER_NOTES.map((n, i) => ({
        id: i + 1,
        locationId: n.locationId,
        authorName: n.authorName,
        authorRole: n.authorRole,
        noteType: n.noteType as ReaderNote["noteType"],
        content: n.content,
        chapterRef: n.chapterRef,
        createdAt: new Date().toISOString(),
      })),
    };
  }
}
