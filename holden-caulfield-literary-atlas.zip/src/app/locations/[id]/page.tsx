import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ChevronLeft, ChevronRight, MapPin } from "lucide-react";
import { getCompleteAtlasData } from "@/db/seed-service";
import LocationDossierContent from "@/components/LocationDossierContent";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const { locations } = await getCompleteAtlasData();
  const loc = locations.find((l) => l.id === id);

  if (!loc) {
    return {
      title: "ლოკაცია ვერ მოიძებნა — ჰოლდენი ნიუ-იორკში",
    };
  }

  return {
    title: `${loc.nameKa} — ჰოლდენი ნიუ-იორკში | ლიტერატურული ატლასი`,
    description: loc.summaryKa,
  };
}

export default async function LocationDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const { locations, events, sources, characters, notes } =
    await getCompleteAtlasData();

  const currentIdx = locations.findIndex((l) => l.id === id);
  if (currentIdx === -1) {
    notFound();
  }

  const location = locations[currentIdx];
  const prevLoc = currentIdx > 0 ? locations[currentIdx - 1] : null;
  const nextLoc =
    currentIdx < locations.length - 1 ? locations[currentIdx + 1] : null;

  return (
    <div className="min-h-screen bg-[#F7F3EB] text-[#1F1D1A] flex flex-col">
      <header className="sticky top-0 z-50 bg-[#FDFBF7]/95 backdrop-blur border-b border-[#DDD5C7]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <Link
            href="/#locations"
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#1F1D1A] hover:text-[#7A1F2B] transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>ატლასსა და კატალოგში დაბრუნება</span>
          </Link>

          <Link
            href="/#atlas"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md bg-[#7A1F2B] text-[#FDFBF7] text-xs font-semibold hover:bg-[#5E1620] transition"
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>ნიუ-იორკის რუკა</span>
          </Link>
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-10">
        <div className="bg-[#FDFBF7] border border-[#D5CCBC] rounded-xl shadow-sm p-6 sm:p-10">
          <LocationDossierContent
            location={location}
            events={events}
            characters={characters}
            sources={sources}
            notes={notes}
            showStandaloneLink={false}
          />

          {location.thenNow && (
            <div className="mt-8 pt-6 border-t border-[#D5CCBC] space-y-3">
              <h3 className="font-serif text-lg font-bold text-[#1F1D1A]">
                შედარებითი ცხრილი: 1949 და დღევანდელობა
              </h3>
              <p className="text-xs text-[#7A1F2B] font-medium">
                {location.thenNow.whatChanged}
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-lg bg-[#F7F3EB] border border-[#DDD5C7] space-y-1.5">
                  <p className="font-bold text-[#7A1F2B]">
                    მაშინ — {location.thenNow.historicalName}
                  </p>
                  <p>{location.thenNow.historicalAppearance}</p>
                  <p className="text-[#57524A]">
                    დანიშნულება: {location.thenNow.historicalFunction}
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-[#F7F3EB] border border-[#DDD5C7] space-y-1.5">
                  <p className="font-bold text-[#243447]">
                    ახლა — {location.thenNow.modernName}
                  </p>
                  <p>{location.thenNow.modernAppearance}</p>
                  <p className="text-[#57524A]">
                    დანიშნულება: {location.thenNow.modernFunction}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Previous / Next Location Navigation */}
        <nav
          className="mt-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3"
          aria-label="მეზობელი ლოკაციები"
        >
          {prevLoc ? (
            <Link
              href={`/locations/${prevLoc.id}`}
              className="inline-flex items-center gap-2 px-4 py-3 rounded-lg bg-[#FDFBF7] border border-[#D5CCBC] hover:border-[#7A1F2B] text-xs font-semibold text-[#1F1D1A] transition"
            >
              <ChevronLeft className="w-4 h-4 text-[#7A1F2B] shrink-0" />
              <span className="truncate">{prevLoc.nameKa}</span>
            </Link>
          ) : (
            <div />
          )}

          {nextLoc ? (
            <Link
              href={`/locations/${nextLoc.id}`}
              className="inline-flex items-center justify-end gap-2 px-4 py-3 rounded-lg bg-[#FDFBF7] border border-[#D5CCBC] hover:border-[#7A1F2B] text-xs font-semibold text-[#1F1D1A] transition"
            >
              <span className="truncate">{nextLoc.nameKa}</span>
              <ChevronRight className="w-4 h-4 text-[#7A1F2B] shrink-0" />
            </Link>
          ) : (
            <div />
          )}
        </nav>
      </main>
    </div>
  );
}
