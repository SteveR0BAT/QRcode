import { NextRequest, NextResponse } from "next/server";
import { getCompleteAtlasData } from "@/db/seed-service";
import { buildAtlasGeoJson } from "@/data/locations";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const { locations, events } = await getCompleteAtlasData();
    const geojson = buildAtlasGeoJson(locations, events);
    const shouldDownload =
      new URL(request.url).searchParams.get("download") === "1";

    const headers: Record<string, string> = {
      "Content-Type": "application/geo+json; charset=utf-8",
    };

    if (shouldDownload) {
      headers["Content-Disposition"] =
        'attachment; filename="holden-new-york-literary-atlas-ka.geojson"';
    }

    return new NextResponse(JSON.stringify(geojson, null, 2), {
      status: 200,
      headers,
    });
  } catch (error) {
    console.error("GeoJSON export failed:", error);
    return NextResponse.json(
      { error: "GeoJSON მონაცემების გენერაცია ვერ მოხერხდა." },
      { status: 500 }
    );
  }
}
