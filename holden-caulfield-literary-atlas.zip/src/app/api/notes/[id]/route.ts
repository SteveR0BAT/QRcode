import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { readerNotesTable } from "@/db/schema";
import { ensureAtlasSeeded } from "@/db/seed-service";

export const dynamic = "force-dynamic";

export async function DELETE(
  _request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureAtlasSeeded();
    const { id } = await context.params;
    const numericId = Number(id);

    if (!Number.isInteger(numericId) || numericId <= 0) {
      return NextResponse.json(
        { error: "არასწორი ჩანაწერის ნომერი." },
        { status: 400 }
      );
    }

    const deleted = await db
      .delete(readerNotesTable)
      .where(eq(readerNotesTable.id, numericId))
      .returning({ id: readerNotesTable.id });

    if (deleted.length === 0) {
      return NextResponse.json(
        { error: "ჩანაწერი ვერ მოიძებნა." },
        { status: 404 }
      );
    }

    return NextResponse.json({ deletedId: numericId });
  } catch (error) {
    console.error("Failed to delete note:", error);
    return NextResponse.json(
      { error: "ჩანაწერის წაშლა ვერ მოხერხდა." },
      { status: 500 }
    );
  }
}
