import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { readerNotesTable } from "@/db/schema";
import { ensureAtlasSeeded } from "@/db/seed-service";
import { ATLAS_LOCATIONS } from "@/data/locations";

export const dynamic = "force-dynamic";

const VALID_LOCATION_IDS = new Set(ATLAS_LOCATIONS.map((l) => l.id));
const VALID_NOTE_TYPES = new Set(["literary", "historical", "geographical"]);

export async function GET(request: NextRequest) {
  try {
    await ensureAtlasSeeded();
    const locationId = new URL(request.url).searchParams.get("locationId");

    const rows = locationId
      ? await db
          .select()
          .from(readerNotesTable)
          .where(eq(readerNotesTable.locationId, locationId))
          .orderBy(desc(readerNotesTable.createdAt))
      : await db
          .select()
          .from(readerNotesTable)
          .orderBy(desc(readerNotesTable.createdAt));

    return NextResponse.json({
      notes: rows.map((n) => ({
        id: n.id,
        locationId: n.locationId,
        authorName: n.authorName,
        authorRole: n.authorRole,
        noteType: n.noteType,
        content: n.content,
        chapterRef: n.chapterRef,
        createdAt: n.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error("Failed to load reader notes:", error);
    return NextResponse.json(
      { error: "ჩანაწერების ჩატვირთვა ვერ მოხერხდა." },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureAtlasSeeded();
    const body = await request.json();

    const locationId = String(body?.locationId ?? "").trim();
    const authorName = String(body?.authorName ?? "").trim();
    const authorRole =
      String(body?.authorRole ?? "მკითხველი").trim() || "მკითხველი";
    const noteType = String(body?.noteType ?? "literary").trim();
    const content = String(body?.content ?? "").trim();
    const chapterRefRaw = String(body?.chapterRef ?? "").trim();

    if (!VALID_LOCATION_IDS.has(locationId)) {
      return NextResponse.json(
        { error: "არასწორი ლოკაციის იდენტიფიკატორი." },
        { status: 400 }
      );
    }

    if (authorName.length < 2 || authorName.length > 80) {
      return NextResponse.json(
        { error: "გთხოვთ მიუთითოთ სახელი (2–80 სიმბოლო)." },
        { status: 400 }
      );
    }

    if (content.length < 10 || content.length > 1000) {
      return NextResponse.json(
        { error: "ჩანაწერის ტექსტი უნდა შეიცავდეს 10-დან 1000-მდე სიმბოლოს." },
        { status: 400 }
      );
    }

    const safeType = VALID_NOTE_TYPES.has(noteType) ? noteType : "literary";
    const chapterRef = chapterRefRaw ? chapterRefRaw.slice(0, 40) : null;

    const [inserted] = await db
      .insert(readerNotesTable)
      .values({
        locationId,
        authorName,
        authorRole: authorRole.slice(0, 60),
        noteType: safeType,
        content,
        chapterRef,
      })
      .returning();

    return NextResponse.json(
      {
        note: {
          id: inserted.id,
          locationId: inserted.locationId,
          authorName: inserted.authorName,
          authorRole: inserted.authorRole,
          noteType: inserted.noteType,
          content: inserted.content,
          chapterRef: inserted.chapterRef,
          createdAt: inserted.createdAt.toISOString(),
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Failed to create reader note:", error);
    return NextResponse.json(
      { error: "ჩანაწერის შენახვა ვერ მოხერხდა." },
      { status: 500 }
    );
  }
}
