import { NextRequest, NextResponse } from "next/server";
import { getCompleteAtlasData } from "@/db/seed-service";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const data = await getCompleteAtlasData();
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const literaryStatus = searchParams.get("literaryStatus");
    const confidence = searchParams.get("confidence");
    const q = searchParams.get("q")?.trim().toLowerCase();

    let filteredLocations = data.locations;

    if (category && category !== "all") {
      filteredLocations = filteredLocations.filter((l) => l.category === category);
    }
    if (literaryStatus && literaryStatus !== "all") {
      filteredLocations = filteredLocations.filter(
        (l) => l.literaryStatus === literaryStatus
      );
    }
    if (confidence && confidence !== "all") {
      filteredLocations = filteredLocations.filter(
        (l) => l.confidence === confidence
      );
    }
    if (q) {
      filteredLocations = filteredLocations.filter(
        (l) =>
          l.nameKa.toLowerCase().includes(q) ||
          l.nameEn.toLowerCase().includes(q) ||
          l.novelNameEn.toLowerCase().includes(q) ||
          l.historicalNameKa.toLowerCase().includes(q) ||
          l.modernNameKa.toLowerCase().includes(q) ||
          l.neighborhoodKa.toLowerCase().includes(q) ||
          l.historicalAddress.toLowerCase().includes(q) ||
          l.modernAddress.toLowerCase().includes(q)
      );
    }

    return NextResponse.json({
      locations: filteredLocations,
      events: data.events,
      sources: data.sources,
      characters: data.characters,
      notes: data.notes,
      totalLocations: data.locations.length,
    });
  } catch (error) {
    console.error("Failed to fetch atlas data:", error);
    return NextResponse.json(
      { error: "ატლასის მონაცემების ჩატვირთვა ვერ მოხერხდა." },
      { status: 500 }
    );
  }
}
