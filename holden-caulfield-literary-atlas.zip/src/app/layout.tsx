import type { Metadata } from "next";
import type { ReactNode } from "react";
import {
  Noto_Serif_Georgian,
  Noto_Sans_Georgian,
  JetBrains_Mono,
} from "next/font/google";
import "leaflet/dist/leaflet.css";
import "./globals.css";

const serifGeorgian = Noto_Serif_Georgian({
  subsets: ["georgian", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-serif-ka",
  display: "swap",
});

const sansGeorgian = Noto_Sans_Georgian({
  subsets: ["georgian", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans-ka",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono-code",
  display: "swap",
});

export const metadata: Metadata = {
  title: "ჰოლდენი ნიუ-იორკში — „თამაში ჭვავის ყანაში“ | ლიტერატურული ატლასი",
  description:
    "ჯ. დ. სელინჯერის რომანის „თამაში ჭვავის ყანაში“ ინტერაქტიული ლიტერატურულ-ისტორიული და გეოგრაფიული ატლასი: ჰოლდენ კოლფილდის გზა, შეხვედრები, ქრონოლოგია და 1949 წლის ზამთრის მანჰეტენის რეკონსტრუქცია.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ka"
      className={`${serifGeorgian.variable} ${sansGeorgian.variable} ${jetbrainsMono.variable} scroll-smooth`}
    >
      <body className="bg-[#F7F3EB] text-[#1F1D1A] font-sans antialiased selection:bg-[#7A1F2B]/20 selection:text-[#1F1D1A]">
        {children}
      </body>
    </html>
  );
}
