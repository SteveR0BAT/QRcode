import { getCompleteAtlasData } from "@/db/seed-service";
import HoldenAtlasApp from "@/components/HoldenAtlasApp";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const { locations, events, sources, characters, notes } =
    await getCompleteAtlasData();

  return (
    <HoldenAtlasApp
      initialLocations={locations}
      initialEvents={events}
      initialSources={sources}
      initialCharacters={characters}
      initialNotes={notes}
    />
  );
}
