export type LocationCategory =
  | "hotel"
  | "nightlife"
  | "cultural"
  | "park"
  | "theatre"
  | "transport"
  | "commercial"
  | "residential"
  | "public_space";

export type LiteraryStatus =
  | "physically_visited"
  | "passed_through"
  | "observed"
  | "mentioned"
  | "fictional_unverified";

export type HistoricalStatus =
  | "surviving"
  | "demolished"
  | "replaced"
  | "fictional_inspired"
  | "fictional"
  | "approximate";

export type ConfidenceLevel = "high" | "medium" | "low" | "unverified";

export type CoordinatePrecision =
  | "building"
  | "site"
  | "street"
  | "neighborhood"
  | "none";

export type MovementCertainty =
  | "confirmed"
  | "implied"
  | "plausible"
  | "editorial";

export type SourceCategory =
  | "primary_literary"
  | "historical_primary"
  | "secondary_historical"
  | "literary_scholarship"
  | "geographical";

export interface ArchivalImage {
  id: string;
  era: "historical" | "modern";
  url: string;
  titleKa: string;
  originalTitle: string;
  dateLabel: string;
  creator: string;
  institution: string;
  sourceUrl: string;
  license: string;
  depictsNovelPeriod: boolean;
  captionKa: string;
}

export interface ThenNowComparison {
  historicalName: string;
  modernName: string;
  historicalAppearance: string;
  modernAppearance: string;
  historicalFunction: string;
  modernFunction: string;
  historicalAddress: string;
  modernAddress: string;
  historicalSignificance: string;
  modernSignificance: string;
  whatChanged: string;
}

export interface LiteraryReference {
  chapter: number;
  contextKa: string;
  briefExcerptNoteKa: string;
}

export interface AtlasLocation {
  id: string;
  nameKa: string;
  nameEn: string;
  novelNameEn: string;
  historicalNameKa: string;
  modernNameKa: string;
  category: LocationCategory;
  literaryStatus: LiteraryStatus;
  historicalStatus: HistoricalStatus;
  confidence: ConfidenceLevel;
  coordinatePrecision: CoordinatePrecision;
  latitude: number | null;
  longitude: number | null;
  historicalAddress: string;
  modernAddress: string;
  neighborhoodKa: string;
  neighborhoodEn: string;
  boroughKa: string;
  stillExistsToday: boolean;
  firstChapter: number;
  chapters: number[];
  summaryKa: string;
  holdensExperienceKa: string;
  historicalContextKa: string;
  modernContextKa: string;
  uncertaintyNoteKa: string;
  durationNoteKa: string;
  characterIds: string[];
  eventIds: string[];
  sourceIds: string[];
  literaryReferences: LiteraryReference[];
  images: ArchivalImage[];
  thenNow: ThenNowComparison | null;
}

export interface ChronologicalEvent {
  id: string;
  sequence: number;
  dayId: "day1" | "day2" | "day3";
  dayLabelKa: string;
  dateEstimateKa: string;
  timeLabelKa: string;
  timeConfidence: "exact_text" | "approximate" | "relative" | "uncertain";
  chapter: number;
  locationId: string;
  previousLocationId: string | null;
  titleKa: string;
  activityCategoryKa: string;
  summaryKa: string;
  whyHeGoesKa: string;
  whatChangesAfterKa: string;
  durationKa: string;
  movementCertainty: MovementCertainty;
  movementModeKa: string;
  movementNoteKa: string;
  characterIds: string[];
  sourceIds: string[];
  confidence: ConfidenceLevel;
  psychologicalNoteKa: string;
}

export interface ResearchSource {
  id: string;
  titleKa: string;
  originalTitle: string;
  authorOrInstitution: string;
  publicationDate: string;
  url: string;
  category: SourceCategory;
  relevantClaimKa: string;
  accessedDate: string;
  reliabilityKa: string;
}

export interface StoryCharacter {
  id: string;
  nameKa: string;
  nameEn: string;
  roleKa: string;
  presenceType: "encountered_in_nyc" | "telephoned" | "remembered_or_mentioned";
  descriptionKa: string;
  locationIds: string[];
  eventIds: string[];
  chapters: number[];
}

export interface ReaderNote {
  id: number;
  locationId: string;
  authorName: string;
  authorRole: string;
  noteType: "literary" | "historical" | "geographical";
  content: string;
  chapterRef: string | null;
  createdAt: string;
}

export interface LiteraryTheme {
  id: string;
  number: string;
  titleKa: string;
  subtitleKa: string;
  factualBasisKa: string;
  literaryInterpretationKa: string;
  relatedLocationIds: string[];
  chapters: string;
}

export interface AuditItem {
  id: string;
  questionKa: string;
  commonMythKa: string;
  verifiedFindingKa: string;
  resolutionConfidence: ConfidenceLevel;
  relatedLocationId: string;
  sourceIds: string[];
}

export const CATEGORY_META: Record<
  LocationCategory,
  { labelKa: string; shortKa: string; color: string; bgHex: string; code: string }
> = {
  transport: {
    labelKa: "სატრანსპორტო სადგურები და ხაზები",
    shortKa: "ტრანსპორტი",
    color: "#243447",
    bgHex: "#E7ECF2",
    code: "ტრ",
  },
  hotel: {
    labelKa: "სასტუმროები და განთავსება",
    shortKa: "სასტუმრო",
    color: "#7A1F2B",
    bgHex: "#F5E7E9",
    code: "სტ",
  },
  nightlife: {
    labelKa: "ბარები და ღამის კლუბები",
    shortKa: "ღამის ცხოვრება",
    color: "#6B2D5C",
    bgHex: "#F2E8F0",
    code: "ბრ",
  },
  park: {
    labelKa: "პარკები და ღია სივრცეები",
    shortKa: "პარკი",
    color: "#2E5A44",
    bgHex: "#E6EFEA",
    code: "პრ",
  },
  cultural: {
    labelKa: "მუზეუმები და სასწავლებლები",
    shortKa: "კულტურა / მუზეუმი",
    color: "#7C5C3B",
    bgHex: "#F2ECE4",
    code: "მზ",
  },
  theatre: {
    labelKa: "თეატრები და სანახაობა",
    shortKa: "თეატრი",
    color: "#9A3B26",
    bgHex: "#F7EAE6",
    code: "თტ",
  },
  commercial: {
    labelKa: "სავაჭრო ქუჩები და მაღაზიები",
    shortKa: "სავაჭრო სივრცე",
    color: "#8A6520",
    bgHex: "#F5EFE0",
    code: "მღ",
  },
  residential: {
    labelKa: "საცხოვრებელი და საოჯახო გარემო",
    shortKa: "საცხოვრებელი",
    color: "#3D4F5F",
    bgHex: "#E9EEF2",
    code: "სხ",
  },
  public_space: {
    labelKa: "ქუჩები, ავენიუები და მოედნები",
    shortKa: "ქუჩა / მოედანი",
    color: "#52524E",
    bgHex: "#ECECE8",
    code: "ქჩ",
  },
};

export const LITERARY_STATUS_META: Record<
  LiteraryStatus,
  { code: string; labelKa: string; descriptionKa: string }
> = {
  physically_visited: {
    code: "A",
    labelKa: "ფიზიკურად მონახულებული",
    descriptionKa: "ჰოლდენი უშუალოდ მიდის და იმყოფება ამ ადგილას რომანის მოქმედებისას.",
  },
  passed_through: {
    code: "B",
    labelKa: "გავლილი სივრცე",
    descriptionKa: "ჰოლდენი გაივლის ამ ქუჩას ან სატრანსპორტო დერეფანს გადაადგილებისას.",
  },
  observed: {
    code: "C",
    labelKa: "გარედან დანახული",
    descriptionKa: "ჰოლდენი მიადგება შენობას და აღწერს მას, მაგრამ შიგნით აღარ შედის.",
  },
  mentioned: {
    code: "D",
    labelKa: "მხოლოდ მოხსენიებული",
    descriptionKa: "ადგილი იხსენიება საუბარში, ფიქრში ან სატელეფონო ზარისას, ვიზიტის გარეშე.",
  },
  fictional_unverified: {
    code: "E",
    labelKa: "გამოგონილი / დაუდგენელი",
    descriptionKa: "ლიტერატურული ობიექტი, რომელსაც დადასტურებული რეალური მისამართი არ გააჩნია.",
  },
};

export const HISTORICAL_STATUS_META: Record<
  HistoricalStatus,
  { labelKa: string; symbol: string; badgeClass: string }
> = {
  surviving: {
    labelKa: "შემორჩენილია დღემდე",
    symbol: "✓",
    badgeClass: "bg-[#2E5A44]/12 text-[#234735] border-[#2E5A44]/30",
  },
  demolished: {
    labelKa: "დანგრეული / გამქრალი",
    symbol: "✕",
    badgeClass: "bg-[#7A1F2B]/12 text-[#691823] border-[#7A1F2B]/30",
  },
  replaced: {
    labelKa: "ჩანაცვლებული მემკვიდრით",
    symbol: "↺",
    badgeClass: "bg-[#8A6520]/14 text-[#6E4F14] border-[#8A6520]/35",
  },
  fictional_inspired: {
    labelKa: "გამოგონილი (რეალური პროტოტიპით)",
    symbol: "≈",
    badgeClass: "bg-[#6B2D5C]/12 text-[#57224A] border-[#6B2D5C]/30",
  },
  fictional: {
    labelKa: "გამოგონილი დაწესებულება",
    symbol: "?",
    badgeClass: "bg-[#57524A]/14 text-[#3F3B35] border-[#57524A]/35",
  },
  approximate: {
    labelKa: "უბნის / ქუჩის სიზუსტით",
    symbol: "◎",
    badgeClass: "bg-[#243447]/12 text-[#1D2B3B] border-[#243447]/30",
  },
};

export const CONFIDENCE_META: Record<
  ConfidenceLevel,
  { labelKa: string; symbol: string; explanationKa: string; badgeClass: string }
> = {
  high: {
    labelKa: "მაღალი სანდოობა",
    symbol: "●●●",
    explanationKa:
      "რომანის ტექსტი და დამოუკიდებელი საარქივო-გეოგრაფიული წყაროები ცალსახად ადასტურებს რეალურ მდებარეობას.",
    badgeClass: "bg-[#2E5A44]/12 text-[#1F4230] border-[#2E5A44]/35",
  },
  medium: {
    labelKa: "საშუალო სანდოობა",
    symbol: "●●○",
    explanationKa:
      "ქუჩა ან უბანი დადასტურებულია, თუმცა ზუსტი შენობის ნომერი ან ლიტერატურული ეკვივალენტი სადავოა.",
    badgeClass: "bg-[#8A6520]/14 text-[#6B4D13] border-[#8A6520]/35",
  },
  low: {
    labelKa: "დაბალი სანდოობა",
    symbol: "●○○",
    explanationKa:
      "არგუმენტირებული გეოგრაფიული მიახლოება უბნის დონეზე; ზუსტი ისტორიული კოორდინატი არ დასტურდება.",
    badgeClass: "bg-[#9A3B26]/14 text-[#7A2D1C] border-[#9A3B26]/35",
  },
  unverified: {
    labelKa: "დაუდასტურებელი (უკოორდინატო)",
    symbol: "○○○",
    explanationKa:
      "გამოგონილი ობიექტი საკმარისი მტკიცებულების გარეშე — ხელოვნური კოორდინატი რუკაზე არ დაიტანება.",
    badgeClass: "bg-[#57524A]/14 text-[#3A3631] border-[#57524A]/35",
  },
};

export const MOVEMENT_META: Record<
  MovementCertainty,
  { labelKa: string; dashArray: string; color: string; descriptionKa: string }
> = {
  confirmed: {
    labelKa: "ტექსტით დადასტურებული გადაადგილება",
    dashArray: "",
    color: "#7A1F2B",
    descriptionKa:
      "რომანში პირდაპირ აღწერილია გადაადგილება ამ ორ პუნქტს შორის (ტაქსით, ფეხით ან მეტროთი). ხაზი ასახავს ქრონოლოგიურ თანმიმდევრობას და არა გამოგონილ ქუჩა-ქუჩა მარშრუტს.",
  },
  implied: {
    labelKa: "ნაგულისხმევი გადაადგილება",
    dashArray: "7 6",
    color: "#243447",
    descriptionKa:
      "თხრობა უშუალოდ გადადის მომდევნო ლოკაციაზე, თუმცა ზუსტი ქუჩები არ სახელდება.",
  },
  plausible: {
    labelKa: "გეოგრაფიული მიახლოება",
    dashArray: "3 6",
    color: "#7C5C3B",
    descriptionKa:
      "ერთ-ერთი წერტილი უბნის დონის მიახლოებაა (მაგ., გამოგონილი კლუბი გრინვიჩ-ვილიჯში).",
  },
  editorial: {
    labelKa: "სარედაქციო ქრონოლოგიური კავშირი",
    dashArray: "2 8",
    color: "#78716C",
    descriptionKa:
      "შუალედური გაჩერება (სასტუმრო „ედმონტი“) გამოგონილია და რუკაზე პინი არ აქვს; კავშირი მხოლოდ ქრონოლოგიურ უწყვეტობას მიანიშნებს.",
  },
};

export const SOURCE_CATEGORY_META: Record<SourceCategory, string> = {
  primary_literary: "პირველადი ლიტერატურული წყარო",
  historical_primary: "პირველადი ისტორიულ-საარქივო წყარო",
  secondary_historical: "მეორეული ისტორიული კვლევა",
  literary_scholarship: "ლიტერატურათმცოდნეობითი ანალიზი",
  geographical: "გეოგრაფიული და კარტოგრაფიული წყარო",
};
